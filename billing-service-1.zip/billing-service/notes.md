# Note

- Bagaimana menghandle SKTRAN jika tiap hari melakukan update
- Bagaimana melakukan pembacaan data dari file SKTRAN?
- Bagaimana menyimpan data yang sudah dibaca tersebut kedalam table database?