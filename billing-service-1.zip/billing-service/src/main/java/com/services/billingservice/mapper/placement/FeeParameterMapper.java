package com.services.billingservice.mapper.placement;

import com.services.billingservice.dto.placement.feeparameter.FeeParameterPlacementDTO;
import com.services.billingservice.model.placement.FeeParameterPlacement;
import org.mapstruct.Mapper;

import java.util.List;

@Mapper(componentModel = "spring")
public interface FeeParameterMapper {
    List<FeeParameterPlacementDTO>toDTOList(List<FeeParameterPlacement>all);
}
