package com.services.billingservice.dto.placement.bifastpaymentstatus;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BiFastPaymentStatusRequest {

    private String originalTrxType;

    private String payUserRefNo;

    private String originalUserRefNo;

}
