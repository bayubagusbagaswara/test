package com.services.billingservice.controller.placement;

import com.services.billingservice.dto.ResponseDTO;
import com.services.billingservice.dto.placement.datachange.PlacementDataChangeDTO;
import com.services.billingservice.dto.placement.instructionsinvest.*;
import com.services.billingservice.exception.GeneralException;
import com.services.billingservice.exception.placement.TooManyRequestException;
import com.services.billingservice.service.placement.InstructionsSInvestService;
import com.services.billingservice.utils.ClientIPUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.time.LocalDateTime;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

@RestController
@RequestMapping(path = "/api/placement/sinvest")
@CrossOrigin(origins = "*", allowedHeaders = "*")
@Slf4j
@RequiredArgsConstructor
public class InstructionsSInvestController {

    private static final String BASE_URL_S_INVEST = "/api/placement/sinvest";
    private static final String MENU_S_INVEST = "S Invest";

    private final InstructionsSInvestService instructionsSInvestService;

    @PostMapping(path = "/upload-data")
    public ResponseEntity<ResponseDTO<InstructionsSInvestResponse>> uploadData(@RequestBody UploadInstructionsSInvestListRequest uploadInstructionsSInvestListRequest, HttpServletRequest servletRequest) {
        String inputIPAddress = ClientIPUtil.getClientIp(servletRequest);
        PlacementDataChangeDTO placementDataChangeDTO = PlacementDataChangeDTO.builder()
                .inputerId(uploadInstructionsSInvestListRequest.getInputerId())
                .inputIPAddress(inputIPAddress)
                .inputDate(LocalDateTime.now())
                .isRequestBody(true)
                .isRequestParam(false)
                .isPathVariable(false)
                .menu(MENU_S_INVEST)
                .build();

        CompletableFuture<InstructionsSInvestResponse> futureResult = instructionsSInvestService.uploadData(uploadInstructionsSInvestListRequest, placementDataChangeDTO);

        try {
            InstructionsSInvestResponse result = futureResult.get();
            ResponseDTO<InstructionsSInvestResponse> response = ResponseDTO.<InstructionsSInvestResponse>builder()
                    .code(HttpStatus.OK.value())
                    .message(HttpStatus.OK.getReasonPhrase())
                    .payload(result)
                    .build();
            return ResponseEntity.ok(response);
        } catch (ExecutionException e) {
            Throwable cause = e.getCause();
            if (cause instanceof TooManyRequestException) {
                throw (TooManyRequestException) cause;
            }
            throw new GeneralException(cause.getMessage());
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new GeneralException("Operation interrupted");
        }
    }

    @PostMapping(path = "/create/approve")
    public ResponseEntity<ResponseDTO<InstructionsSInvestResponse>> createApprove(@RequestBody ApproveInstructionsSInvestRequest approveInstructionsSInvestRequest, HttpServletRequest servletRequest) {
        String approveIPAddress = ClientIPUtil.getClientIp(servletRequest);
        InstructionsSInvestResponse singleApprove = instructionsSInvestService.createApprove(approveInstructionsSInvestRequest, approveIPAddress);
        ResponseDTO<InstructionsSInvestResponse> response = ResponseDTO.<InstructionsSInvestResponse>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(singleApprove)
                .build();
        return ResponseEntity.ok(response);
    }

    @PutMapping(path = "/update/approve")
    public ResponseEntity<ResponseDTO<InstructionsSInvestResponse>> updateApprove(@RequestBody ApproveInstructionsSInvestRequest approveInstructionsSInvestRequest, HttpServletRequest servletRequest) {
        String approveIPAddress = ClientIPUtil.getClientIp(servletRequest);
        InstructionsSInvestResponse singleApprove = instructionsSInvestService.updateApprove(approveInstructionsSInvestRequest, approveIPAddress);
        ResponseDTO<InstructionsSInvestResponse> response = ResponseDTO.<InstructionsSInvestResponse>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(singleApprove)
                .build();
        return ResponseEntity.ok(response);
    }

    @DeleteMapping(path = "/deleteById")
    public ResponseEntity<ResponseDTO<InstructionsSInvestResponse>> deleteById(@RequestBody DeleteInstructionsSInvestRequest deleteInstructionsSInvestRequest, HttpServletRequest servletRequest) {
        String inputIPAddress = ClientIPUtil.getClientIp(servletRequest);
        PlacementDataChangeDTO placementDataChangeDTO = PlacementDataChangeDTO.builder()
                .inputerId(deleteInstructionsSInvestRequest.getInputerId())
                .inputIPAddress(inputIPAddress)
                .inputDate(LocalDateTime.now())
                .methodHttp(HttpMethod.DELETE.name())
                .endpoint(BASE_URL_S_INVEST + "/delete/approve")
                .isRequestBody(true)
                .isRequestParam(false)
                .isPathVariable(false)
                .menu(MENU_S_INVEST)
                .build();
        InstructionsSInvestResponse deleteSingle = instructionsSInvestService.deleteById(deleteInstructionsSInvestRequest, placementDataChangeDTO);
        ResponseDTO<InstructionsSInvestResponse> response = ResponseDTO.<InstructionsSInvestResponse>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(deleteSingle)
                .build();
        return ResponseEntity.ok(response);
    }

    @DeleteMapping(path = "/delete/approve")
    public ResponseEntity<ResponseDTO<InstructionsSInvestResponse>> deleteApprove(@RequestBody ApproveInstructionsSInvestRequest approveInstructionsSInvestRequest, HttpServletRequest servletRequest) {
        String approveIPAddress = ClientIPUtil.getClientIp(servletRequest);
        InstructionsSInvestResponse singleApprove = instructionsSInvestService.deleteApprove(approveInstructionsSInvestRequest, approveIPAddress);
        ResponseDTO<InstructionsSInvestResponse> response = ResponseDTO.<InstructionsSInvestResponse>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(singleApprove)
                .build();
        return ResponseEntity.ok(response);
    }

    @GetMapping(path = "/{id}")
    public ResponseEntity<ResponseDTO<InstructionsSInvestDTO>> getById(@PathVariable("id") Long id) {
        InstructionsSInvestDTO instructionsSInvestDTO = instructionsSInvestService.getById(id);
        ResponseDTO<InstructionsSInvestDTO> response = ResponseDTO.<InstructionsSInvestDTO>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(instructionsSInvestDTO)
                .build();
        return ResponseEntity.ok(response);
    }

    @GetMapping(path = "/all")
    public ResponseEntity<ResponseDTO<List<InstructionsSInvestDTO>>> getAll() {
        List<InstructionsSInvestDTO> instructionsSInvestDTOList = instructionsSInvestService.getAll();
        ResponseDTO<List<InstructionsSInvestDTO>> response = ResponseDTO.<List<InstructionsSInvestDTO>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(instructionsSInvestDTOList)
                .build();
        return ResponseEntity.ok(response);
    }

}
