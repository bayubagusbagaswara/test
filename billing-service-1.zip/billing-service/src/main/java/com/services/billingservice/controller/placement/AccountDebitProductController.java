package com.services.billingservice.controller.placement;

import com.services.billingservice.dto.ResponseDTO;
import com.services.billingservice.dto.placement.accountdebitproduct.*;
import com.services.billingservice.dto.placement.datachange.PlacementDataChangeDTO;
import com.services.billingservice.service.placement.AccountDebitProductService;
import com.services.billingservice.utils.ClientIPUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping(path = "/api/placement/account-debit-product")
@CrossOrigin(origins = "*", allowedHeaders = "*")
@Slf4j
@RequiredArgsConstructor
public class AccountDebitProductController {

    private static final String BASE_URL_ACCOUNT_DEBIT_PRODUCT = "/api/placement/account-debit-product";
    private static final String MENU_ACCOUNT_DEBIT_PRODUCT = "Account Debit Product";

    private final AccountDebitProductService accountDebitProductService;

    @PostMapping(path = "/upload-data")
    public ResponseEntity<ResponseDTO<AccountDebitProductResponse>> uploadData(@RequestBody UploadAccountDebitProductListRequest uploadAccountDebitProductListRequest, HttpServletRequest servletRequest) {
        String inputIPAddress = ClientIPUtil.getClientIp(servletRequest);
        PlacementDataChangeDTO placementDataChangeDTO = PlacementDataChangeDTO.builder()
                .inputerId(uploadAccountDebitProductListRequest.getInputerId())
                .inputIPAddress(inputIPAddress)
                .inputDate(LocalDateTime.now())
                .isRequestBody(true)
                .isRequestParam(false)
                .isPathVariable(false)
                .menu(MENU_ACCOUNT_DEBIT_PRODUCT)
                .build();

        AccountDebitProductResponse accountDebitProductResponse = accountDebitProductService.uploadData(uploadAccountDebitProductListRequest, placementDataChangeDTO);
        ResponseDTO<AccountDebitProductResponse> response = ResponseDTO.<AccountDebitProductResponse>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(accountDebitProductResponse)
                .build();
        return ResponseEntity.ok(response);
    }

    @PostMapping(path = "/create/approve")
    public ResponseEntity<ResponseDTO<AccountDebitProductResponse>> createApprove(@RequestBody ApproveAccountDebitProductRequest approveAccountDebitProductRequest, HttpServletRequest servletRequest) {
        String approveIPAddress = ClientIPUtil.getClientIp(servletRequest);
        AccountDebitProductResponse accountDebitProductResponse = accountDebitProductService.createApprove(approveAccountDebitProductRequest, approveIPAddress);
        ResponseDTO<AccountDebitProductResponse> response = ResponseDTO.<AccountDebitProductResponse>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(accountDebitProductResponse)
                .build();
        return ResponseEntity.ok(response);
    }

    @PutMapping(path = "/update/approve")
    public ResponseEntity<ResponseDTO<AccountDebitProductResponse>> updateApprove(@RequestBody ApproveAccountDebitProductRequest approveAccountDebitProductRequest, HttpServletRequest servletRequest) {
        String approveIPAddress = ClientIPUtil.getClientIp(servletRequest);
        AccountDebitProductResponse accountDebitProductResponse = accountDebitProductService.updateApprove(approveAccountDebitProductRequest, approveIPAddress);
        ResponseDTO<AccountDebitProductResponse> response = ResponseDTO.<AccountDebitProductResponse>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(accountDebitProductResponse)
                .build();
        return ResponseEntity.ok(response);
    }

    @DeleteMapping(path = "/deleteById")
    public ResponseEntity<ResponseDTO<AccountDebitProductResponse>> deleteById(@RequestBody DeleteAccountDebitProductRequest deleteAccountDebitProductRequest, HttpServletRequest servletRequest) {
        String inputIPAddress = ClientIPUtil.getClientIp(servletRequest);
        PlacementDataChangeDTO placementDataChangeDTO = PlacementDataChangeDTO.builder()
                .inputerId(deleteAccountDebitProductRequest.getInputerId())
                .inputIPAddress(inputIPAddress)
                .inputDate(LocalDateTime.now())
                .methodHttp(HttpMethod.DELETE.name())
                .endpoint(BASE_URL_ACCOUNT_DEBIT_PRODUCT + "/delete/approve")
                .isRequestBody(true)
                .isRequestParam(false)
                .isPathVariable(false)
                .menu(MENU_ACCOUNT_DEBIT_PRODUCT)
                .build();
        AccountDebitProductResponse accountDebitProductResponse = accountDebitProductService.deleteById(deleteAccountDebitProductRequest, placementDataChangeDTO);
        ResponseDTO<AccountDebitProductResponse> response = ResponseDTO.<AccountDebitProductResponse>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(accountDebitProductResponse)
                .build();
        return ResponseEntity.ok(response);
    }

    @DeleteMapping(path = "/delete/approve")
    public ResponseEntity<ResponseDTO<AccountDebitProductResponse>> deleteApprove(@RequestBody ApproveAccountDebitProductRequest approveAccountDebitProductRequest, HttpServletRequest servletRequest) {
        String approveIPAddress = ClientIPUtil.getClientIp(servletRequest);
        AccountDebitProductResponse accountDebitProductResponse = accountDebitProductService.deleteApprove(approveAccountDebitProductRequest, approveIPAddress);
        ResponseDTO<AccountDebitProductResponse> response = ResponseDTO.<AccountDebitProductResponse>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(accountDebitProductResponse)
                .build();
        return ResponseEntity.ok(response);
    }

    @GetMapping(path = "/{id}")
    public ResponseEntity<ResponseDTO<AccountDebitProductDTO>> getById(@PathVariable("id") Long id) {
        AccountDebitProductDTO accountDebitProductDTO = accountDebitProductService.getById(id);
        ResponseDTO<AccountDebitProductDTO> response = ResponseDTO.<AccountDebitProductDTO>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(accountDebitProductDTO)
                .build();
        return ResponseEntity.ok(response);
    }

    @GetMapping(path = "/product-code")
    public ResponseEntity<ResponseDTO<AccountDebitProductDTO>> getByProductCode(@RequestParam("productCode") String productCode) {
        AccountDebitProductDTO accountDebitProductDTO = accountDebitProductService.getByProductCode(productCode);
        ResponseDTO<AccountDebitProductDTO> response = ResponseDTO.<AccountDebitProductDTO>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(accountDebitProductDTO)
                .build();
        return ResponseEntity.ok(response);
    }

    @GetMapping(path = "/all")
    public ResponseEntity<ResponseDTO<List<AccountDebitProductDTO>>> getAll() {
        List<AccountDebitProductDTO> accountDebitProductDTOList = accountDebitProductService.getAll();
        ResponseDTO<List<AccountDebitProductDTO>> response = ResponseDTO.<List<AccountDebitProductDTO>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(accountDebitProductDTOList)
                .build();
        return ResponseEntity.ok(response);
    }

}
