package com.services.billingservice.exception.placement;

public class ReferenceIdAlreadyExists extends RuntimeException {

    public ReferenceIdAlreadyExists() {
    }

    public ReferenceIdAlreadyExists(String message) {
        super(message);
    }

    public ReferenceIdAlreadyExists(String message, Throwable cause) {
        super(message, cause);
    }

}
