package com.services.billingservice.repository;

import com.services.billingservice.model.BillingSellingAgentData;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface BillingSellingAgentDataRepository extends JpaRepository<BillingSellingAgentData, Long> {

    @Query(value = "SELECT * FROM bill_selling_agent_data WHERE code = :code", nativeQuery = true)
    Optional<BillingSellingAgentData> findByCode(@Param("code") String code);

    Boolean existsByCode(String code);
}
