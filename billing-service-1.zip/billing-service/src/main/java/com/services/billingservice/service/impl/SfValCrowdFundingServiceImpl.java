package com.services.billingservice.service.impl;

import com.opencsv.exceptions.CsvException;
import com.services.billingservice.exception.*;
import com.services.billingservice.model.SfValCrowdFunding;
import com.services.billingservice.repository.SfValCrowdFundingRepository;
import com.services.billingservice.service.SfValCrowdFundingService;
import com.services.billingservice.utils.ConvertDateUtil;
import com.services.billingservice.utils.CsvDataMapper;
import com.services.billingservice.utils.CsvReaderUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.IOException;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
@Slf4j
public class SfValCrowdFundingServiceImpl implements SfValCrowdFundingService {

    private static final String BASE_FILE_NAME = "Urun_Dana_";
    private static final DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    private final SfValCrowdFundingRepository sfValCrowdFundingRepository;
    private final ConvertDateUtil convertDateUtil;

    @Override
    public String readAndInsertToDB(String filePath, String monthYear) {
        log.info("Start read and insert SfVal Crowd Funding to the database from file path : {}", filePath);
        try {
            Map<String, String> monthMinus1 = convertDateUtil.getMonthMinus1();
            String monthName = monthMinus1.get("monthName");
            String monthValue = monthMinus1.get("monthValue");
            int year = Integer.parseInt(monthMinus1.get("year"));

            String fileName = BASE_FILE_NAME + year + monthValue + ".csv";
            String filePathNew = filePath + fileName;
            log.info("File path new Urun Dana: {}", filePathNew);

            File file = new File(filePathNew);
            if (!file.exists()) {
                log.error("File not found: {}", filePathNew);
                throw new DataNotFoundException("Urun Dana file not found with path: " + filePathNew);
            }

            sfValCrowdFundingRepository.deleteByMonthAndYear(monthName, year);

            List<String[]> rows = CsvReaderUtil.readCsvFile(filePathNew);
            List<SfValCrowdFunding> sfValCrowdFundingList = CsvDataMapper.mapCsvSfValCrowdFunding(rows);
            sfValCrowdFundingRepository.saveAll(sfValCrowdFundingList);

            return "Urun Dana CSV data processed and saved successfully";
        } catch (DataNotFoundException e) {
            log.error("Urun Dana file not found: {}", e.getMessage(), e);
            throw new DataNotFoundException(e.getMessage());
        } catch (IOException | CsvException e) {
            log.error("Urun Dana failed to process CSV data from file: {}", filePath, e);
            throw new CsvProcessingException("Urun Dana failed to process CSV data: " + e.getMessage());
        } catch (Exception e) {
            log.error("Unexpected error occurred while processing file: {}", filePath, e);
            throw new GeneralException("Unexpected error: " + e.getMessage());
        }
    }

    @Override
    public List<SfValCrowdFunding> getAll() {
        return sfValCrowdFundingRepository.findAll();
    }

    @Override
    public List<SfValCrowdFunding> getAllByClientCodeAndMonthAndYear(String clientCode, String monthName, Integer year) {
        return sfValCrowdFundingRepository.findAllByClientCodeAndMonthAndYear(clientCode, monthName, year);
    }

    @Override
    public String deleteAll() {
        try {
            sfValCrowdFundingRepository.deleteAll();
            return "Successfully deleted all Urun Dana";
        } catch (Exception e) {
            log.error("Error when delete all Urun Dana: {}", e.getMessage(), e);
            throw new UnexpectedException("Error when delete all Urun Dana: " + e.getMessage());
        }
    }

}
