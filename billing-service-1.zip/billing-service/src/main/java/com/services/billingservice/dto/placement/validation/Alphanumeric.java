package com.services.billingservice.dto.placement.validation;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Constraint(validatedBy = AlphanumericValidator.class)
@Target({ ElementType.FIELD, ElementType.METHOD })
@Retention(RetentionPolicy.RUNTIME)
public @interface Alphanumeric {

    String message() default "Code must contain only alphanumeric characters";
    Class<?>[] groups() default {};
    Class<? extends Payload>[] payload() default {};

}
