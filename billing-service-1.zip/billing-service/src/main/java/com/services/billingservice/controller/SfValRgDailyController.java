package com.services.billingservice.controller;

import com.services.billingservice.dto.ResponseDTO;
import com.services.billingservice.model.SfValRgDaily;
import com.services.billingservice.service.SfValRgDailyService;
import com.services.billingservice.utils.ConvertDateUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@Slf4j
@RestController
@RequestMapping(path = "/api/sfval/rg-daily")
@RequiredArgsConstructor
public class SfValRgDailyController {

    @Value("${file.path.sf-val-rg-daily}")
    public String filePath;

    @Value("${file.path.holding.data.csa}")
    private String folderPath;

    private static final String REKAP_ACCOUNT_BALANCE = "REKAP_ACCOUNT_BALANCE";
    private static final String CSV_EXT = ".csv";
    private static final String UNDERSCORE_SEPARATOR = "_";
    private static final String PATH_SEPARATOR = "\\";

    private final SfValRgDailyService rgDailyService;
    private final ConvertDateUtil convertDateUtil;

    @GetMapping(path = "/read-insert")
    public ResponseEntity<ResponseDTO<String>> readAndInsert(@RequestParam("monthYear") String monthYear) {
        String status = rgDailyService.readFileAndInsertToDB(filePath, monthYear);
        ResponseDTO<String> response = ResponseDTO.<String>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(status)
                .build();
        return ResponseEntity.ok().body(response);
    }

    @GetMapping(path = "/all")
    public ResponseEntity<ResponseDTO<List<SfValRgDaily>>> getAll() {
        List<SfValRgDaily> sfValRgDailyList = rgDailyService.getAll();
        ResponseDTO<List<SfValRgDaily>> response = ResponseDTO.<List<SfValRgDaily>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(sfValRgDailyList)
                .build();
        return ResponseEntity.ok().body(response);
    }

    @GetMapping(path = "/period")
    public ResponseEntity<ResponseDTO<List<SfValRgDaily>>> getAllByPeriod(@RequestParam("month") String month, @RequestParam("year") Integer year) {
        List<SfValRgDaily> sfValRgDailyList = rgDailyService.findByMonthAndYear(month, year);
        ResponseDTO<List<SfValRgDaily>> response = ResponseDTO.<List<SfValRgDaily>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(sfValRgDailyList)
                .build();
        return ResponseEntity.ok().body(response);
    }

    @GetMapping(path = "/aid")
    public ResponseEntity<ResponseDTO<List<SfValRgDaily>>> getAllByAid(@RequestParam("aid") String aid) {
        List<SfValRgDaily> sfValRgDailyList = rgDailyService.getAllByAid(aid);
        ResponseDTO<List<SfValRgDaily>> response = ResponseDTO.<List<SfValRgDaily>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(sfValRgDailyList)
                .build();
        return ResponseEntity.ok().body(response);
    }

    @GetMapping(path = "/aid/period")
    public ResponseEntity<ResponseDTO<List<SfValRgDaily>>> getAllByAidAndPeriod(@RequestParam("aid") String aid, @RequestParam("month") String month, @RequestParam("year") Integer year) {
        List<SfValRgDaily> sfValRgDailyList = rgDailyService.findByAidAndMonthAndYearOrderByAidAscSecurityNameAscDateAsc(aid, month, year);
        ResponseDTO<List<SfValRgDaily>> response = ResponseDTO.<List<SfValRgDaily>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(sfValRgDailyList)
                .build();
        return ResponseEntity.ok().body(response);
    }

    @GetMapping(path = "/retail/aid/period")
    public ResponseEntity<ResponseDTO<List<SfValRgDaily>>> getAllRetailByAidAndTypeAndCurrencyAndPeriod(
            @RequestParam("customerCode") String customerCode,
            @RequestParam("aid") String aid,
            @RequestParam("typeRetail") String typeRetail,
            @RequestParam("currency") String currency,
            @RequestParam("month") String month,
            @RequestParam("year") Integer year) {

        String monthYearFormat = month + " " + year;
        LocalDate date = convertDateUtil.getFirstDateOfMonthYear(monthYearFormat);
        List<SfValRgDaily> sfValRgDailyList = rgDailyService.getAllRetailByAidAndTypeAndCurrencyAndPeriod(customerCode, aid, typeRetail, currency, date);
        ResponseDTO<List<SfValRgDaily>> response = ResponseDTO.<List<SfValRgDaily>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(sfValRgDailyList)
                .build();
        return ResponseEntity.ok().body(response);
    }

    @GetMapping(path = "/retail/list-aid/period")
    public ResponseEntity<ResponseDTO<List<String>>> getRetailAidByTypeAndCurrencyAndPeriod(
            @RequestParam("typeRetail") String typeRetail,
            @RequestParam("currency") String currency,
            @RequestParam("month") String month,
            @RequestParam("year") Integer year) {

        String monthYearFormat = month + " " + year;
        LocalDate date = convertDateUtil.getFirstDateOfMonthYear(monthYearFormat);
        List<String> listAid = rgDailyService.getRetailAidByTypeAndCurrencyAndPeriod(typeRetail, currency, date);
        ResponseDTO<List<String>> response = ResponseDTO.<List<String>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(listAid)
                .build();
        return ResponseEntity.ok().body(response);
    }

    @GetMapping(path = "/retail/download-csa-holding")
    public ResponseEntity<ResponseDTO<byte[]>> downloadCsaHolding(
            @RequestParam("typeRetail") String typeRetail,
            @RequestParam("currency") String currency,
            @RequestParam("month") String month,
            @RequestParam("year") Integer year) {

        Map<String, String> stringStringMap = convertDateUtil.extractMonthYearInformation(month + " " + year);
        final String monthValue = stringStringMap.get("monthValue");
        final String folderStr = folderPath + year + monthValue;
        final String fileName = REKAP_ACCOUNT_BALANCE + UNDERSCORE_SEPARATOR + typeRetail + UNDERSCORE_SEPARATOR + currency + UNDERSCORE_SEPARATOR + year + monthValue + CSV_EXT;

        try {
            Path folder = Paths.get(folderStr);
            Path fullPath = Paths.get(folderStr + PATH_SEPARATOR + fileName);
            if (!Files.isDirectory(folder) || !Files.exists(fullPath)) {
                log.error("File not found with path : {}", folder);
                return ResponseEntity
                        .status(HttpStatus.NO_CONTENT)
                        .body(ResponseDTO.<byte[]>builder()
                                .code(HttpStatus.NOT_FOUND.value())
                                .message("File Download : " + HttpStatus.NOT_FOUND.getReasonPhrase())
                                .payload(null)
                                .build());
            }

            byte[] byteArray = Files.readAllBytes(fullPath);
//            InputStreamResource resource = new InputStreamResource(new ByteArrayInputStream(byteArray));
//            InputStreamResource resource = new InputStreamResource(new FileInputStream(fullPath.toFile()));
            HttpHeaders headers = new HttpHeaders();
            headers.setContentDisposition(ContentDisposition.attachment().filename(fileName).build());
            headers.setContentType(MediaType.APPLICATION_JSON);
            log.info("Success download file with path : {}", folder);

            ResponseDTO<byte[]> response = ResponseDTO.<byte[]>builder()
                    .code(HttpStatus.OK.value())
                    .message(fileName)
//                    .payload(resource)
                    .payload(byteArray)
                    .build();
            return ResponseEntity.ok().body(response);
        } catch (Exception e) {
            log.error("Failed download file with error : {}", e.getMessage());
            return ResponseEntity
                    .status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(ResponseDTO.<byte[]>builder()
                            .code(HttpStatus.INTERNAL_SERVER_ERROR.value())
                            .message(HttpStatus.NOT_FOUND.getReasonPhrase())
                            .payload(null)
                            .build());
        }
    }

    @GetMapping(path = "/aid/security-name")
    public ResponseEntity<ResponseDTO<List<SfValRgDaily>>> getAllByAidAndSecurityName(@RequestParam("aid") String aid, @RequestParam("securityName") String securityName) {
        List<SfValRgDaily> sfValRgDailyList = rgDailyService.getAllByAidAndSecurityName(aid, securityName);
        ResponseDTO<List<SfValRgDaily>> response = ResponseDTO.<List<SfValRgDaily>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(sfValRgDailyList)
                .build();
        return ResponseEntity.ok().body(response);
    }

    @GetMapping(path = "/aid/security-name/period")
    public ResponseEntity<ResponseDTO<List<SfValRgDaily>>> getAllByAidAndSecurityName(@RequestParam("aid") String aid, @RequestParam("securityName") String securityName, @RequestParam("month") String month, @RequestParam("year") Integer year) {
        List<SfValRgDaily> sfValRgDailyList = rgDailyService.findByAidAndSecurityNameAndMonthAndYear(aid, securityName, month, year);
        ResponseDTO<List<SfValRgDaily>> response = ResponseDTO.<List<SfValRgDaily>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(sfValRgDailyList)
                .build();
        return ResponseEntity.ok().body(response);
    }

    @GetMapping(path = "/aid/date")
    public ResponseEntity<ResponseDTO<List<SfValRgDaily>>> getAllByAidAndDate(@RequestParam("aid") String aid, @RequestParam("date") String date) {
        List<SfValRgDaily> sfValRgDailyList = rgDailyService.getAllByAidAndDate(aid, date);
        ResponseDTO<List<SfValRgDaily>> response = ResponseDTO.<List<SfValRgDaily>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(sfValRgDailyList)
                .build();
        return ResponseEntity.ok().body(response);
    }

    @DeleteMapping
    public ResponseEntity<ResponseDTO<String>> deleteAll() {
        String status = rgDailyService.deleteAll();
        ResponseDTO<String> response = ResponseDTO.<String>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(status)
                .build();
        return ResponseEntity.ok().body(response);
    }

    @GetMapping(path = "/recap/period")
    public ResponseEntity<ResponseDTO<List<SfValRgDaily>>> getRecapByPeriod(@RequestParam("month") String month, @RequestParam("year") Integer year) {
        String monthYearFormat = month + " " + year;
        List<SfValRgDaily> sfValRgDailyList = rgDailyService.findRecapByMonthAndYear(month, year);
        ResponseDTO<List<SfValRgDaily>> response = ResponseDTO.<List<SfValRgDaily>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(sfValRgDailyList)
                .build();
        return ResponseEntity.ok().body(response);
    }

    @GetMapping(path = "/recap/aid/period")
    public ResponseEntity<ResponseDTO<List<SfValRgDaily>>> getRecapByAidAndPeriod(@RequestParam("aid") String aid, @RequestParam("month") String month, @RequestParam("year") Integer year) {
        String monthYearFormat = month + " " + year;
        List<SfValRgDaily> sfValRgDailyList = rgDailyService.findRecapByAidAndMonthAndYear(aid, month, year);
        ResponseDTO<List<SfValRgDaily>> response = ResponseDTO.<List<SfValRgDaily>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(sfValRgDailyList)
                .build();
        return ResponseEntity.ok().body(response);
    }

}
