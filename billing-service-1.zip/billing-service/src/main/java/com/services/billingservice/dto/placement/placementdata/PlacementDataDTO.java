package com.services.billingservice.dto.placement.placementdata;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PlacementDataDTO {

    private Long id;

    private String inputId;

    private String inputIPAddress;

    private LocalDateTime createdDate;

    private String imCode;

    private String imName;

    private String fundCode;

    private String fundName;

    private String placementBankCode;

    private String placementBankName;

    private String placementBankCashAccountName;

    private String placementBankCashAccountNo;

    private String currency;

    private String principle;

    private String placementDate; // yyyyMMdd

    private String referenceNo;

    private String siReferenceId;

    private String accountDebitNo;

    private String biCode;

    private String bankType;

    private String branchCode;

    private String productCode;

    private String description;

    private String placementType;

    private String placementApprovalId;

    private String placementApprovalStatus;

    private String placementProcessType;

    private String placementTransferType;
}
