package com.services.billingservice.service;

import com.services.billingservice.dto.assettransfercustomer.*;
import com.services.billingservice.dto.datachange.BillingDataChangeDTO;

import java.util.List;

public interface AssetTransferCustomerService {

    AssetTransferCustomerResponse createSingleData(CreateAssetTransferCustomerRequest createAssetTransferCustomerRequest, BillingDataChangeDTO dataChangeDTO);

    AssetTransferCustomerResponse createSingleApprove(AssetTransferCustomerApproveRequest approveRequest, String clientIP);

    AssetTransferCustomerResponse updateSingleData(UpdateAssetTransferCustomerRequest updateAssetTransferCustomerRequest, BillingDataChangeDTO dataChangeDTO);

    AssetTransferCustomerResponse updateSingleApprove(AssetTransferCustomerApproveRequest approveRequest, String clientIP);

    AssetTransferCustomerResponse deleteSingleData(DeleteAssetTransferCustomerRequest deleteAssetTransferCustomerRequest, BillingDataChangeDTO dataChangeDTO);

    AssetTransferCustomerResponse deleteSingleApprove(AssetTransferCustomerApproveRequest deleteAssetTransferCustomerListRequest, String clientIP);

    String deleteAll();

    List<AssetTransferCustomerDTO> getAll();

    AssetTransferCustomerDTO getById(Long Id);

    List<AssetTransferCustomerDTO> getAllByCustomerCode(String code);
}
