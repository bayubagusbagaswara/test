package com.services.billingservice.exception;

public class CalculateBillingException extends RuntimeException {

    public CalculateBillingException() {
    }

    public CalculateBillingException(String message) {
        super(message);
    }

    public CalculateBillingException(String message, Throwable cause) {
        super(message, cause);
    }

}
