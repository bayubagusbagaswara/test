package com.services.billingservice.mapper.placement;

import com.services.billingservice.dto.placement.accountdebitproduct.AccountDebitProductDTO;
import com.services.billingservice.dto.placement.accountdebitproduct.UploadAccountDebitProductDataRequest;
import com.services.billingservice.model.placement.AccountDebitProduct;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

import java.util.List;

/**
 * productCode
 * fundCode
 * fundName
 * imCode
 * imName
 * currency
 * cashAccount
 * bank
 */
@Mapper(componentModel = "spring")
public interface AccountDebitProductMapper {

    @Mapping(source = "id",target = "id")
    AccountDebitProductDTO toDTO(AccountDebitProduct accountDebitProduct);

    @Mapping(target = "id", ignore = true)
    @Mapping(target = "productCode", source = "productCode", qualifiedByName = "nullToEmpty")
    @Mapping(target = "fundCode", source = "fundCode", qualifiedByName = "nullToEmpty")
    @Mapping(target = "imCode", source = "imCode", qualifiedByName = "nullToEmpty")
    @Mapping(target = "imName", source = "imName", qualifiedByName = "nullToEmpty")
    @Mapping(target = "currency", source = "currency", qualifiedByName = "nullToEmpty")
    @Mapping(target = "cashAccount", source = "cashAccount", qualifiedByName = "nullToEmpty")
    @Mapping(target = "bankName", source = "bankName", qualifiedByName = "nullToEmpty")
    AccountDebitProductDTO fromUploadRequestToDTO(UploadAccountDebitProductDataRequest uploadAccountDebitProductDataRequest);

    @Named("nullToEmpty")
    default String nullToEmpty(String value) { return null == value ? "" : value; }

    List<AccountDebitProductDTO> toDTOList(List<AccountDebitProduct> all);
}
