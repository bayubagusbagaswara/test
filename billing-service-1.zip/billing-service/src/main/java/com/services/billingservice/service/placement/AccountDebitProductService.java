package com.services.billingservice.service.placement;

import com.services.billingservice.dto.placement.accountdebitproduct.*;
import com.services.billingservice.dto.placement.datachange.PlacementDataChangeDTO;
import com.services.billingservice.model.placement.AccountDebitProduct;

import java.util.List;

public interface AccountDebitProductService {

    boolean isProductCodeAlreadyExists(String productCode);

    AccountDebitProductResponse uploadData(UploadAccountDebitProductListRequest uploadAccountDebitProductListRequest, PlacementDataChangeDTO placementDataChangeDTO);

    AccountDebitProductResponse createApprove(ApproveAccountDebitProductRequest approveAccountDebitProductRequest, String approveIPAddress);

    AccountDebitProductResponse updateApprove(ApproveAccountDebitProductRequest approveAccountDebitProductRequest, String approveIPAddress);

    AccountDebitProductResponse deleteById(DeleteAccountDebitProductRequest deleteAccountDebitProductRequest, PlacementDataChangeDTO placementDataChangeDTO);

    AccountDebitProductResponse deleteApprove(ApproveAccountDebitProductRequest approveAccountDebitProductRequest, String approveIPAddress);

    AccountDebitProductDTO getById(Long id);

    AccountDebitProductDTO getByProductCode(String productCode);

    List<AccountDebitProductDTO> getAll();

    AccountDebitProduct findByFundCode(String fundCode);

}
