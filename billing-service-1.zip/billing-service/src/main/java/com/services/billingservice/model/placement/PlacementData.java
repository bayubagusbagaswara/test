package com.services.billingservice.model.placement;

import lombok.*;

import javax.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "placement_data")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PlacementData {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "input_id")
    private String inputId;

    @Column(name = "input_ip_address")
    private String inputIPAddress;

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Column(name = "im_code")
    private String imCode;

    @Column(name = "im_name")
    private String imName;

    @Column(name = "fund_code")
    private String fundCode;

    @Column(name = "fund_name")
    private String fundName;

    @Column(name = "placement_bank_code")
    private String placementBankCode;

    @Column(name = "placement_bank_name")
    private String placementBankName;

    @Column(name = "placement_bank_cash_account_name")
    private String placementBankCashAccountName;

    @Column(name = "placement_bank_cash_account_no")
    private String placementBankCashAccountNo;

    @Column(name = "currency")
    private String currency;

    @Column(name = "principle")
    private BigDecimal principle;

    @Column(name = "placement_date")
    private LocalDate placementDate;

    @Column(name = "reference_no")
    private String referenceNo;

    @Column(name = "si_reference_id")
    private String siReferenceId;

    @Column(name = "account_debit_no")
    private String accountDebitNo;

    @Column(name = "product_code")
    private String productCode;

    @Column(name = "bi_code")
    private String biCode;

    @Column(name = "bank_type")
    private String bankType;

    @Column(name = "branch_code")
    private String branchCode;

    @Column(name = "description")
    private String description;

    @Column(name = "placement_type")
    private String placementType; // External or Internal

    @Column(name = "placement_approval_id")
    private String placementApprovalId;

    @Column(name = "placement_approval_status")
    private String placementApprovalStatus;

}
