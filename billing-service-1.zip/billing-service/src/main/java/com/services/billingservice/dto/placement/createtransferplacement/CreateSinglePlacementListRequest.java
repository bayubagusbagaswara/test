package com.services.billingservice.dto.placement.createtransferplacement;

import com.services.billingservice.dto.approval.InputIdentifierRequest;
import lombok.*;
import lombok.experimental.SuperBuilder;

import java.util.List;

@EqualsAndHashCode(callSuper = true)
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class CreateSinglePlacementListRequest extends InputIdentifierRequest {

    private List<CreateSinglePlacementRequest> createSinglePlacementRequestList;

}
