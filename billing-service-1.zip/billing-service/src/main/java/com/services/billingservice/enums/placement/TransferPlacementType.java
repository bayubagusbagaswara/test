package com.services.billingservice.enums.placement;

import lombok.Getter;

@Getter
public enum TransferPlacementType {

    BI_FAST("BI-FAST"),

    SKN("SKN"),

    RTGS("RTGS"),

    OVERBOOKING("OVERBOOKING");

    public final String transferTypeName;

    TransferPlacementType(String transferTypeName) {
        this.transferTypeName = transferTypeName;
    }

    public static TransferPlacementType fromTransferTypeName(String name) {
        for (TransferPlacementType type : TransferPlacementType.values()) {
            if (type.transferTypeName.equalsIgnoreCase(name)) {
                return type;
            }
        }
        throw new IllegalArgumentException("Invalid transfer type name: " + name);
    }

}
