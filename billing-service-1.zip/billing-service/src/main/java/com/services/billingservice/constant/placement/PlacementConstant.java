package com.services.billingservice.constant.placement;

import lombok.experimental.UtilityClass;

@UtilityClass
public class PlacementConstant {

    public static final String S_INVEST_CREATE_APPROVE_URL = "/api/placement/sinvest/create/approve";
    public static final String S_INVEST_UPDATE_APPROVE_URL = "/api/placement/sinvest/update/approve";
    public static final String S_INVEST_ID_NOT_FOUND = "Instruction S-Invest not found with id: ";
    public static final String S_INVEST_UNKNOWN_SI_REFERENCE_ID = "Unknown SI Reference Id";

    public static final String API_RESPONSE_CODE_SUCCESS = "200R000000";

    public static final String PLACEMENT_BANK_CODE_DANAMON = "0011";
    public static final String PLACEMENT_TYPE_EXTERNAL = "External";
    public static final String PLACEMENT_TYPE_INTERNAL = "Internal";
    public static final String NCBS_STATUS_FAILED = "FAILED";
    public static final String NCBS_STATUS_SUCCESS = "SUCCESS";

    public static final String BI_FAST = "BI-FAST";
    public static final String SKN = "SKN";
    public static final String RTGS = "RTGS";

    public static final String PLACEMENT_TYPE_BULK = "BULK";
    public static final String PLACEMENT_TYPE_SINGLE = "SINGLE";

    public static final String INSUFFICIENT_BALANCE = "INSUFFICIENT_BALANCE";

    public static final String RERUN = "RERUN";

    public static final String BDI_KEY = "BDI-Key";
    public static final String BDI_EXTERNAL_ID = "BDI-External-ID";
    public static final String BDI_TIMESTAMP = "BDI-Timestamp";
    public static final String BDI_CHANNEL = "BDI-Channel";
    public static final String BDI_SERVICE_CODE = "BDI-Service-Code";
    public static final String BDI_SIGNATURE = "BDI-Signature";

    public static final String INQUIRY_ACCOUNT = "INQUIRY_ACCOUNT";
    public static final String CREDIT_TRANSFER = "CREDIT_TRANSFER";
    public static final String OVERBOOKING_CASA = "OVERBOOKING_CASA";
    public static final String TRANSFER_SKN_RTGS = "TRANSFER_SKN_RTGS";
    public static final String PAYMENT_STATUS = "PAYMENT_STATUS";

    // **INQUIRY ACCOUNT */
    public static final String URI_INQUIRY_ACCOUNT_TIMEOUT = "http://localhost:8081/inquiry-account-timeout";
    public static final String URI_INQUIRY_ACCOUNT_SUCCESS = "http://localhost:8081/inquiry-account-success";

    // **CREDIT TRANSFER */
    public static final String URI_CREDIT_TRANSFER_SUCCESS = "http://localhost:8081/credit-transfer-success";
    public static final String URI_CREDIT_TRANSFER_DUPLICATE_REF_NUMBER = "http://localhost:8081/credit-transfer-duplicate-ref-number";
    public static final String URL_CREDIT_TRANSFER_CHECKING_ACCOUNT_NOT_REGISTERED = "http://localhost:8081/credit-transfer-account-not-registered";

    // **OVERBOOKING CASA */
    public static final String URI_OVERBOOKING_CASA_SUCCESS = "http://localhost:8081/overbooking-casa-success";

    // **TRANSFER SKN & RTGS */
    public static final String URI_TRANSFER_SKN_RTGS_SUCCESS = "http://localhost:8081/transfer-skn-rtgs-success";

    // untuk menangkap Header Response
    public static final String CORRELATION_ID = "X-CorrelationID";
    public static final String CHANNEL_ID = "channelid";
    public static final String DATE = "date";
    public static final String PROVIDER_SYSTEM = "providerSystem";
    public static final String SERVICE_CODE = "svccode";
    public static final String SERVICE_REQUEST_ID = "svcrqid";

}
