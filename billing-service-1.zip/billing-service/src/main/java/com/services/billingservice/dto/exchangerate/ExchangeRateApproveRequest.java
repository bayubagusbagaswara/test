package com.services.billingservice.dto.exchangerate;

import com.services.billingservice.dto.approval.ApprovalIdentifierRequest;
import lombok.*;
import lombok.experimental.SuperBuilder;

@EqualsAndHashCode(callSuper = true)
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class ExchangeRateApproveRequest extends ApprovalIdentifierRequest {

    private String dataChangeId;

}
