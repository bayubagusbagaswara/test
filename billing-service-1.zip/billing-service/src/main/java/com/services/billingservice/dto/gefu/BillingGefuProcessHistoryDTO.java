package com.services.billingservice.dto.gefu;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BillingGefuProcessHistoryDTO {

    private Long id;

    private String customerCode;
    private String billingPeriode;
    private String category;
    private String type;
    private String fileName;

    private Long failure;
    private Long pending;
    private Long success;

}
