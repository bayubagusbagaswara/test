package com.services.billingservice.dto.fund;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.time.Instant;

@Data
@SuperBuilder
@NoArgsConstructor
public class BillingFundListProcessDTO {
    private String month;
    private Integer year;
    private Instant createdAt;
}
