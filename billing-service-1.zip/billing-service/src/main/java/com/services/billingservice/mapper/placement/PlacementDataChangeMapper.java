package com.services.billingservice.mapper.placement;

import com.services.billingservice.dto.placement.datachange.PlacementDataChangeDTO;
import com.services.billingservice.model.placement.PlacementDataChange;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface PlacementDataChangeMapper {

    PlacementDataChangeDTO toDTO(PlacementDataChange placementDataChange);

    @Mapping(source = "isRequestBody", target = "isRequestBody")
    @Mapping(source = "isRequestParam", target = "isRequestParam")
    @Mapping(source = "isPathVariable", target = "isPathVariable")
    PlacementDataChange toModel(PlacementDataChangeDTO placementDataChangeDTO);

}
