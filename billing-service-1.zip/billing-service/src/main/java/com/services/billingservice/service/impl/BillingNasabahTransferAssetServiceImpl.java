package com.services.billingservice.service.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.services.billingservice.dto.ErrorMessageDTO;
import com.services.billingservice.dto.assettransfercustomer.*;
import com.services.billingservice.dto.datachange.BillingDataChangeDTO;
import com.services.billingservice.exception.DataNotFoundException;
import com.services.billingservice.mapper.AssetTransferCustomerMapper;
import com.services.billingservice.model.BillingNasabahTransferAsset;
import com.services.billingservice.repository.BillingNasabahTransferAssetRepository;
import com.services.billingservice.service.BillingDataChangeService;
import com.services.billingservice.service.BillingNasabahTransferAssetService;
import com.services.billingservice.utils.JsonUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

@Service
@RequiredArgsConstructor
@Slf4j
public class BillingNasabahTransferAssetServiceImpl implements BillingNasabahTransferAssetService {

    private static final String ID_NOT_FOUND = "Nasabah Transfer Asset not found with id: ";
    private static final String CODE_NOT_FOUND = "Nasabah Transfer Asset not found with code: ";
    private static final String UNKNOWN = "unknown";

    private final BillingNasabahTransferAssetRepository assetTransferCustomerRepository;
    private final BillingDataChangeService dataChangeService;
    private final Validator validator;
    private final ObjectMapper objectMapper;
    private final AssetTransferCustomerMapper assetTransferCustomerMapper;

    @Override
    public AssetTransferCustomerResponse createSingleData(CreateAssetTransferCustomerRequest createRequest, BillingDataChangeDTO dataChangeDTO) {
        log.info("Create single data asset transfer customer with request: {}", createRequest);
        AssetTransferCustomerDTO assetTransferCustomerDTO = assetTransferCustomerMapper.mapCreateRequestToDto(createRequest);
        dataChangeDTO.setInputerId(createRequest.getInputerId());
        dataChangeDTO.setInputerIPAddress(createRequest.getInputerIPAddress());
        return processAssetTransferCustomerCreation(assetTransferCustomerDTO, dataChangeDTO);
    }

    private AssetTransferCustomerResponse processAssetTransferCustomerCreation(AssetTransferCustomerDTO assetTransferCustomerDTO, BillingDataChangeDTO dataChangeDTO) {
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageList = new ArrayList<>();

        try {
            List<String> validationErrors = new ArrayList<>();
            Errors errors = validateAssetTransferCustomerUsingValidator(assetTransferCustomerDTO);
            if (errors.hasErrors()) {
                errors.getAllErrors().forEach(error -> validationErrors.add(error.getDefaultMessage()));
            }

            if (!validationErrors.isEmpty()) {
                ErrorMessageDTO errorMessageDTO = new ErrorMessageDTO(assetTransferCustomerDTO.getId().toString(), validationErrors);
                errorMessageList.add(errorMessageDTO);
                totalDataFailed++;
            } else {
                dataChangeDTO.setInputerId(dataChangeDTO.getInputerId());
                dataChangeDTO.setInputerIPAddress(dataChangeDTO.getInputerIPAddress());
                dataChangeDTO.setJsonDataAfter(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(assetTransferCustomerDTO)));

                dataChangeService.createChangeActionADD(dataChangeDTO, BillingNasabahTransferAsset.class);
                totalDataSuccess++;
            }
        } catch (Exception e) {
            handleGeneralError(assetTransferCustomerDTO, e, errorMessageList);
            totalDataFailed++;
        }

        return new AssetTransferCustomerResponse(totalDataSuccess, totalDataFailed, errorMessageList);
    }

    @Override
    public AssetTransferCustomerResponse createSingleApprove(AssetTransferCustomerApproveRequest approveRequest) {
        log.info("Approve when create investment management with request: {}", approveRequest);
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageList = new ArrayList<>();

        validateDataChangeId(approveRequest.getDataChangeId());
        AssetTransferCustomerDTO assetTransferCustomerDTO = approveRequest.getData();
        try {
            Long dataChangeId = Long.valueOf(approveRequest.getDataChangeId());
            List<String> errorMessages = new ArrayList<>();

            BillingDataChangeDTO dataChangeDTO = dataChangeService.getById(dataChangeId);

            Errors errors = validateAssetTransferCustomerUsingValidator(assetTransferCustomerDTO);
            if (errors.hasErrors()) {
                errors.getAllErrors().forEach(objectError -> errorMessages.add(objectError.getDefaultMessage()));
            }

            dataChangeDTO.setApproverId(approveRequest.getApproverId());
            dataChangeDTO.setApproverIPAddress(approveRequest.getApproverIPAddress());

            if (!errorMessages.isEmpty()) {
                dataChangeDTO.setJsonDataAfter(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(assetTransferCustomerDTO)));
                dataChangeService.approvalStatusIsRejected(dataChangeDTO, errorMessages);
                totalDataFailed++;
            } else {
                BillingNasabahTransferAsset assetTransferCustomer = assetTransferCustomerMapper.createEntity(assetTransferCustomerDTO, dataChangeDTO);
                BillingNasabahTransferAsset assetTransferCustomerSaved = assetTransferCustomerRepository.save(assetTransferCustomer);

                dataChangeDTO.setDescription("Successfully approve data change and save data asset transfer customer");
                dataChangeDTO.setJsonDataAfter(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(assetTransferCustomerSaved)));
                dataChangeDTO.setEntityId(assetTransferCustomer.getId().toString());
                dataChangeService.approvalStatusIsApproved(dataChangeDTO);
                totalDataSuccess++;
            }
        } catch (Exception e) {
            handleGeneralError(assetTransferCustomerDTO, e, errorMessageList);
            totalDataFailed++;
        }
        return new AssetTransferCustomerResponse(totalDataSuccess, totalDataFailed, errorMessageList);
    }

    @Override
    public AssetTransferCustomerResponse updateSingleData(UpdateAssetTransferCustomerRequest updateRequest, BillingDataChangeDTO dataChangeDTO) {
        log.info("Update single data asset transfer customer with request: {}", updateRequest);
        dataChangeDTO.setInputerId(updateRequest.getInputerId());
        dataChangeDTO.setInputerIPAddress(updateRequest.getInputerIPAddress());
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageList = new ArrayList<>();

        AssetTransferCustomerDTO assetTransferCustomerDTO = assetTransferCustomerMapper.mapUpdateRequestToDto(updateRequest);
        try {
            BillingNasabahTransferAsset assetTransferCustomer = assetTransferCustomerRepository.findById(assetTransferCustomerDTO.getId())
                    .orElseThrow(() -> new DataNotFoundException(ID_NOT_FOUND + assetTransferCustomerDTO.getId()));

            AtomicInteger successCounter = new AtomicInteger(totalDataSuccess);
            AtomicInteger failedCounter = new AtomicInteger(totalDataFailed);

            processUpdateAssetTransferCustomer(assetTransferCustomer, assetTransferCustomerDTO, dataChangeDTO, errorMessageList, successCounter, failedCounter);

            totalDataSuccess = successCounter.get();
            totalDataFailed = failedCounter.get();
        } catch (Exception e) {
            handleGeneralError(assetTransferCustomerDTO, e, errorMessageList);
            totalDataFailed++;
        }
        return new AssetTransferCustomerResponse(totalDataSuccess, totalDataFailed, errorMessageList);
    }

    @Override
    public AssetTransferCustomerResponse updateMultipleData(AssetTransferCustomerListRequest updateListRequest, BillingDataChangeDTO dataChangeDTO) {
        log.info("Update multiple data asset transfer customer with request: {}", updateListRequest);
        dataChangeDTO.setInputerId(updateListRequest.getInputerId());
        dataChangeDTO.setInputerIPAddress(updateListRequest.getInputerIPAddress());
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageList = new ArrayList<>();

        for (AssetTransferCustomerDTO assetTransferCustomerDTO : updateListRequest.getAssetTransferCustomerDTOList()) {
          try {
              BillingNasabahTransferAsset assetTransferCustomer = assetTransferCustomerRepository.findById(assetTransferCustomerDTO.getId())
                      .orElseThrow(() -> new DataNotFoundException(ID_NOT_FOUND + assetTransferCustomerDTO.getId()));

                AtomicInteger successCounter = new AtomicInteger(totalDataSuccess);
                AtomicInteger failedCounter = new AtomicInteger(totalDataFailed);

                processUpdateAssetTransferCustomer(assetTransferCustomer, assetTransferCustomerDTO, dataChangeDTO, errorMessageList, successCounter, failedCounter);

                totalDataSuccess = successCounter.get();
                totalDataFailed = failedCounter.get();
            } catch (Exception e) {
                handleGeneralError(assetTransferCustomerDTO, e, errorMessageList);
                totalDataFailed++;
            }
        }
        return new AssetTransferCustomerResponse(totalDataSuccess, totalDataFailed, errorMessageList);
    }

    private void processUpdateAssetTransferCustomer(BillingNasabahTransferAsset assetTransferCustomer,
                                          AssetTransferCustomerDTO assetTransferCustomerDTO,
                                          BillingDataChangeDTO dataChangeDTO,
                                          List<ErrorMessageDTO> errorMessageList,
                                          AtomicInteger successCounter,
                                          AtomicInteger failedCounter) {
        try {
            List<String> validationErrors = new ArrayList<>();
            Errors errors = validateAssetTransferCustomerUsingValidator(assetTransferCustomerDTO);
            if (errors.hasErrors()) {
                errors.getAllErrors().forEach(error -> validationErrors.add(error.getDefaultMessage()));
            }

            if (!validationErrors.isEmpty()) {
                ErrorMessageDTO errorMessageDTO = new ErrorMessageDTO(assetTransferCustomerDTO.getId().toString(), validationErrors);
                errorMessageList.add(errorMessageDTO);
                failedCounter.incrementAndGet();
            } else {
                dataChangeDTO.setInputerId(dataChangeDTO.getInputerId());
                dataChangeDTO.setInputerIPAddress(dataChangeDTO.getInputerIPAddress());
                dataChangeDTO.setJsonDataBefore(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(assetTransferCustomerMapper.mapToDto(assetTransferCustomer))));
                dataChangeDTO.setJsonDataAfter(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(assetTransferCustomerDTO)));
                dataChangeDTO.setEntityId(assetTransferCustomer.getId().toString());

                dataChangeService.createChangeActionEDIT(dataChangeDTO, BillingNasabahTransferAsset.class);
                successCounter.incrementAndGet(); // Increment totalDataSuccess
            }
        } catch (Exception e) {
            handleGeneralError(assetTransferCustomerDTO, e, errorMessageList);
            failedCounter.incrementAndGet(); // Increment totalDataFailed
        }
    }

    @Override
    public AssetTransferCustomerResponse updateSingleApprove(AssetTransferCustomerApproveRequest approveRequest) {
        log.info("Approve when update asset transfer customer with request: {}", approveRequest);
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageList = new ArrayList<>();

        validateDataChangeId(approveRequest.getDataChangeId());
        AssetTransferCustomerDTO assetTransferCustomerDTO = approveRequest.getData();

        try {
            Long dataChangeId = Long.valueOf(approveRequest.getDataChangeId());
            List<String> validationErrors = new ArrayList<>();

            Errors errors = validateAssetTransferCustomerUsingValidator(assetTransferCustomerDTO);
            if (errors.hasErrors()) {
                errors.getAllErrors().forEach(error -> validationErrors.add(error.getDefaultMessage()));
            }

            BillingNasabahTransferAsset assetTransferCustomer = assetTransferCustomerRepository.findById(assetTransferCustomerDTO.getId())
                    .orElseThrow(() -> new DataNotFoundException(ID_NOT_FOUND + assetTransferCustomerDTO.getId()));

            // Copy data from DTO to Entity
            assetTransferCustomerMapper.mapObjectsDtoToEntity(assetTransferCustomerDTO, assetTransferCustomer);
            log.info("Fee Schedule after copy properties: {}", assetTransferCustomer);

            // Retrieve and set billing data change
            BillingDataChangeDTO dataChangeDTO = dataChangeService.getById(dataChangeId);
            dataChangeDTO.setApproverId(approveRequest.getApproverId());
            dataChangeDTO.setApproverIPAddress(approveRequest.getApproverIPAddress());
            dataChangeDTO.setEntityId(assetTransferCustomer.getId().toString());

            if (!validationErrors.isEmpty()) {
                dataChangeDTO.setJsonDataAfter(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(assetTransferCustomerDTO)));
                dataChangeService.approvalStatusIsRejected(dataChangeDTO, validationErrors);
                totalDataFailed++;
            } else {
                BillingNasabahTransferAsset assetTransferCustomerUpdated = assetTransferCustomerMapper.updateEntity(assetTransferCustomer, dataChangeDTO);
                BillingNasabahTransferAsset assetTransferCustomerSaved = assetTransferCustomerRepository.save(assetTransferCustomerUpdated);

                dataChangeDTO.setJsonDataAfter(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(assetTransferCustomerSaved)));
                dataChangeDTO.setDescription("Successfully approve data change and update data entity");
                dataChangeService.approvalStatusIsApproved(dataChangeDTO);
                totalDataSuccess++;
            }
        } catch (Exception e) {
            handleGeneralError(assetTransferCustomerDTO, e, errorMessageList);
            totalDataFailed++;
        }
        return new AssetTransferCustomerResponse(totalDataSuccess, totalDataFailed, errorMessageList);
    }

    @Override
    public AssetTransferCustomerResponse deleteSingleData(DeleteAssetTransferCustomerRequest deleteRequest, BillingDataChangeDTO dataChangeDTO) {
        log.info("Delete single asset transfer customer with request: {}", deleteRequest);
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageList = new ArrayList<>();

        AssetTransferCustomerDTO assetTransferCustomerDTO = AssetTransferCustomerDTO.builder()
                .id(deleteRequest.getId())
                .build();
        try {
            BillingNasabahTransferAsset assetTransferCustomer = assetTransferCustomerRepository.findById(assetTransferCustomerDTO.getId())
                    .orElseThrow(() -> new DataNotFoundException(ID_NOT_FOUND + assetTransferCustomerDTO.getId()));

            dataChangeDTO.setInputerId(deleteRequest.getInputerId());
            dataChangeDTO.setInputerIPAddress(deleteRequest.getInputerIPAddress());
            dataChangeDTO.setJsonDataBefore(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(assetTransferCustomer)));
            dataChangeDTO.setJsonDataAfter("");
            dataChangeDTO.setEntityId(assetTransferCustomer.getId().toString());

            dataChangeService.createChangeActionDELETE(dataChangeDTO, BillingNasabahTransferAsset.class);
            totalDataSuccess++;
        } catch (Exception e) {
            handleGeneralError(assetTransferCustomerDTO, e, errorMessageList);
            totalDataFailed++;
        }
        return new AssetTransferCustomerResponse(totalDataSuccess, totalDataFailed, errorMessageList);
    }

    @Override
    public AssetTransferCustomerResponse deleteSingleApprove(AssetTransferCustomerApproveRequest approveRequest) {
        log.info("Approve when delete asset transfer customer with request: {}", approveRequest);
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageList = new ArrayList<>();

        validateDataChangeId(approveRequest.getDataChangeId());
        AssetTransferCustomerDTO assetTransferCustomerDTO = approveRequest.getData();
        BillingDataChangeDTO dataChangeDTO = dataChangeService.getById(Long.valueOf(approveRequest.getDataChangeId()));
        try {
            BillingNasabahTransferAsset assetTransferCustomer = assetTransferCustomerRepository.findById(assetTransferCustomerDTO.getId())
                    .orElseThrow(() -> new DataNotFoundException(ID_NOT_FOUND + assetTransferCustomerDTO.getId()));

            dataChangeDTO.setApproverId(approveRequest.getApproverId());
            dataChangeDTO.setApproverIPAddress(approveRequest.getApproverIPAddress());
            dataChangeDTO.setJsonDataBefore(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(assetTransferCustomer)));
            dataChangeDTO.setDescription("Successfully approve data change and delete data entity");

            dataChangeService.approvalStatusIsApproved(dataChangeDTO);
            assetTransferCustomerRepository.delete(assetTransferCustomer);
            totalDataSuccess++;

        } catch (DataNotFoundException e) {
            handleDataNotFoundException(assetTransferCustomerDTO, e, errorMessageList);
            dataChangeDTO.setApproverId(approveRequest.getApproverId());
            dataChangeDTO.setApproverIPAddress(approveRequest.getApproverIPAddress());
            List<String> validationErrors = new ArrayList<>();
            validationErrors.add(ID_NOT_FOUND + assetTransferCustomerDTO.getId());

            dataChangeService.approvalStatusIsRejected(dataChangeDTO, validationErrors);
            totalDataFailed++;
        } catch (Exception e) {
            handleGeneralError(assetTransferCustomerDTO, e, errorMessageList);
            totalDataFailed++;
        }
        return new AssetTransferCustomerResponse(totalDataSuccess, totalDataFailed, errorMessageList);
    }

    @Override
    public String deleteAll() {
        assetTransferCustomerRepository.deleteAll();
        return "Successfully delete all Asset Transfer Customer";
    }

    @Override
    public List<AssetTransferCustomerDTO> getAll() {
        List<BillingNasabahTransferAsset> all = assetTransferCustomerRepository.findAll();
        List<AssetTransferCustomerDTO> assetTransferCustomerDTO = assetTransferCustomerMapper.mapToDTOList(all);
        return assetTransferCustomerDTO;
    }

    @Override
    public List<AssetTransferCustomerDTO> getByCode(String code) {
        List<BillingNasabahTransferAsset> billingNasabahTransferAsset = assetTransferCustomerRepository.findByCustomerCode(code)
                .orElseThrow(() -> new DataNotFoundException(CODE_NOT_FOUND + code));
        List<AssetTransferCustomerDTO> assetTransferCustomerDTO = assetTransferCustomerMapper.mapToDTOList(billingNasabahTransferAsset);
        return assetTransferCustomerDTO;
    }

    @Override
    public AssetTransferCustomerDTO getById(Long id) {
        BillingNasabahTransferAsset billingNasabahTransferAsset = assetTransferCustomerRepository.findById(id)
                .orElseThrow(() -> new DataNotFoundException(ID_NOT_FOUND + id));
        AssetTransferCustomerDTO assetTransferCustomerDTO = assetTransferCustomerMapper.mapToDto(billingNasabahTransferAsset);
        return assetTransferCustomerDTO;
    }

    private Errors validateAssetTransferCustomerUsingValidator(AssetTransferCustomerDTO dto) {
        Errors errors = new BeanPropertyBindingResult(dto, "assetTransferCustomerDTO");
        validator.validate(dto, errors);
        return errors;
    }

    private void validateDataChangeId(String dataChangeId) {
        if (!dataChangeService.existById(Long.valueOf(dataChangeId))) {
            log.info("Data Change not found with id: {}", dataChangeId);
            throw new DataNotFoundException("Data Change id not found with id: " + dataChangeId);
        }
    }

    private void handleDataNotFoundException(AssetTransferCustomerDTO assetTransferCustomerDTO, DataNotFoundException e, List<ErrorMessageDTO> errorMessageList) {
        log.error("Asset Transfer Customer not found with id: {}", assetTransferCustomerDTO != null ? assetTransferCustomerDTO.getId() : UNKNOWN, e);
        List<String> validationErrors = new ArrayList<>();
        validationErrors.add(e.getMessage());
        errorMessageList.add(new ErrorMessageDTO(assetTransferCustomerDTO!= null ? String.valueOf(assetTransferCustomerDTO.getId()) : UNKNOWN, validationErrors));
    }

    private void handleGeneralError(AssetTransferCustomerDTO assetTransferCustomerDTO, Exception e, List<ErrorMessageDTO> errorMessageList) {
        log.error("An unexpected error occurred: {}", e.getMessage(), e);
        List<String> validationErrors = new ArrayList<>();
        validationErrors.add("An unexpected error occurred: " + e.getMessage());
        errorMessageList.add(new ErrorMessageDTO(assetTransferCustomerDTO != null ? String.valueOf(assetTransferCustomerDTO.getId()) : UNKNOWN, validationErrors));
    }
}
