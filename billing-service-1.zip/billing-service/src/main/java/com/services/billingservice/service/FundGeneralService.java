package com.services.billingservice.service;

import com.services.billingservice.dto.core.CoreCalculateRequest;
import com.services.billingservice.dto.fund.BillingFundDTO;
import com.services.billingservice.dto.fund.BillingFundListProcessDTO;
import com.services.billingservice.dto.fund.UpdateApprovalStatusBillingFundRequest;
import com.services.billingservice.dto.fund.UpdateBillingFundRequest;

import java.util.List;

public interface FundGeneralService {

    String updateApprovalStatus(UpdateApprovalStatusBillingFundRequest request);

    String deleteByCategoryAndTypeAndMonthYear(CoreCalculateRequest request);

    List<BillingFundDTO> updateAll(List<UpdateBillingFundRequest> requestList);

    List<BillingFundDTO> getAll();

    List<BillingFundListProcessDTO> getAllListProcess();

    List<BillingFundListProcessDTO> getAllListPendingApprove();

    List<BillingFundDTO> findByMonthAndYear(String month, Integer year);

    List<BillingFundDTO> findByMonthAndYearAndBillingCategoryAndBillingType(String month, Integer year, String category, String type);

    List<BillingFundDTO> findByMonthAndYearAndBillingCategoryAndBillingTypeAndCustomerCode(String month, Integer year, String category, String type, String customerCode);

    String deleteAll();

    List<BillingFundDTO> getAllByCategoryAndMonthYearAndApprovalStatusIsApproved(String category, String monthYear);

    List<BillingFundDTO> getAllWithAmountGreaterThan5Billion(String category, String monthYear);
}
