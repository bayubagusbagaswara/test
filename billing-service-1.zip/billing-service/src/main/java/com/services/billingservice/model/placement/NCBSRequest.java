package com.services.billingservice.model.placement;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "placement_ncbs_request")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class NCBSRequest {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Column(name = "placement_id")
    private String placementId;

    @Column(name = "si_reference_id")
    private String siReferenceId;

    @Column(name = "placement_type")
    private String placementType;

    @Column(name = "placement_process_type")
    private String placementProcessType;

    @Column(name = "placement_transfer_type")
    private String placementTransferType;

    @Lob
    @Column(name = "request_json", columnDefinition = "nvarchar(max)")
    private String requestJson;

    @Column(name = "reference_id")
    private String referenceId;

    @Column(name = "service_type")
    private String serviceType; // INQUIRY_ACCOUNT, CREDIT_TRANSFER, OVERBOOKING_CASA, TRANSFER_SKN_RTGS

    @Column(name = "pay_user_ref_no")
    private String payUserRefNo;
}
