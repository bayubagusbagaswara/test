package com.services.billingservice.repository.placement;

import com.services.billingservice.enums.ApprovalStatus;
import com.services.billingservice.model.placement.PlacementDataChange;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PlacementDataChangeRepository extends JpaRepository<PlacementDataChange, Long> {

    @Query(value = "SELECT CASE WHEN COUNT(*) = :listSize THEN true ELSE false END " +
            "FROM PlacementDataChange WHERE id IN :idList and approvalStatus = :status")
    Boolean existsByIdListAndStatus(
            @Param("idList") List<Long> idList,
            @Param("listSize") Long listSize,
            @Param("status")ApprovalStatus approvalStatus
    );

    List<PlacementDataChange> findByMenuAndApprovalStatus(String menu, ApprovalStatus approvalStatus);

    List<PlacementDataChange> findAllByApprovalStatus(String approvalStatus);

    @Query(value = "SELECT DISTINCT menu FROM placement_data_change WHERE ISNULL(menu, '') != '' AND menu NOT LIKE %:menuFilter% ORDER BY menu ASC", nativeQuery = true)
    List<String> findAllMenuNotLike(@Param("menuFilter") String menuFilter);

    @Query(value = "SELECT DISTINCT menu FROM placement_data_change WHERE ISNULL(menu, '') != '' AND menu LIKE %:menuFilter% ORDER BY menu ASC", nativeQuery = true)
    List<String> findAllMenuLike(@Param("menuFilter") String menuFilter);

    @Query(value = "SELECT DISTINCT menu FROM placement_data_change WHERE ISNULL(menu, '') != '' ORDER BY menu ASC", nativeQuery = true)
    List<String> findAllMenu();

}
