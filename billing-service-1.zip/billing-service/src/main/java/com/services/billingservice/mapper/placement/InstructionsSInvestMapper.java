package com.services.billingservice.mapper.placement;

import com.services.billingservice.dto.placement.instructionsinvest.InstructionsSInvestDTO;
import com.services.billingservice.dto.placement.instructionsinvest.UploadInstructionsSInvestDataRequest;
import com.services.billingservice.model.placement.InstructionsSInvest;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.regex.Pattern;

@Mapper(componentModel = "spring")
public interface InstructionsSInvestMapper {

    Pattern DIGIT_PATTERN = Pattern.compile("\\D");

    @Mapping(source = "id", target = "id")
    @Mapping(source = "principle", target = "principle", qualifiedByName = "bigDecimalToString")
    @Mapping(source = "placementDate", target = "placementDate", qualifiedByName = "localDateToString")
    InstructionsSInvestDTO toDTO(InstructionsSInvest instructionsSInvest);

    @Mapping(target = "id", ignore = true)
    @Mapping(target = "imCode", source = "imCode", qualifiedByName = "nullToEmpty")
    @Mapping(target = "imName", source = "imName", qualifiedByName = "nullToEmpty")
    @Mapping(target = "fundCode", source = "fundCode", qualifiedByName = "nullToEmpty")
    @Mapping(target = "fundName", source = "fundName", qualifiedByName = "nullToEmpty")
    @Mapping(target = "placementBankCode", source = "placementBankCode", qualifiedByName = "nullToEmpty")
    @Mapping(target = "placementBankName", source = "placementBankName", qualifiedByName = "nullToEmpty")
    @Mapping(target = "placementBankCashAccountName", source = "placementBankCashAccountName", qualifiedByName = "nullToEmpty")
    @Mapping(target = "placementBankCashAccountNo", source = "placementBankCashAccountNo", qualifiedByName = "removeSymbol")
    @Mapping(target = "currency", source = "currency", qualifiedByName = "nullToEmpty")
    @Mapping(target = "principle", source = "principle", qualifiedByName = "nullToEmpty")
    @Mapping(target = "placementDate", source = "placementDate", qualifiedByName = "nullToEmpty")
    @Mapping(target = "referenceNo", source = "referenceNo", qualifiedByName = "nullToEmpty")
    @Mapping(target = "siReferenceId", source = "siReferenceId", qualifiedByName = "nullToEmpty")
    InstructionsSInvestDTO fromUploadRequestToDTO(UploadInstructionsSInvestDataRequest uploadInstructionsSInvestDataRequest);

    @Named("nullToEmpty")
    default String nullToEmpty(String value) {
        return null == value ? "" : value;
    }

    @Named("removeSymbol")
    default String removeSymbol(String value) {
        return value.replaceAll(String.valueOf(DIGIT_PATTERN), "");
    }

    @Named("bigDecimalToString")
    default String bigDecimalToString(BigDecimal value) {
        return value != null ? value.toPlainString() : null;
    }

    @Named("localDateToString")
    default String localDateToString(LocalDate localDate) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd");
        LocalDate date = LocalDate.parse(localDate.toString());
        return date.format(formatter); // Format LocalDate to yyyyMMdd
    }

    List<InstructionsSInvestDTO> toDTOList(List<InstructionsSInvest> all);

}
