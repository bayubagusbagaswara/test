package com.services.billingservice.dto.feeschedule;

import com.services.billingservice.dto.approval.InputIdentifierRequest;
import lombok.*;
import lombok.experimental.SuperBuilder;

import javax.validation.constraints.NotBlank;

@EqualsAndHashCode(callSuper = true)
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class UpdateFeeScheduleRequest extends InputIdentifierRequest {

    private Long id;

    private String feeMinimum;

    private String feeMaximum;

    private String feeAmount;
}
