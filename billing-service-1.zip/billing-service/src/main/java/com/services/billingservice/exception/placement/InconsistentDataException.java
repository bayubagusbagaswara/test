package com.services.billingservice.exception.placement;

public class InconsistentDataException extends RuntimeException {

    public InconsistentDataException() {
    }

    public InconsistentDataException(String message) {
        super(message);
    }

    public InconsistentDataException(String message, Throwable cause) {
        super(message, cause);
    }
}
