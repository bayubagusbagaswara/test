package com.services.billingservice.service.impl;

import com.services.billingservice.enums.BillingCategory;
import com.services.billingservice.enums.BillingType;
import com.services.billingservice.enums.FeeParameter;
import com.services.billingservice.exception.GeneralException;
import com.services.billingservice.exception.UnexpectedException;
import com.services.billingservice.model.BillingCustomer;
import com.services.billingservice.model.SfValCoreIIG;
import com.services.billingservice.repository.SfValCoreIIGRepository;
import com.services.billingservice.service.BillingCustomerService;
import com.services.billingservice.service.BillingFeeParameterService;
import com.services.billingservice.service.SfValCoreIIGService;
import com.services.billingservice.utils.ConvertDateUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class SfValCoreIIGServiceImpl implements SfValCoreIIGService {

    private static final String CORE_IIG_GROUP = "IIG";
    private static final String TOTAL_HOLDING = "TOTAL_HOLDING";
    private static final String PRICE_TRUB = "PRICE_TRUB";

    private final SfValCoreIIGRepository sfValCoreIIGRepository;
    private final BillingCustomerService customerService;
    private final BillingFeeParameterService feeParameterService;
    private final ConvertDateUtil convertDateUtil;

    @Override
    public String create() {
        int totalDataSuccess = 0;

        // get from Parameter
        List<BillingCustomer> customerList = customerService.getAllByBillingCategoryAndBillingType(BillingCategory.CORE.getValue(), BillingType.TYPE_8.getValue());

        for (BillingCustomer customer : customerList) {
            try {
                String customerCode = customer.getCustomerCode();
                String customerName = customer.getCustomerName();

                /* get data parameter total holding and TRUB */
                String feeParameterTotalHolding = customerCode + "_" + TOTAL_HOLDING;
                String feeParameterPriceTRUB = customerCode + "_" + PRICE_TRUB;
                BigDecimal totalHolding = feeParameterService.getValueByName(feeParameterTotalHolding);
                BigDecimal priceTRUB = feeParameterService.getValueByName(feeParameterPriceTRUB);
                String priceTRUBString = priceTRUB.stripTrailingZeros().toPlainString();

                BigDecimal safeFee = feeParameterService.getValueByName(FeeParameter.SAFEKEEPING_FEE_IIG.getValue());

                BigDecimal totalMarketValue = calculateTotalMarketValue(totalHolding, Integer.valueOf(priceTRUBString));
                BigDecimal safekeepingFee = calculateSafekeepingFee(totalMarketValue, safeFee);

                List<SfValCoreIIG> sfValCoreIIGList = new ArrayList<>();

                for (int i = 1; i <= 31; i++) {
                    SfValCoreIIG sfvalCoreIIG = SfValCoreIIG.builder()
                            .customerCode(customerCode)
                            .customerCodeGroup(CORE_IIG_GROUP)
                            .customerName(customerName)
                            .date(i)
                            .totalHolding(totalHolding)
                            .priceTRUB(Integer.valueOf(priceTRUBString))
                            .totalMarketValue(totalMarketValue)
                            .safekeepingFee(safekeepingFee)
                            .build();

                    sfValCoreIIGList.add(sfvalCoreIIG);
                }

                // save all to the database
                List<SfValCoreIIG> sfValCoreIIGListSaved = sfValCoreIIGRepository.saveAll(sfValCoreIIGList);
                log.info("Total data customer code: {} is {}", customerCode, sfValCoreIIGListSaved.size());
                totalDataSuccess++;
            } catch (Exception e) {
                log.error("Error when create data core IIG: ", e.getMessage(), e);
                throw new GeneralException("Error when create data core IIG: " + e.getMessage());
            }
        }
        return "Successfully created sfVal Core IIG with total: " + totalDataSuccess;
    }

    @Override
    public List<SfValCoreIIG> getAll() {
        log.info("Start get all SfVal Core IIG");
        return sfValCoreIIGRepository.findAll();
    }

    @Override
    public List<SfValCoreIIG> getAllByCustomerCode(String customerCode) {
        log.info("Start get all SfVal Core IIG by customer code: {}", customerCode);
        return sfValCoreIIGRepository.findAllByCustomerCode(customerCode);
    }

    @Override
    public List<SfValCoreIIG> getAllByAidAndMonthAndYear(String aid, String monthName, Integer year) {
        log.info("Start get all SfVal Core IIG by customer code: {}, month: {}, and year: {}", aid, monthName, year);
        List<SfValCoreIIG> sfValCoreIIGList = sfValCoreIIGRepository.findAllByCustomerCode(aid);

        String monthYearFormat = monthName + " " + year;
        LocalDate lastDate = convertDateUtil.getLatestDateOfMonthYear(monthYearFormat);

        int dayOfMonth = lastDate.getDayOfMonth();

        return sfValCoreIIGList.stream()
                .limit(dayOfMonth)
                .collect(Collectors.toList());
    }

    @Override
    public String deleteAll() {
        try {
            sfValCoreIIGRepository.deleteAll();
            return "Successfully deleted all SfVal Core IIG";
        } catch (Exception e) {
            log.error("Error when delete all SfVal Core IIG: {}", e.getMessage(), e);
            throw new UnexpectedException("Error when delete all SfVal Core IIG: " + e.getMessage());
        }
    }

    private static BigDecimal calculateTotalMarketValue(BigDecimal totalHolding, Integer priceTRUB) {
        BigDecimal totalMarketValue = totalHolding
                .multiply(new BigDecimal(priceTRUB))
                .setScale(0, RoundingMode.HALF_UP);
        log.info("[SfVal Core IIG] Total market value: {}", totalMarketValue);
        return totalMarketValue;
    }

    private static BigDecimal calculateSafekeepingFee(BigDecimal totalMarketValue, BigDecimal safeFee) {
        BigDecimal safekeepingFeeDivide = safeFee.divide(new BigDecimal(100), 5, RoundingMode.HALF_UP);
        return totalMarketValue
                .multiply(safekeepingFeeDivide)
                .divide(new BigDecimal(365), 2, RoundingMode.HALF_UP);
    }

}
