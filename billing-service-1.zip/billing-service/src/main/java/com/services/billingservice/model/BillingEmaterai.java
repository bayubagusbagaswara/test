package com.services.billingservice.model;

import com.services.billingservice.model.base.Approvable;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "billing_ematerai")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class BillingEmaterai extends Approvable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "customer_code")
    private String customerCode;

    @Column(name = "security_code")
    private String securityCode;

    @Column(name = "period")
    private String period;
}
