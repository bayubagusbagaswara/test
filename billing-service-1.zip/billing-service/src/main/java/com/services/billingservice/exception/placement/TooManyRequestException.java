package com.services.billingservice.exception.placement;

import lombok.Getter;

import java.time.Instant;
import java.time.LocalDateTime;

@Getter
public class TooManyRequestException extends RuntimeException {

    private final int retryAfterSeconds;
    private final int queuePosition;
    private final Instant timestamp;

    public TooManyRequestException(int retryAfterSeconds, int queuePosition, Instant timestamp) {
        this.retryAfterSeconds = retryAfterSeconds;
        this.queuePosition = queuePosition;
        this.timestamp = timestamp;
    }

    public TooManyRequestException(String message, int retryAfterSeconds, int queuePosition, Instant timestamp) {
        super(message);
        this.retryAfterSeconds = retryAfterSeconds;
        this.queuePosition = queuePosition;
        this.timestamp = timestamp;
    }

    public TooManyRequestException(String message, Throwable cause, int retryAfterSeconds, int queuePosition, Instant timestamp) {
        super(message, cause);
        this.retryAfterSeconds = retryAfterSeconds;
        this.queuePosition = queuePosition;
        this.timestamp = timestamp;
    }

    public TooManyRequestException(int retryAfterSeconds, int queuePosition) {
        super(String.format(
                "System sedang memproses request lain. " +
                        "Coba lagi dalam %d detik. " +
                        "Posisi antrian: %d. " +
                        "Timestamp: %s",
                retryAfterSeconds,
                queuePosition,
                LocalDateTime.now()
        ));
        this.retryAfterSeconds = retryAfterSeconds;
        this.queuePosition = queuePosition;
        this.timestamp = Instant.now();
    }

}
