package com.services.billingservice.dto.retail;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RetailTemplate4IDR {

    private BigDecimal safekeepingValueFrequency;
    private BigDecimal safekeepingFee;
    private BigDecimal safekeepingAmountDue;

    private BigDecimal vatFee;
    private BigDecimal vatAmountDue;

    private BigDecimal subTotal;

    private Integer transferValueFrequency;
    private BigDecimal transferFee;
    private BigDecimal transferAmountDue;

    private BigDecimal totalAmountDue;
}
