package com.services.billingservice.repository.placement;

import com.services.billingservice.model.placement.PlacementData;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface PlacementDataRepository extends JpaRepository<PlacementData, Long> {

    @Query("SELECT p FROM PlacementData p WHERE p.placementDate = :date")
    List<PlacementData> findByPlacementDate(@Param("date") LocalDate date);

    List<PlacementData> findByPlacementApprovalId(String placementApprovalId);

    @Query("SELECT p FROM PlacementData p WHERE p.placementDate = :placementDate AND p.placementApprovalStatus = :status")
    List<PlacementData> findByPlacementDateAndApprovalStatus(
            @Param("placementDate") LocalDate placementDate,
            @Param("status") String status);

    @Transactional
    @Modifying
    @Query(value = "DELETE FROM PlacementData p WHERE p.placementDate = :placementDate AND (p.placementApprovalStatus IS NULL OR p.placementApprovalStatus = :status)")
    void deleteByPlacementDateAndApprovalStatus(
            @Param("placementDate") LocalDate placementDate,
            @Param("status") String status);

    @Query("SELECT p FROM PlacementData p WHERE p.placementDate = :date AND placementType = :placementType")
    List<PlacementData> findByPlacementDateAndPlacementType(@Param("date") LocalDate date,
                                                            @Param("placementType") String placementType);

    @Query("SELECT CASE WHEN COUNT(*) = 1 THEN true ELSE false END FROM PlacementData " +
            "WHERE siReferenceId = :siReferenceId " +
            "AND ISNULL(placementApprovalId, '') = :placementApprovalId ")
    Boolean findBySiReferenceIdAndPlacementApprovalId(@Param("siReferenceId") String siReferenceId,
                                                      @Param("placementApprovalId") String placementApprovalId);

    @Query("SELECT CASE WHEN COUNT(*) = :countSiReferenceIdList THEN true ELSE false END FROM PlacementData " +
            "WHERE siReferenceId IN :siReferenceIdList " +
            "AND ISNULL(placementApprovalId, '') = :placementApprovalId ")
    Boolean findBySiReferenceIdInAndPlacementApprovalId(@Param("siReferenceIdList") List<String> siReferenceIdList,
                                                        @Param("placementApprovalId") String placementApprovalId,
                                                        @Param("countSiReferenceIdList") Integer countSiReferenceIdList);
}
