package com.services.billingservice.dto.placement.validation;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class NumericValidator implements ConstraintValidator<NumericOnly, String> {

    @Override
    public boolean isValid(String value, ConstraintValidatorContext constraintValidatorContext) {
        if (value == null) {
            return true; // Jika null valid, jika tidak ubah menjadi false
        }
        String trim = value.trim();
        return trim.matches("^\\d*$"); // hanya angka diperbolehkan
    }

}
