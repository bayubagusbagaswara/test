package com.services.billingservice.model;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import javax.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;

@Entity
@Table(name = "rekap_account_balance")
@Data
@SuperBuilder
@NoArgsConstructor
public class RekapAccountBalance {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "year")
    private Integer year;

    @Column(name = "month")
    private String month; // February

    @Column(name = "as_of")
    private LocalDate asOf;

    @Column(name = "aid")
    private String aid; // or portfolio code

    @Column(name = "selling_agent")
    private String sellingAgent;

    @Column(name = "security_group")
    private String securityGroup;

    @Column(name = "security_code")
    private String securityCode;

    @Column(name = "currency")
    private String currency;

    @Column(name = "name")
    private String name;

    @Column(name = "balance", precision = 19, scale = 5)
    private BigDecimal balance;

    @Column(name = "cif_number")
    private String cifNumber;

    @Column(name = "fee", precision = 19, scale = 5)
    private BigDecimal Fee;
}
