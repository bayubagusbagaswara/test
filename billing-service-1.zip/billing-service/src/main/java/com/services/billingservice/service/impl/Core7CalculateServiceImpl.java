package com.services.billingservice.service.impl;

import com.services.billingservice.dto.billing.BillingCalculationErrorMessageDTO;
import com.services.billingservice.dto.billing.BillingCalculationResponse;
import com.services.billingservice.dto.billing.BillingContextDate;
import com.services.billingservice.dto.core.CoreCalculateRequest;
import com.services.billingservice.dto.core.CoreTemplate2;
import com.services.billingservice.dto.core.CoreType7Parameter;
import com.services.billingservice.dto.mi.InvestmentManagementDTO;
import com.services.billingservice.enums.*;
import com.services.billingservice.exception.DataNotFoundException;
import com.services.billingservice.model.*;
import com.services.billingservice.repository.BillingCoreRepository;
import com.services.billingservice.service.*;
import com.services.billingservice.utils.ConvertDateUtil;
import com.services.billingservice.utils.StringUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

import static com.services.billingservice.enums.FeeParameter.BILLING_PAYMENT_DUE_DATE;
import static com.services.billingservice.enums.FeeParameter.KSEI;
import static com.services.billingservice.enums.FeeParameter.VAT;

@Slf4j
@Service
@RequiredArgsConstructor
public class Core7CalculateServiceImpl implements Core7CalculateService {

    private final BillingCustomerService customerService;
    private final BillingFeeParameterService feeParameterService;
    private final SkTranService skTransactionService;
    private final SfValRgMonthlyService sfValRgMonthlyService;
    private final KseiSafeService kseiSafekeepingFeeService;
    private final BillingNumberService billingNumberService;
    private final BillingCoreRepository billingCoreRepository;
    private final BillingFeeScheduleService feeScheduleService;
    private final BillingMIService investmentManagementService;
    private final ConvertDateUtil convertDateUtil;

    @Override
    public synchronized String calculate(CoreCalculateRequest request) {
        log.info("Start core billing calculation type 7 with a data request: {}", request);

        /* initialize response data */
        Integer totalDataSuccess = 0;
        Integer totalDataFailed = 0;
        List<BillingCalculationErrorMessageDTO> errorMessageList = new ArrayList<>();

        /* initialize data request */
        Instant dateNow = Instant.now();
        String categoryUpperCase = request.getCategory().toUpperCase();
        String typeUpperCase = StringUtil.replaceBlanksWithUnderscores(request.getType());

        /* generate billing context date */
        BillingContextDate contextDate = convertDateUtil.getBillingContextDate(dateNow);

        /* get previous month and year */
        String[][] previousMonthsAndYears = convertDateUtil.getPreviousMonthsAndYears(contextDate.getMonthNameMinus1(), contextDate.getYearMinus1());

        /* initialize temporary data for sk transaction, rg monthly, and ksei amount fee */
        List<List<SkTransaction>> skTransactionsList = new ArrayList<>();
        List<List<SfValRgMonthly>> sfValRgMonthliesList = new ArrayList<>();
        List<BigDecimal> kseiAmountFeeList = new ArrayList<>();

        /* get data fee parameters */
        String paymentDueDate = feeParameterService.getFeeDescriptionByName(BILLING_PAYMENT_DUE_DATE.getValue());
        BigDecimal vatFee = feeParameterService.getValueByName(VAT.getValue());
        BigDecimal kseiTransactionFee = feeParameterService.getValueByName(KSEI.getValue());
        String customerCode12MUFG = feeParameterService.getFeeDescriptionByName(FeeParameter.CUSTOMER_CODE_12MUFG.getValue());

        /* get all customer Core Type 3 */
        List<BillingCustomer> customerList = customerService.getAllByBillingCategoryAndBillingType(categoryUpperCase, typeUpperCase);

        String customerCode = null;

        try {
            for (BillingCustomer customer : customerList) {
                customerCode = customer.getCustomerCode();
                String kseiSafeCode = customer.getKseiSafeCode();

                for (String[] previousMonthsAndYear : previousMonthsAndYears) {
                    String monthInput = previousMonthsAndYear[0];
                    Integer yearInput = Integer.parseInt(previousMonthsAndYear[1]);

                    /* Get SfValRgMonthly Month [i] and Year [i] */
                    List<SfValRgMonthly> sfValRgMonthlyList = sfValRgMonthlyService.getAllByAidAndMonthAndYear(customerCode, monthInput, yearInput);
                    sfValRgMonthliesList.add(sfValRgMonthlyList);

                    /* Get KSEI Safe Fee Month [i] and Year [i] */
                    BigDecimal kseiSafekeepingFeeAmount = BigDecimal.ZERO;
                    if (!"0".equalsIgnoreCase(customer.getKseiSafeCode())) {
                        KseiSafekeepingFee kseiSafekeepingFee = kseiSafekeepingFeeService.getByKseiSafeCodeAndMonthAndYear(kseiSafeCode, monthInput, yearInput);
                        kseiSafekeepingFeeAmount = kseiSafekeepingFee.getAmountFee();
                    }
                    kseiAmountFeeList.add(kseiSafekeepingFeeAmount);
                }

                /* Get SK Transaction Month [i] and Year [i] */
                List<SkTransaction> skTransactionList = skTransactionService.getAllByAidAndMonthAndYear(customerCode, contextDate.getMonthNameMinus1(), contextDate.getYearMinus1());
                skTransactionsList.add(skTransactionList);
            }

            /* get data dari billing customer list, filter by customerCode is 12MUFG */
            BillingCustomer customer12MUFG = customerList.stream()
                    .filter(data -> data.getCustomerCode().equalsIgnoreCase(customerCode12MUFG))
                    .findFirst()
                    .orElseThrow(() -> new DataNotFoundException("Customer not found with customer code: " + customerCode12MUFG));

            /* get data investment management */
            InvestmentManagementDTO investmentManagementDTO = investmentManagementService.getByCode(customer12MUFG.getMiCode());

            /* create billing core */
            BillingCore billingCore = createBillingCore(contextDate, customer12MUFG, investmentManagementDTO, previousMonthsAndYears, paymentDueDate);

            /* create parameter core type 7 */
            CoreType7Parameter coreType7Parameter = new CoreType7Parameter(
                    customer12MUFG.getCustomerSafekeepingFee(),
                    skTransactionsList, sfValRgMonthliesList, kseiAmountFeeList,
                    vatFee, kseiTransactionFee);

            /* calculation billing */
            CoreTemplate2 coreTemplate2 = calculationResult(coreType7Parameter);

            /* update billing core data to include calculated values */
            updateBillingCoreForTemplate2(billingCore, coreTemplate2);

            /* create a billing number then set it to the billing core */
            String number = billingNumberService.generateSingleNumber(contextDate.getMonthNameNow(), contextDate.getYearNow());
            billingCore.setBillingNumber(number);

            /* get billing data to check whether the data is in the database or not */
            Optional<BillingCore> existingBillingCore = billingCoreRepository.findByCustomerCodeAndSubCodeAndBillingCategoryAndBillingTypeAndMonthAndYear(
                    customer12MUFG.getCustomerCode(), customer12MUFG.getSubCode(), customer12MUFG.getBillingCategory(), customer12MUFG.getBillingType(), contextDate.getMonthNameMinus1(), contextDate.getYearMinus1());

            /* check paid status. if it is FALSE, it can be regenerated */
            if (!existingBillingCore.isPresent() || Boolean.TRUE.equals(!existingBillingCore.get().getPaid())) {

                /* delete billing data if it exists in the database */
                existingBillingCore.ifPresent(this::deleteExistingBillingCore);

                /* save to the database */
                billingCoreRepository.save(billingCore);
                billingNumberService.saveSingleNumber(number);
                totalDataSuccess++;
            } else {
                addErrorMessage(errorMessageList, customer12MUFG.getCustomerCode(), "Billing already paid for period " + contextDate.getMonthNameMinus1() + " " + contextDate.getYearMinus1());
                totalDataFailed++;
            }
        } catch (Exception e) {
            handleGeneralError(customerCode, e, errorMessageList);
            totalDataFailed++;
        }
        log.info("Total successfully calculations: {}, total failed calculations: {}", totalDataSuccess, totalDataFailed);
        BillingCalculationResponse billingCalculationResponse = new BillingCalculationResponse(totalDataSuccess, totalDataFailed, errorMessageList);
        return "Total successful calculations: " + billingCalculationResponse.getTotalDataSuccess() + ", total failed calculations: " + billingCalculationResponse.getTotalDataFailed();
    }

    private void updateBillingCoreForTemplate2(BillingCore billingCore, CoreTemplate2 coreTemplate2) {
        billingCore.setSafekeepingValueFrequency(coreTemplate2.getSafekeepingValueFrequency());
        billingCore.setSafekeepingFee(coreTemplate2.getSafekeepingFee());
        billingCore.setSafekeepingAmountDue(coreTemplate2.getSafekeepingAmountDue());

        billingCore.setSubTotal(coreTemplate2.getSafekeepingAmountDue());

        billingCore.setVatFee(coreTemplate2.getVatFee());
        billingCore.setVatAmountDue(coreTemplate2.getVatAmountDue());
        billingCore.setKseiTransactionValueFrequency(coreTemplate2.getKseiTransactionValueFrequency());
        billingCore.setKseiTransactionFee(coreTemplate2.getKseiTransactionFee());
        billingCore.setKseiTransactionAmountDue(coreTemplate2.getKseiTransactionAmountDue());
        billingCore.setKseiSafekeepingAmountDue(coreTemplate2.getKseiSafekeepingAmountDue());
        billingCore.setTotalAmountDue(coreTemplate2.getTotalAmountDue());
    }

    private BillingCore createBillingCore(BillingContextDate contextDate, BillingCustomer customer, InvestmentManagementDTO investmentManagementDTO, String[][] previousMonthsAndYears, String paymentDueDate) {
        Instant dateNow = contextDate.getDateNow();
        return BillingCore.builder()
                .createdAt(dateNow)
                .updatedAt(dateNow)
                .approvalStatus(ApprovalStatus.Pending)
                .billingStatus(BillingStatus.Generated)
                .customerCode(customer.getCustomerCode())
                .subCode(customer.getSubCode())
                .customerName(customer.getCustomerName())
                .month(contextDate.getMonthNameMinus1())
                .year(contextDate.getYearMinus1())
                // bisa ubah Billing Period dengan previous3Month
                .billingPeriod(ConvertDateUtil.convertToRange3Months(previousMonthsAndYears))
                .billingStatementDate(ConvertDateUtil.convertInstantToString(dateNow))
                .billingPaymentDueDate(paymentDueDate)
                .billingCategory(customer.getBillingCategory())
                .billingType(customer.getBillingType())
                .billingTemplate(customer.getBillingTemplate())
                .investmentManagementCode(investmentManagementDTO.getCode())
                .investmentManagementName(investmentManagementDTO.getName())
                .investmentManagementAddress1(investmentManagementDTO.getAddress1())
                .investmentManagementAddress2(investmentManagementDTO.getAddress2())
                .investmentManagementAddress3(investmentManagementDTO.getAddress3())
                .investmentManagementAddress4(investmentManagementDTO.getAddress4())
                .investmentManagementEmail(investmentManagementDTO.getEmail())
                .investmentManagementUniqueKey(investmentManagementDTO.getUniqueKey())
                .account(customer.getAccount())
                .accountName(customer.getAccountName())
                .currency(customer.getCurrency())
                .paid(false)
                .gefuCreated(false)
                .build();
    }

    private CoreTemplate2 calculationResult(CoreType7Parameter param) {
        BigDecimal safekeepingAmountDue = calculateSafekeepingAmountDue(param.getSfValRgMonthliesList());
        BigDecimal subTotal = calculateSubTotal(safekeepingAmountDue);
        BigDecimal vatAmountDue = calculateVATAmountDue(safekeepingAmountDue, param.getVatFee());
        Integer kseiTransactionValueFrequency = calculateKseiTransactionValueFrequency(param.getSkTransactionsList());
        BigDecimal kseiTransactionAmountDue = calculateKseiSafekeepingAmountDue(kseiTransactionValueFrequency, param.getKseiTransactionFee());
        BigDecimal kseiSafeFeeAmountDue = calculateKseiSafeFeeAmountDue(param.getKseiAmountFeeList());
        BigDecimal totalAmountDue = calculateTotalAmountDue(subTotal, vatAmountDue, kseiSafeFeeAmountDue, kseiTransactionAmountDue);

        return CoreTemplate2.builder()
                .safekeepingValueFrequency(BigDecimal.ZERO)
                .safekeepingFee(param.getCustomerSafekeepingFee())
                .safekeepingAmountDue(safekeepingAmountDue)
                .vatFee(param.getVatFee())
                .vatAmountDue(vatAmountDue)
                .kseiTransactionValueFrequency(kseiTransactionValueFrequency)
                .kseiTransactionFee(param.getKseiTransactionFee())
                .kseiTransactionAmountDue(kseiTransactionAmountDue)
                .kseiSafekeepingAmountDue(kseiSafeFeeAmountDue)
                .totalAmountDue(totalAmountDue)
                .build();
    }

    private BigDecimal calculateSafekeepingAmountDue(List<List<SfValRgMonthly>> sfValRgMonthliesList) {
        List<BigDecimal> safekeepingValueFrequencyList = new ArrayList<>();

        List<SfValRgMonthly> rawList = new ArrayList<>();

        for (List<SfValRgMonthly> sfValRgMonthlyList : sfValRgMonthliesList) {
            rawList.addAll(sfValRgMonthlyList);
        }

        List<SfValRgMonthly> sorted = rawList.stream()
                .sorted(Comparator.comparing(SfValRgMonthly::getDate).reversed())
                .collect(Collectors.toList());

        // Grouping by month and year
        Map<String, List<SfValRgMonthly>> groupedByMonthAndYear = new HashMap<>();
        for (SfValRgMonthly sf : sorted) {
            String key = sf.getDate().getYear() + "-" + sf.getDate().getMonthValue(); // Forming key as "YYYY-MM"
            groupedByMonthAndYear.computeIfAbsent(key, k -> new ArrayList<>()).add(sf);
        }

        // Adding the grouped lists to the 'lists' list
        List<List<SfValRgMonthly>> lists = new ArrayList<>(groupedByMonthAndYear.values());

        for (List<SfValRgMonthly> list : lists) {
            List<SfValRgMonthly> latestEntries = list.stream()
                    .filter(entry -> entry.getDate().equals(list.stream()
                            .map(SfValRgMonthly::getDate)
                            .max(Comparator.naturalOrder())
                            .orElse(null)))
                    .collect(Collectors.toList());

            BigDecimal safekeepingValueFrequency = latestEntries.stream()
                    .map(SfValRgMonthly::getMarketValue)
                    .filter(Objects::nonNull)
                    .reduce(BigDecimal.ZERO, BigDecimal::add)
                    .setScale(0, RoundingMode.HALF_UP);

            // calculate with fee schedule
            BigDecimal feeScheduleFeeValue = feeScheduleService.checkFeeScheduleAndGetFeeValue(safekeepingValueFrequency);
            BigDecimal result = feeScheduleFeeValue.divide(new BigDecimal(12), 0, RoundingMode.HALF_UP);
            safekeepingValueFrequencyList.add(result);
        }

        BigDecimal safekeepingValueFrequency3Months = safekeepingValueFrequencyList.stream()
                .reduce(BigDecimal.ZERO, BigDecimal::add)
                .setScale(0, RoundingMode.HALF_UP);
        log.info("[Core Type 7] Safekeeping value frequency 3 months (-PPn): {}", safekeepingValueFrequency3Months);
        return safekeepingValueFrequency3Months;
    }

    private static Integer calculateKseiTransactionValueFrequency(List<List<SkTransaction>> skTransactionsList) {
        List<Integer> kseiTransactionValueFrequency = new ArrayList<>();
        for (List<SkTransaction> skTransactions : skTransactionsList) {
            int size = skTransactions.size();
            kseiTransactionValueFrequency.add(size);
        }
        int sum = kseiTransactionValueFrequency.stream()
                .mapToInt(Integer::intValue)
                .sum();
        log.info("[Core Type 7] Total KSEI transaction frequency: {}", sum);
        return sum;
    }

    private static BigDecimal calculateKseiSafekeepingAmountDue(Integer kseiTransactionValueFrequency, BigDecimal kseiTransactionFee) {
        BigDecimal kseiSafekeepingAmountDue = new BigDecimal(kseiTransactionValueFrequency)
                .multiply(kseiTransactionFee)
                .setScale(0, RoundingMode.HALF_UP);
        log.info("[Core Type 7] KSEI safekeeping amount due: {}", kseiSafekeepingAmountDue);
        return kseiSafekeepingAmountDue;
    }

    private static BigDecimal calculateVATAmountDue(BigDecimal safekeepingAmountDue, BigDecimal vatFee) {
        BigDecimal vatAmountDue = safekeepingAmountDue
                .multiply(vatFee)
                .divide(new BigDecimal(100), 0, RoundingMode.HALF_UP)
                .setScale(0, RoundingMode.HALF_UP);
        log.info("[Core Type 7] VAT amount due: {}", vatAmountDue);
        return vatAmountDue;
    }

    private static BigDecimal calculateKseiSafeFeeAmountDue(List<BigDecimal> kseiAmountFeeList) {
        BigDecimal kseiSafeFeeAmountDue = kseiAmountFeeList.stream()
                .filter(Objects::nonNull)
                .reduce(BigDecimal.ZERO, BigDecimal::add)
                .setScale(0, RoundingMode.HALF_UP);

        BigDecimal result = kseiSafeFeeAmountDue.multiply(new BigDecimal(1.11))
                .setScale(0, RoundingMode.HALF_UP);

        log.info("[Core Type 7] Ksei Safe fee amount due: {}", result);
        return result;
    }

    private static BigDecimal calculateSubTotal(BigDecimal safekeepingAmountDue) {
        log.info("[Core Type 7] Sub total: {}", safekeepingAmountDue);
        return safekeepingAmountDue;
    }

    private static BigDecimal calculateTotalAmountDue(BigDecimal subTotal, BigDecimal vatAmountDue, BigDecimal kseiSafeFeeAmountDue, BigDecimal kseiTransactionAmountDue) {
        BigDecimal totalAmountDue = subTotal
                .add(vatAmountDue)
                .add(kseiSafeFeeAmountDue)
                .add(kseiTransactionAmountDue).setScale(0, RoundingMode.HALF_UP);
        log.info("[Core Type 7] Total amount due: {}", totalAmountDue);
        return totalAmountDue;
    }

    private void deleteExistingBillingCore(BillingCore existBillingCore) {
        String billingNumber = existBillingCore.getBillingNumber();
        billingCoreRepository.delete(existBillingCore);
        billingNumberService.deleteByBillingNumber(billingNumber);
    }

    private void handleGeneralError(String customerCode, Exception e, List<BillingCalculationErrorMessageDTO> errorMessageList) {
        addErrorMessage(errorMessageList, customerCode, e.getMessage());
    }

    private void addErrorMessage(List<BillingCalculationErrorMessageDTO> errorMessageList, String customerCode, String message) {
        List<String> stringList = new ArrayList<>();
        stringList.add(message);
        errorMessageList.add(new BillingCalculationErrorMessageDTO(customerCode.isEmpty() ? "unknown" : customerCode, stringList));
    }

}
