package com.services.billingservice.repository;

import com.services.billingservice.model.SfValCoreIIG;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface SfValCoreIIGRepository extends JpaRepository<SfValCoreIIG, Long> {

    @Query(value = "SELECT * FROM bill_sfval_core_iig WHERE customer_code = :customerCode", nativeQuery = true)
    List<SfValCoreIIG> findAllByCustomerCode(@Param("customerCode") String customerCode);

}
