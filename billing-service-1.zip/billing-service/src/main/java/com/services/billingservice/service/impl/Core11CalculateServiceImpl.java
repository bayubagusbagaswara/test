package com.services.billingservice.service.impl;

import com.services.billingservice.dto.billing.BillingCalculationErrorMessageDTO;
import com.services.billingservice.dto.billing.BillingCalculationResponse;
import com.services.billingservice.dto.billing.BillingContextDate;
import com.services.billingservice.dto.core.CoreCalculateRequest;
import com.services.billingservice.dto.core.CoreTemplate3;
import com.services.billingservice.dto.core.CoreType11Parameter;
import com.services.billingservice.dto.mi.InvestmentManagementDTO;
import com.services.billingservice.enums.ApprovalStatus;
import com.services.billingservice.enums.BillingStatus;
import com.services.billingservice.model.BillingCore;
import com.services.billingservice.model.BillingCustomer;
import com.services.billingservice.model.SfValCrowdFunding;
import com.services.billingservice.model.SkTransaction;
import com.services.billingservice.repository.BillingCoreRepository;
import com.services.billingservice.service.*;
import com.services.billingservice.utils.ConvertDateUtil;
import com.services.billingservice.utils.StringUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

import static com.services.billingservice.enums.FeeParameter.BILLING_PAYMENT_DUE_DATE;
import static com.services.billingservice.enums.FeeParameter.VAT;

@Slf4j
@Service
@RequiredArgsConstructor
public class Core11CalculateServiceImpl implements Core11CalculateService {

    private final BillingCustomerService customerService;
    private final BillingFeeParameterService feeParameterService;
    private final SkTranService skTransactionService;
    private final SfValCrowdFundingService sfValCrowdFundingService;
    private final BillingNumberService billingNumberService;
    private final BillingCoreRepository billingCoreRepository;
    private final BillingMIService investmentManagementService;
    private final ConvertDateUtil convertDateUtil;

    @Override
    public synchronized String calculate(CoreCalculateRequest request) {
        log.info("Start core billing calculation type 11 with a data request: {}", request);

        /* initialize response data */
        Integer totalDataSuccess = 0;
        Integer totalDataFailed = 0;
        List<BillingCalculationErrorMessageDTO> errorMessageList = new ArrayList<>();

        /* initialize data request */
        Instant dateNow = Instant.now();
        String categoryUpperCase = request.getCategory().toUpperCase();
        String typeUpperCase = StringUtil.replaceBlanksWithUnderscores(request.getType());

        /* generate billing context date */
        BillingContextDate contextDate = convertDateUtil.getBillingContextDate(dateNow);

        /* get data fee parameters */
        String paymentDueDate = feeParameterService.getFeeDescriptionByName(BILLING_PAYMENT_DUE_DATE.getValue());
        BigDecimal vatFee = feeParameterService.getValueByName(VAT.getValue());

        /* get billing customer Core type 11 */
        List<BillingCustomer> customerList = customerService.getAllByBillingCategoryAndBillingType(categoryUpperCase, typeUpperCase);

        for (BillingCustomer customer : customerList) {
            try {
                String customerCode = customer.getCustomerCode();

                /* get investment management data */
                InvestmentManagementDTO investmentManagementDTO = investmentManagementService.getByCode(customer.getMiCode());

                /* get data sk tran */
                List<SkTransaction> skTransactionList = skTransactionService.getAllByAidAndMonthAndYear(customerCode, contextDate.getMonthNameMinus1(), contextDate.getYearMinus1());

                /* get data sf val crowd funding */
                List<SfValCrowdFunding> sfValCrowdFundingList = sfValCrowdFundingService.getAllByClientCodeAndMonthAndYear(customerCode, contextDate.getMonthNameMinus1(), contextDate.getYearMinus1());

                /* create billing core */
                BillingCore billingCore = buildBillingCore(contextDate, customer, investmentManagementDTO, paymentDueDate);

                /* create core type 11 parameter */
                CoreType11Parameter coreType11Parameter = new CoreType11Parameter(
                        sfValCrowdFundingList, skTransactionList, customer.getCustomerMinimumFee(),
                        customer.getCustomerSafekeepingFee(),
                        customer.getCustomerTransactionHandling(), vatFee);

                /* calculation billing */
                CoreTemplate3 coreTemplate3 = calculationResult(coreType11Parameter);

                /* update billing core data to include calculated values */
                updateBillingCoreForCoreTemplate3(billingCore, coreTemplate3);

                /* create a billing number then set it to the billing core */
                String number = billingNumberService.generateSingleNumber(contextDate.getMonthNameNow(), contextDate.getYearNow());
                billingCore.setBillingNumber(number);


                /* get billing data to check whether the data is in the database or not */
                Optional<BillingCore> existingBillingCore = billingCoreRepository.findByCustomerCodeAndSubCodeAndBillingCategoryAndBillingTypeAndMonthAndYear(
                        customerCode, customer.getSubCode(), customer.getBillingCategory(), customer.getBillingType(), contextDate.getMonthNameMinus1(), contextDate.getYearMinus1());

                /* check paid status. if it is FALSE, it can be regenerated */
                if (!existingBillingCore.isPresent() || Boolean.TRUE.equals(!existingBillingCore.get().getPaid())) {

                    /* delete billing data if it exists in the database */
                    existingBillingCore.ifPresent(this::deleteExistingBillingCore);

                    /* save to the database */
                    billingCoreRepository.save(billingCore);
                    billingNumberService.saveSingleNumber(number);
                    totalDataSuccess++;
                } else {
                    addErrorMessage(errorMessageList, customer.getCustomerCode(), "Billing already paid for period " + contextDate.getMonthNameMinus1() + " " + contextDate.getYearMinus1());
                    totalDataFailed++;
                }
            } catch (Exception e) {
                handleGeneralError(customer.getCustomerCode(), e, errorMessageList);
                totalDataFailed++;
            }
        }

        log.info("Total successfully calculations: {}, total failed calculations: {}", totalDataSuccess, totalDataFailed);
        BillingCalculationResponse billingCalculationResponse = new BillingCalculationResponse(totalDataSuccess, totalDataFailed, errorMessageList);
        return "Total successful calculations: " + billingCalculationResponse.getTotalDataSuccess() + ", total failed calculations: " + billingCalculationResponse.getTotalDataFailed();
    }

    private static BigDecimal calculateSafekeepingValueFrequency(List<SfValCrowdFunding> sfValCrowdFundingList) {
        List<SfValCrowdFunding> latestEntries = sfValCrowdFundingList.stream()
                .filter(entry -> entry.getSettlementDate().equals(sfValCrowdFundingList.stream()
                        .map(SfValCrowdFunding::getSettlementDate)
                        .max(Comparator.naturalOrder())
                        .orElse(null)))
                .collect(Collectors.toList());

        BigDecimal safekeepingValueFrequency = latestEntries.stream()
                .map(SfValCrowdFunding::getMarketValue)
                .filter(Objects::nonNull)
                .reduce(BigDecimal.ZERO, BigDecimal::add)
                .setScale(0, RoundingMode.HALF_UP);

        log.info("[Core Type 11] Safekeeping value frequency: {}", safekeepingValueFrequency);
        return safekeepingValueFrequency;
    }

    private static BigDecimal calculateSafekeepingAmountDue(BigDecimal customerMinimumFee, BigDecimal customerSafekeepingFee, BigDecimal safekeepingValueFrequency) {
        BigDecimal result = safekeepingValueFrequency
                .multiply(customerSafekeepingFee)
                .setScale(0, RoundingMode.HALF_UP);

        BigDecimal divide = result.divide(new BigDecimal(12), 0, RoundingMode.HALF_UP);

        BigDecimal safekeepingAmountDue = divide.compareTo(customerMinimumFee) < 0 ? customerMinimumFee : divide;

        log.info("[Core Type 11] Safekeeping amount due: {}", safekeepingAmountDue);
        return safekeepingAmountDue;
    }

    private static BigDecimal calculateSubTotal(BigDecimal transactionHandlingAmountDue, BigDecimal safekeepingAmountDue) {
        BigDecimal subTotal = transactionHandlingAmountDue.add(safekeepingAmountDue);
        log.info("[Core Type 11] Sub total: {}", subTotal);
        return subTotal;
    }

    private static BigDecimal calculateVATAmountDue(BigDecimal vatFee, BigDecimal subTotal) {
        BigDecimal vatAmountDue = subTotal.multiply(vatFee)
                .divide(new BigDecimal(100), 0, RoundingMode.HALF_UP);
        log.info("[Core Type 11] VAT amount due: {}", vatAmountDue);
        return vatAmountDue;
    }

    private static BigDecimal calculateTotalAmountDue(BigDecimal subTotal, BigDecimal vatAmountDue) {
        BigDecimal totalAmountDue = subTotal.add(vatAmountDue).setScale(0, BigDecimal.ROUND_HALF_UP);
        log.info("[Core Type 11] Total amount due: {}", totalAmountDue);
        return totalAmountDue;
    }

    private void deleteExistingBillingCore(BillingCore existBillingCore) {
        String billingNumber = existBillingCore.getBillingNumber();
        billingCoreRepository.delete(existBillingCore);
        billingNumberService.deleteByBillingNumber(billingNumber);
    }

    private void handleGeneralError(String customerCode, Exception e, List<BillingCalculationErrorMessageDTO> errorMessageList) {
        addErrorMessage(errorMessageList, customerCode, e.getMessage());
    }

    private void addErrorMessage(List<BillingCalculationErrorMessageDTO> errorMessageList, String customerCode, String message) {
        List<String> stringList = new ArrayList<>();
        stringList.add(message);
        errorMessageList.add(new BillingCalculationErrorMessageDTO(customerCode, stringList));
    }

    private BillingCore buildBillingCore(BillingContextDate contextDate, BillingCustomer customer, InvestmentManagementDTO investmentManagementDTO, String paymentDueDate) {
        return BillingCore.builder()
                .createdAt(contextDate.getDateNow())
                .updatedAt(contextDate.getDateNow())
                .approvalStatus(ApprovalStatus.Pending)
                .billingStatus(BillingStatus.Generated)
                .customerCode(customer.getCustomerCode())
                .subCode(customer.getSubCode())
                .customerName(customer.getCustomerName())
                .month(contextDate.getMonthNameMinus1())
                .year(contextDate.getYearMinus1())
                .billingPeriod(contextDate.getMonthNameMinus1() + " " + contextDate.getYearMinus1())
                .billingStatementDate(ConvertDateUtil.convertInstantToString(contextDate.getDateNow()))
                .billingPaymentDueDate(paymentDueDate)
                .billingCategory(customer.getBillingCategory())
                .billingType(customer.getBillingType())
                .billingTemplate(customer.getBillingTemplate())
                .investmentManagementCode(investmentManagementDTO.getCode())
                .investmentManagementName(investmentManagementDTO.getName())
                .investmentManagementAddress1(investmentManagementDTO.getAddress1())
                .investmentManagementAddress2(investmentManagementDTO.getAddress2())
                .investmentManagementAddress3(investmentManagementDTO.getAddress3())
                .investmentManagementAddress4(investmentManagementDTO.getAddress4())
                .investmentManagementEmail(investmentManagementDTO.getEmail())
                .investmentManagementUniqueKey(investmentManagementDTO.getUniqueKey())
                .account(customer.getAccount())
                .accountName(customer.getAccountName())
                .currency(customer.getCurrency())
                .gefuCreated(false)
                .paid(false)
                .build();
    }

    private CoreTemplate3 calculationResult(CoreType11Parameter param) {
        Integer transactionHandlingValueFrequency = calculateTransactionHandlingValueFrequency(param.getSkTransactionList());
        BigDecimal transactionHandlingAmountDue = calculateTransactionHandlingAmountDue(param.getTransactionHandlingFee(), transactionHandlingValueFrequency);
        BigDecimal safekeepingValueFrequency = calculateSafekeepingValueFrequency(param.getSfValCrowdFundingList());
        BigDecimal safekeepingAmountDue = calculateSafekeepingAmountDue(param.getCustomerMinimumFee(), param.getCustomerSafekeepingFee(), safekeepingValueFrequency);
        BigDecimal subTotal = calculateSubTotal(transactionHandlingAmountDue, safekeepingAmountDue);
        BigDecimal vatAmountDue = calculateVATAmountDue(param.getVatFee(), subTotal);
        BigDecimal totalAmountDue = calculateTotalAmountDue(subTotal, vatAmountDue);

        return CoreTemplate3.builder()
                .transactionHandlingValueFrequency(transactionHandlingValueFrequency)
                .transactionHandlingFee(param.getTransactionHandlingFee())
                .transactionHandlingAmountDue(transactionHandlingAmountDue)
                .safekeepingValueFrequency(safekeepingValueFrequency)
                .safekeepingFee(param.getCustomerSafekeepingFee())
                .safekeepingAmountDue(safekeepingAmountDue)
                .subTotal(subTotal)
                .vatFee(param.getVatFee())
                .vatAmountDue(vatAmountDue)
                .totalAmountDue(totalAmountDue)
                .build();
    }

    private void updateBillingCoreForCoreTemplate3(BillingCore billingCore, CoreTemplate3 coreTemplate3) {
        billingCore.setTransactionHandlingValueFrequency(coreTemplate3.getTransactionHandlingValueFrequency());
        billingCore.setTransactionHandlingFee(coreTemplate3.getTransactionHandlingFee());
        billingCore.setTransactionHandlingAmountDue(coreTemplate3.getTransactionHandlingAmountDue());
        billingCore.setSafekeepingValueFrequency(coreTemplate3.getSafekeepingValueFrequency());
        billingCore.setSafekeepingFee(coreTemplate3.getSafekeepingFee());
        billingCore.setSafekeepingAmountDue(coreTemplate3.getSafekeepingAmountDue());
        billingCore.setSubTotal(coreTemplate3.getSubTotal());
        billingCore.setVatFee(coreTemplate3.getVatFee());
        billingCore.setVatAmountDue(coreTemplate3.getVatAmountDue());
        billingCore.setTotalAmountDue(coreTemplate3.getTotalAmountDue());
    }

    private Integer calculateTransactionHandlingValueFrequency(List<SkTransaction> skTransactionList) {
        Integer totalTransactionHandling = skTransactionList.size();
        log.info("[Core Type 1] Total transaction handling: {}", totalTransactionHandling);
        return totalTransactionHandling;
    }

    private BigDecimal calculateTransactionHandlingAmountDue(BigDecimal transactionHandlingFee, int transactionHandlingValueFrequency) {
        BigDecimal transactionHandlingAmountDue = transactionHandlingFee.multiply(new BigDecimal(transactionHandlingValueFrequency).setScale(0, RoundingMode.HALF_UP));
        log.info("[Core Type 1] Transaction handling amount due: {}", transactionHandlingAmountDue);
        return transactionHandlingAmountDue;
    }

}
