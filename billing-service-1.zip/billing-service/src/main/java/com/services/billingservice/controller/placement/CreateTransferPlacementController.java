package com.services.billingservice.controller.placement;

import com.services.billingservice.dto.ResponseDTO;
import com.services.billingservice.dto.placement.createtransferplacement.CreateBulkPlacementListRequest;
import com.services.billingservice.dto.placement.createtransferplacement.CreatePlacementResponse;
import com.services.billingservice.dto.placement.createtransferplacement.CreateSinglePlacementListRequest;
import com.services.billingservice.service.placement.CreateTransferPlacementService;
import com.services.billingservice.utils.ClientIPUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;

@RestController
@RequestMapping(path = "/api/placement/create-transfer-placement")
@CrossOrigin(origins = "*", allowedHeaders = "*")
@Slf4j
@RequiredArgsConstructor
public class CreateTransferPlacementController {

    private final CreateTransferPlacementService createTransferPlacementService;

    @PostMapping(path = "/bulk")
    public ResponseEntity<ResponseDTO<CreatePlacementResponse>> createBulk(@RequestBody CreateBulkPlacementListRequest createBulkPlacementListRequest, HttpServletRequest servletRequest) {
        String inputId = createBulkPlacementListRequest.getInputerId();
        String inputIPAddress = ClientIPUtil.getClientIp(servletRequest);
        log.info("Create Bulk with input id: {}, and input ip address: {}", inputId, inputIPAddress);

        CreatePlacementResponse createPlacementResponse = createTransferPlacementService.createBulk(createBulkPlacementListRequest, inputId, inputIPAddress);

        ResponseDTO<CreatePlacementResponse> response = ResponseDTO.<CreatePlacementResponse>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(createPlacementResponse)
                .build();
        return ResponseEntity.ok(response);
    }

    @PostMapping(path = "/single")
    public ResponseEntity<ResponseDTO<CreatePlacementResponse>> createSingle(@RequestBody CreateSinglePlacementListRequest createSinglePlacementListRequest, HttpServletRequest servletRequest) {
        String inputId = createSinglePlacementListRequest.getInputerId();
        String inputIPAddress = ClientIPUtil.getClientIp(servletRequest);
        log.info("Create Single with input id: {}, and input ip address: {}", inputId, inputIPAddress);

        CreatePlacementResponse createPlacementResponse = createTransferPlacementService.createSingle(createSinglePlacementListRequest, inputId, inputIPAddress);

        ResponseDTO<CreatePlacementResponse> response = ResponseDTO.<CreatePlacementResponse>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(createPlacementResponse)
                .build();
        return ResponseEntity.ok(response);
    }

}
