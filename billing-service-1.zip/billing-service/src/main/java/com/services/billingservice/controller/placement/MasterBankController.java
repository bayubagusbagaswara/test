package com.services.billingservice.controller.placement;

import com.services.billingservice.dto.ResponseDTO;
import com.services.billingservice.dto.placement.datachange.PlacementDataChangeDTO;
import com.services.billingservice.dto.placement.masterbank.*;
import com.services.billingservice.service.placement.MasterBankService;
import com.services.billingservice.utils.ClientIPUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping(path = "/api/placement/master-bank")
@CrossOrigin(origins = "*", allowedHeaders = "*")
@Slf4j
@RequiredArgsConstructor
public class MasterBankController {

    private static final String BASE_URL_MASTER_BANK = "/api/placement/master-bank";
    private static final String MENU_MASTER_BANK = "Master Bank";

    private final MasterBankService masterBankService;

    @PostMapping(path = "/upload-data")
    public ResponseEntity<ResponseDTO<MasterBankResponse>> uploadData(@RequestBody UploadMasterBankListRequest uploadMasterBankListRequest, HttpServletRequest servletRequest) {
        String inputIPAddress = ClientIPUtil.getClientIp(servletRequest);
        PlacementDataChangeDTO regulatoryDataChangeDTO = PlacementDataChangeDTO.builder()
                .inputerId(uploadMasterBankListRequest.getInputerId())
                .inputIPAddress(inputIPAddress)
                .inputDate(LocalDateTime.now())
                .isRequestBody(true)
                .isRequestParam(false)
                .isPathVariable(false)
                .menu(MENU_MASTER_BANK)
                .build();
        MasterBankResponse listData = masterBankService.uploadData(uploadMasterBankListRequest, regulatoryDataChangeDTO);
        ResponseDTO<MasterBankResponse> response = ResponseDTO.<MasterBankResponse>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(listData)
                .build();
        return ResponseEntity.ok(response);
    }

    @PostMapping(path = "/create/approve")
    public ResponseEntity<ResponseDTO<MasterBankResponse>> createApprove(@RequestBody ApproveMasterBankRequest approveMasterBankRequest, HttpServletRequest servletRequest) {
        String approveIPAddress = ClientIPUtil.getClientIp(servletRequest);
        MasterBankResponse singleApprove = masterBankService.createApprove(approveMasterBankRequest, approveIPAddress);
        ResponseDTO<MasterBankResponse> response = ResponseDTO.<MasterBankResponse>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(singleApprove)
                .build();
        return ResponseEntity.ok(response);
    }

    @PutMapping(path = "/update/approve")
    public ResponseEntity<ResponseDTO<MasterBankResponse>> updateApprove(@RequestBody ApproveMasterBankRequest approveMasterBankRequest, HttpServletRequest servletRequest) {
        String approveIPAddress = ClientIPUtil.getClientIp(servletRequest);
        MasterBankResponse singleApprove = masterBankService.updateApprove(approveMasterBankRequest, approveIPAddress);
        ResponseDTO<MasterBankResponse> response = ResponseDTO.<MasterBankResponse>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(singleApprove)
                .build();
        return ResponseEntity.ok(response);
    }

    @DeleteMapping(path = "/deleteById")
    public ResponseEntity<ResponseDTO<MasterBankResponse>> deleteById(@RequestBody DeleteMasterBankRequest deleteMasterBankRequest, HttpServletRequest servletRequest) {
        String inputIPAddress = ClientIPUtil.getClientIp(servletRequest);
        PlacementDataChangeDTO placementDataChangeDTO = PlacementDataChangeDTO.builder()
                .inputerId(deleteMasterBankRequest.getInputerId())
                .inputIPAddress(inputIPAddress)
                .inputDate(LocalDateTime.now())
                .methodHttp(HttpMethod.DELETE.name())
                .endpoint(BASE_URL_MASTER_BANK + "/delete/approve")
                .isRequestBody(true)
                .isRequestParam(false)
                .isPathVariable(false)
                .menu(MENU_MASTER_BANK)
                .build();
        MasterBankResponse singleData = masterBankService.deleteById(deleteMasterBankRequest, placementDataChangeDTO);
        ResponseDTO<MasterBankResponse> response = ResponseDTO.<MasterBankResponse>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(singleData)
                .build();
        return ResponseEntity.ok(response);
    }

    @DeleteMapping(path = "/delete/approve")
    public ResponseEntity<ResponseDTO<MasterBankResponse>> deleteApprove(@RequestBody ApproveMasterBankRequest approveMasterBankRequest, HttpServletRequest servletRequest) {
        String approveIPAddress = ClientIPUtil.getClientIp(servletRequest);
        MasterBankResponse singleApprove = masterBankService.deleteApprove(approveMasterBankRequest, approveIPAddress);
        ResponseDTO<MasterBankResponse> response = ResponseDTO.<MasterBankResponse>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(singleApprove)
                .build();
        return ResponseEntity.ok(response);
    }

    @GetMapping(path = "/{id}")
    public ResponseEntity<ResponseDTO<MasterBankDTO>> getById(@PathVariable("id") Long id) {
        MasterBankDTO masterBankDTO = masterBankService.getById(id);
        ResponseDTO<MasterBankDTO> response = ResponseDTO.<MasterBankDTO>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(masterBankDTO)
                .build();
        return ResponseEntity.ok(response);
    }

    @GetMapping(path = "/placement-bank-code")
    public ResponseEntity<ResponseDTO<MasterBankDTO>> getByPlacementBankCode(@RequestParam("placementBankCode") String placementBankCode) {
        MasterBankDTO masterBankDTO = masterBankService.getByPlacementBankCode(placementBankCode);
        ResponseDTO<MasterBankDTO> response = ResponseDTO.<MasterBankDTO>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(masterBankDTO)
                .build();
        return ResponseEntity.ok(response);
    }

    @GetMapping(path = "/all")
    public ResponseEntity<ResponseDTO<List<MasterBankDTO>>> getAll() {
        List<MasterBankDTO> masterBankDTOList = masterBankService.getAll();
        ResponseDTO<List<MasterBankDTO>> response = ResponseDTO.<List<MasterBankDTO>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(masterBankDTOList)
                .build();
        return ResponseEntity.ok(response);
    }

}
