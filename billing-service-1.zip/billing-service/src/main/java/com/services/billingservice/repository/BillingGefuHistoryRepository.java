package com.services.billingservice.repository;

import com.services.billingservice.dto.gefu.BillingGefuProcessHistoryDTO;
import com.services.billingservice.enums.ApprovalStatus;
import com.services.billingservice.model.BillingGefuProcessHistory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BillingGefuHistoryRepository extends JpaRepository<BillingGefuProcessHistory, Long> {

    @Query(value = "SELECT * FROM billing_gefu_process_history  " +
            "WHERE fileName = :fileName ", nativeQuery = true)
    BillingGefuProcessHistory findByFileName(
            @Param("fileName") String fileName);

    @Query(value = "SELECT * FROM billing_gefu_process_history  " +
            "WHERE id = :id ", nativeQuery = true)
    BillingGefuProcessHistory findById(
            @Param("id") long id);

    @Query(value = "SELECT fileName FROM billing_gefu_process_history  " +
            "WHERE approval_status <> 'Rejected'", nativeQuery = true)
    List<String> findNotRejectedFileName();

    @Query(value = "SELECT * FROM billing_gefu_process_history  " +
            "WHERE category = :category", nativeQuery = true)
    List<BillingGefuProcessHistory> findAllByCategory(
            @Param("category") String category);

    @Query(value = "SELECT * FROM billing_gefu_process_history  " +
            "order by id desc", nativeQuery = true)
    List<BillingGefuProcessHistory> findAll();


    @Query(value = "SELECT * FROM billing_gefu_process_history  " +
            "WHERE category = :category and billingPeriode = :billingPeriode " +
            " and approval_status = 'Pending' ", nativeQuery = true)
    List<BillingGefuProcessHistory> findAllByCategoryAndBillingPeriode(
            @Param("category") String category,
            @Param("billingPeriode") String billingPeriode);

    @Query(value = "SELECT * FROM billing_gefu_process_history  " +
            "WHERE category = :category and billingPeriode = :billingPeriode and customerCode = :customerCode" +
            " and approval_status = 'Pending' ", nativeQuery = true)
    List<BillingGefuProcessHistory> findAllByCategoryAndBillingPeriodeAndCustomerCode(
            @Param("category") String category,
            @Param("billingPeriode") String billingPeriode,
            @Param("customerCode") String customerCode);

    @Query("SELECT new com.services.billingservice.dto.gefu.BillingGefuProcessHistoryDTO(" +
            "ph.id, ph.customerCode, ph.billingPeriode, ph.category, ph.type, ph.fileName, " +
            "SUM(CASE WHEN gd.status = 'Failure' THEN 1 ELSE 0 END), " +
            "SUM(CASE WHEN gd.status = 'Pending' THEN 1 ELSE 0 END), " +
            "SUM(CASE WHEN gd.status = 'Success' THEN 1 ELSE 0 END)) " +
            "FROM BillingGefuProcessHistory ph " +
            "JOIN BillingGefuProcessDetail gd " +
            "ON ph.id = gd.gefuProcessHistory " +
            "WHERE ph.category = :category " +
            "AND ph.billingPeriode = :billingPeriod " +
            "AND ph.approvalStatus <> :approvalStatus " +
            "GROUP BY ph.id, ph.customerCode, ph.billingPeriode, ph.category, ph.type, ph.fileName")
    List<BillingGefuProcessHistoryDTO> findResultAllByCategoryAndBillingPeriod(
            @Param("category") String category,
            @Param("billingPeriod") String billingPeriod,
            @Param("approvalStatus") ApprovalStatus approvalStatus);

    @Query("SELECT new com.services.billingservice.dto.gefu.BillingGefuProcessHistoryDTO(" +
            "ph.id, ph.customerCode, ph.billingPeriode, ph.category, ph.type, ph.fileName, " +
            "SUM(CASE WHEN gd.status = 'Failure' THEN 1 ELSE 0 END), " +
            "SUM(CASE WHEN gd.status = 'Pending' THEN 1 ELSE 0 END), " +
            "SUM(CASE WHEN gd.status = 'Success' THEN 1 ELSE 0 END)) " +
            "FROM BillingGefuProcessHistory ph " +
            "JOIN BillingGefuProcessDetail gd " +
            "ON ph.id = gd.gefuProcessHistory " +
            "WHERE ph.category = :category " +
            "AND ph.billingPeriode = :billingPeriod " +
            "AND ph.customerCode = :customerCode " +
            "AND ph.approvalStatus <> :approvalStatus " +
            "GROUP BY ph.id, ph.customerCode, ph.billingPeriode, ph.category, ph.type, ph.fileName")
    List<BillingGefuProcessHistoryDTO> findResultAllByCategoryAndBillingPeriodAndCustomerCode(
            @Param("category") String category,
            @Param("billingPeriod") String billingPeriod,
            @Param("customerCode") String customerCode,
            @Param("approvalStatus") ApprovalStatus approvalStatus);

    @Query(value = "SELECT * FROM billing_gefu_process_history  " +
            "WHERE fileName = :fileName ", nativeQuery = true)
    List<BillingGefuProcessHistory> findAllByFileName(
            @Param("fileName") String fileName);

}
