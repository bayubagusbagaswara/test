package com.services.billingservice.service;

import com.services.billingservice.dto.ematerai.BillingEmateraiDTO;

import java.util.List;

public interface BillingEmateraiService {

    List<BillingEmateraiDTO> getByCategory(String Category);

}
