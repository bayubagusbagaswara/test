package com.services.billingservice.mapper.placement;

import com.services.billingservice.dto.placement.masterbank.MasterBankDTO;
import com.services.billingservice.dto.placement.masterbank.UploadMasterBankDataRequest;
import com.services.billingservice.model.placement.MasterBank;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

import java.util.List;

@Mapper(componentModel = "spring")
public interface MasterBankMapper {

    @Mapping(source = "id", target = "id")
    MasterBankDTO toDTO(MasterBank masterBank);

    @Mapping(target = "id", ignore = true)
    @Mapping(source = "placementBankCode", target = "placementBankCode", qualifiedByName = "nullToEmpty")
    @Mapping(source = "placementBankName", target = "placementBankName", qualifiedByName = "nullToEmpty")
    @Mapping(source = "biCode", target = "biCode", qualifiedByName = "nullToEmpty")
    @Mapping(source = "bankType", target = "bankType", qualifiedByName = "nullToEmpty")
    @Mapping(source = "branchCode", target = "branchCode", qualifiedByName = "nullToEmpty")
    MasterBankDTO fromUploadRequestToDTO(UploadMasterBankDataRequest uploadMasterBankDataRequest);

    @Named("nullToEmpty")
    default String nullToEmpty(String value) { return null == value ? "" : value; }

    List<MasterBankDTO> toDTOList(List<MasterBank> all);

}
