package com.services.billingservice.mapper;

import com.services.billingservice.dto.datachange.BillingDataChangeDTO;
import com.services.billingservice.dto.feeschedule.FeeScheduleDTO;
import com.services.billingservice.enums.ApprovalStatus;
import com.services.billingservice.model.BillingFeeSchedule;
import com.services.billingservice.utils.ConvertDateUtil;
import org.modelmapper.ModelMapper;
import org.modelmapper.PropertyMap;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class FeeScheduleMapper extends BaseMapper<BillingFeeSchedule, FeeScheduleDTO> {

    private final ConvertDateUtil convertDateUtil;

    public FeeScheduleMapper(ModelMapper modelMapper, ConvertDateUtil convertDateUtil) {
        super(modelMapper);
        this.convertDateUtil = convertDateUtil;
    }

    @Override
    protected PropertyMap<BillingFeeSchedule, FeeScheduleDTO> getPropertyMap() {
        return new PropertyMap<BillingFeeSchedule, FeeScheduleDTO>() {
            @Override
            protected void configure() {
                skip(destination.getApprovalStatus());
                skip(destination.getInputerId());
                skip(destination.getInputerIPAddress());
                skip(destination.getInputDate());
                skip(destination.getApproverId());
                skip(destination.getApproverIPAddress());
                skip(destination.getApproveDate());
            }
        };
    }

    @Override
    protected Class<BillingFeeSchedule> getEntityClass() {
        return BillingFeeSchedule.class;
    }

    @Override
    protected Class<FeeScheduleDTO> getDtoClass() {
        return FeeScheduleDTO.class;
    }

    @Override
    protected void setCommonProperties(BillingFeeSchedule entity, BillingDataChangeDTO dataChangeDTO) {
        entity.setApprovalStatus(ApprovalStatus.Approved);
        entity.setInputerId(dataChangeDTO.getInputerId());
        entity.setInputerIPAddress(dataChangeDTO.getInputerIPAddress());
        entity.setInputDate(dataChangeDTO.getInputDate());
        entity.setApproverId(dataChangeDTO.getApproverId());
        entity.setApproverIPAddress(dataChangeDTO.getApproverIPAddress());
        entity.setApproveDate(convertDateUtil.getDate());
    }

}
