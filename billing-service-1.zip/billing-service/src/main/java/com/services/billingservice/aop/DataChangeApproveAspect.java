package com.services.billingservice.aop;

//import com.services.billingservice.model.DataChange;
//import com.services.billingservice.repository.DataChangeRepository;
import org.aspectj.lang.annotation.Aspect;
        import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
        import org.springframework.stereotype.Component;

@Aspect
@Component
public class DataChangeApproveAspect {
    Logger logger = LoggerFactory.getLogger(DataChangeApproveAspect.class);
//    @Autowired
//    ApplicationContext applicationContext;
//
////
////    @Autowired
////    private MasterKebijakanInvestasiRepository masterKebijakanInvestasiRepository;
//    @Autowired
//    private DataChangeRepository dataChangeRepository;
//    @Pointcut("execution(* com.services.billingservice.service.DataChangeService.doApprove(..)) && args(dataChangeId)")
//    public void dataChangeApproval(Long dataChangeId) {
//    }
//    @AfterReturning(pointcut = "dataChangeApproval(dataChangeId)", returning = "result")
//    public void copyApprovedDataToMaster(Long dataChangeId, ResponseEntity<ResponseDTO> result) {
//
//        String className = result.getBody().getPayload().getClass().getSimpleName();
//        String firstLetterLowercase = Character.toLowerCase(className.charAt(0)) + className.substring(1); // Ubah huruf pertama menjadi huruf kecil
//        String repositoryName = firstLetterLowercase + "Repository"; // Buat nama repository
//
//        // mencari repository berdasarkan nama
//        JpaRepository<Object, String> repository = (JpaRepository<Object, String>) applicationContext.getBean(repositoryName);
//
//        DataChange dataChange = dataChangeRepository.findById(dataChangeId).orElseThrow(()->new RuntimeException("No data!"));
//        Approvable approvable = (Approvable) SerializationUtils.deserialize(dataChange.getChangedObject());
//        approvable.setApprovalStatus(ApprovalStatus.Approved);
//        approvable.setApproveDate(new Date());
//        approvable.setApproverId(UserIdUtil.getUser());
//        repository.save(approvable);
//        logger.info("Aspect Data Change Approved");
//
//
//    }
}
