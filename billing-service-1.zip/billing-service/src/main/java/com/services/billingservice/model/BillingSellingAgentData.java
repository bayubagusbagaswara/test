package com.services.billingservice.model;

import com.services.billingservice.model.base.Approvable;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import javax.persistence.*;

@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "bill_selling_agent_data")
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class BillingSellingAgentData extends Approvable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "code")
    private String code;

    @Column(name = "name")
    private String name;

}
