package com.services.billingservice.service.impl;

import com.services.billingservice.dto.monthyear.MonthYearDTO;
import com.services.billingservice.dto.pdf.GeneratePDFResponse;
import com.services.billingservice.dto.retail.BillingRetailDTO;
import com.services.billingservice.dto.retail.RetailCalculateRequest;
import com.services.billingservice.enums.ApprovalStatus;
import com.services.billingservice.enums.ReportGeneratorStatus;
import com.services.billingservice.exception.GeneratePDFBillingException;
import com.services.billingservice.mapper.BillingRetailMapper;
import com.services.billingservice.model.BillingReportGenerator;
import com.services.billingservice.model.BillingRetail;
import com.services.billingservice.repository.BillingRetailRepository;
import com.services.billingservice.service.BillingReportGeneratorService;
import com.services.billingservice.service.RetailGeneratePDFService;
import com.services.billingservice.utils.ConvertDateUtil;
import com.services.billingservice.utils.PdfGenerator;
import com.services.billingservice.utils.StringUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.thymeleaf.context.Context;
import org.thymeleaf.spring5.SpringTemplateEngine;

import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Instant;
import java.util.List;

import static com.services.billingservice.constant.RetailConstant.*;

@Service
@Slf4j
@RequiredArgsConstructor
public class RetailGeneratePDFServiceImpl implements RetailGeneratePDFService {

    @Value("${base.path.billing.retail}")
    private String basePathBillingRetail;

    @Value("${base.path.billing.image}")
    private String folderPathImage;

    private static final String DELIMITER = "/";
    private static final String BANK_ACCOUNT_BDI = "PT Bank Danamon Indonesia";

    private final BillingRetailRepository billingRetailRepository;
    private final SpringTemplateEngine templateEngine;
    private final PdfGenerator pdfGenerator;
    private final ConvertDateUtil convertDateUtil;
    private final BillingRetailMapper billingRetailMapper;
    private final BillingReportGeneratorService billingReportGeneratorService;

    @Override
    public String generatePDF(RetailCalculateRequest request) {
        log.info("Start generate PDF Billing Retail with request: {}", request);
        String categoryUpperCase = request.getCategory().toUpperCase();
        String typeUpperCase = StringUtil.replaceBlanksWithUnderscores(request.getType());
        String[] monthFormat = convertDateUtil.convertToYearMonthFormat(request.getMonthYear());
        String monthName = monthFormat[0];
        int year = Integer.parseInt(monthFormat[1]);

        try {
            String approvalStatus = ApprovalStatus.Approved.getStatus();

            List<BillingRetail> billingRetailList = billingRetailRepository.findAllByBillingCategoryAndBillingTypeAndMonthAndYearAndApprovalStatus(
                    categoryUpperCase, typeUpperCase, monthName, year, approvalStatus
            );

            GeneratePDFResponse generatePDFResponse = generateAndSavePdfStatements(billingRetailList);

            return "Successfully created a PDF file Billing Fund with total data success: " + generatePDFResponse.getTotalDataSuccess() +
                    ", and total data failed: " + generatePDFResponse.getTotalDataFailed();
        } catch (Exception e) {
            log.error("Error when generate PDF Billing Retail type '" + typeUpperCase + "' : " + e.getMessage(), e);
            throw new GeneratePDFBillingException("Error when generate PDF Billing Retail type '" + typeUpperCase + "' : " + e.getMessage());
        }
    }

    private GeneratePDFResponse generateAndSavePdfStatements(List<BillingRetail> billingRetailList) {
        log.info("Start generate and save PDF statements Billing Retail size: {}", billingRetailList.size());
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        Instant dateNow = Instant.now();
        List<BillingRetailDTO> billingRetailDTOList = billingRetailMapper.mapToDTOList(billingRetailList);

        for (BillingRetailDTO billingRetailDTO : billingRetailDTOList) {
            log.info("Start generate PDF Billing Retail type '{}' and currency '{}'", billingRetailDTO.getBillingType(), billingRetailDTO.getCurrency());

            String customerCode = billingRetailDTO.getCustomerCode();
            String subCode = billingRetailDTO.getSubCode();
            String investmentManagementCode = billingRetailDTO.getInvestmentManagementCode();
            String investmentManagementName = billingRetailDTO.getInvestmentManagementName();
            String investmentManagementEmail = billingRetailDTO.getInvestmentManagementEmail();
            String investmentManagementUniqueKey = billingRetailDTO.getInvestmentManagementUniqueKey();
            String customerName = billingRetailDTO.getCustomerName();
            String billingCategory = billingRetailDTO.getBillingCategory();
            String billingType = billingRetailDTO.getBillingType();
            String billingPeriod = billingRetailDTO.getBillingPeriod();
            String currency = billingRetailDTO.getCurrency();
            String billingNumber = billingRetailDTO.getBillingNumber();

            MonthYearDTO monthYearDTO = convertDateUtil.parseBillingPeriodToLocalDate(billingRetailDTO.getBillingPeriod());
            String yearMonthFormat = monthYearDTO.getYear() + monthYearDTO.getMonthValue();
            String filePath;
            String fileName = generateFileName(customerCode, subCode, billingNumber);

            /* get month and year */
            int year = monthYearDTO.getYear();
            String monthName = monthYearDTO.getMonthName();

            /* tentukan folder path */
            String folderPath = basePathBillingRetail + yearMonthFormat + DELIMITER + investmentManagementCode;

            /* tentukan file path */
            filePath = folderPath + DELIMITER + fileName;

            try {
                /* create folder to save pdf file */
                Path folderPathObj = Paths.get(folderPath);
                Files.createDirectories(folderPathObj);

                deleteFilesWithCustomerCode(folderPathObj, customerCode, subCode);

                /* render data to thymeleaf and save pdf */
                String htmlContent = renderThymeleafTemplate(billingRetailDTO);
                byte[] pdfBytes = pdfGenerator.generatePdfFromHtml(htmlContent);
                savePdf(pdfBytes, folderPath, fileName);

                /* check and delete existing report generator */
                billingReportGeneratorService.checkingExistingBillingReportGenerator(
                        customerCode, billingCategory, billingType, currency, billingRetailDTO.getMonth(), Integer.parseInt(billingRetailDTO.getYear())
                );

                BillingReportGenerator reportGenerator = BillingReportGenerator.builder()
                        .createdAt(dateNow)
                        .investmentManagementName(investmentManagementName)
                        .investmentManagementEmail(investmentManagementEmail)
                        .investmentManagementUniqueKey(investmentManagementUniqueKey)
                        .customerCode(customerCode)
                        .customerName(customerName)
                        .category(billingCategory)
                        .type(billingType)
                        .period(billingPeriod)
                        .month(monthName)
                        .year(year)
                        .currency(currency)
                        .fileName(fileName)
                        .filePath(filePath)
                        .status(ReportGeneratorStatus.SUCCESS.getStatus())
                        .desc("Successfully generate and save PDF statement with customer code: " + customerCode)
                        .investmentManagementCode(investmentManagementCode)
                        .build();
                BillingReportGenerator generator = billingReportGeneratorService.saveSingleData(reportGenerator);
                log.info("Successfully create report generator with id: {}", generator.getId());
                totalDataSuccess++;
            } catch (Exception e) {
                log.error("Error creating folder or saving PDF: {}", e.getMessage(), e);
                /* create report generator for saving failed process */
                BillingReportGenerator reportGenerator = BillingReportGenerator.builder()
                        .createdAt(dateNow)
                        .investmentManagementName(investmentManagementName)
                        .investmentManagementEmail(investmentManagementEmail)
                        .investmentManagementUniqueKey(investmentManagementUniqueKey)
                        .currency(currency)
                        .customerCode(customerCode)
                        .customerName(customerName)
                        .category(billingCategory)
                        .type(billingType)
                        .period(billingPeriod)
                        .month(monthName)
                        .year(year)
                        .fileName(fileName)
                        .filePath(folderPath)
                        .status(ReportGeneratorStatus.FAILED.getStatus())
                        .desc(e.getMessage())
                        .investmentManagementCode(investmentManagementCode)
                        .build();
                BillingReportGenerator generator = billingReportGeneratorService.saveSingleData(reportGenerator);
                log.info("Successfully create report generator with id: {}", generator.getId());
                totalDataFailed++;
            }
        }
        return new GeneratePDFResponse(totalDataSuccess, totalDataFailed);
    }

    private String renderThymeleafTemplate(BillingRetailDTO retailDTO) {
        Context context = new Context();
        context.setVariable(BILLING_NUMBER, retailDTO.getBillingNumber());
        context.setVariable(BILLING_PERIOD, retailDTO.getBillingPeriod());
        context.setVariable(BILLING_STATEMENT_DATE, retailDTO.getBillingStatementDate());
        context.setVariable(BILLING_PAYMENT_DUE_DATE, retailDTO.getBillingPaymentDueDate());
        context.setVariable(BILLING_CATEGORY, retailDTO.getBillingCategory());
        context.setVariable(BILLING_TYPE, retailDTO.getBillingType());
        context.setVariable(BILLING_TEMPLATE, retailDTO.getBillingTemplate());
        context.setVariable(INVESTMENT_MANAGEMENT_NAME, retailDTO.getInvestmentManagementName());
        context.setVariable(INVESTMENT_MANAGEMENT_ADDRESS_1, retailDTO.getInvestmentManagementAddress1());
        context.setVariable(INVESTMENT_MANAGEMENT_ADDRESS_2, retailDTO.getInvestmentManagementAddress2());
        context.setVariable(INVESTMENT_MANAGEMENT_ADDRESS_3, retailDTO.getInvestmentManagementAddress3());
        context.setVariable(INVESTMENT_MANAGEMENT_ADDRESS_4, retailDTO.getInvestmentManagementAddress4());

        context.setVariable(CUSTOMER_NAME, retailDTO.getCustomerName());
        context.setVariable(ACCOUNT_NUMBER, retailDTO.getAccountNumber());
        context.setVariable(ACCOUNT_NAME, retailDTO.getAccountName());
        context.setVariable(ACCOUNT_BANK, BANK_ACCOUNT_BDI);
        context.setVariable(SAFEKEEPING_FR, retailDTO.getSafekeepingFR());
        context.setVariable(SAFEKEEPING_SR, retailDTO.getSafekeepingSR());
        context.setVariable(SAFEKEEPING_ST, retailDTO.getSafekeepingST());
        context.setVariable(SAFEKEEPING_ORI, retailDTO.getSafekeepingORI());
        context.setVariable(SAFEKEEPING_SBR, retailDTO.getSafekeepingSBR());
        context.setVariable(SAFEKEEPING_PBS, retailDTO.getSafekeepingPBS());
        context.setVariable(SAFEKEEPING_CORPORATE_BOND, retailDTO.getSafekeepingCorporateBond());

        context.setVariable(TOTAL_AMOUNT_DUE, retailDTO.getTotalAmountDue());

        context.setVariable(SAFEKEEPING_VALUE_FREQUENCY, retailDTO.getSafekeepingValueFrequency());
        context.setVariable(SAFEKEEPING_FEE, retailDTO.getSafekeepingFee());
        context.setVariable(SAFEKEEPING_AMOUNT_DUE, retailDTO.getSafekeepingAmountDue());

        context.setVariable(TRANSACTION_SETTLEMENT_VALUE_FREQUENCY, retailDTO.getTransactionSettlementValueFrequency());
        context.setVariable(TRANSACTION_SETTLEMENT_FEE, retailDTO.getTransactionSettlementFee());
        context.setVariable(TRANSACTION_SETTLEMENT_AMOUNT_DUE, retailDTO.getTransactionSettlementAmountDue());

        context.setVariable(AD_HOC_REPORT_VALUE_FREQUENCY, retailDTO.getAdHocReportValueFrequency());
        context.setVariable(AD_HOC_REPORT_FEE, retailDTO.getAdHocReportFee());
        context.setVariable(AD_HOC_REPORT_AMOUNT_DUE, retailDTO.getAdHocReportAmountDue());

        context.setVariable(THIRD_PARTY_VALUE_FREQUENCY, retailDTO.getThirdPartyValueFrequency());
        context.setVariable(THIRD_PARTY_FEE, retailDTO.getThirdPartyFee());
        context.setVariable(THIRD_PARTY_AMOUNT_DUE, retailDTO.getThirdPartyAmountDue());

        context.setVariable(VAT_FEE, retailDTO.getVatFee());
        context.setVariable(VAT_AMOUNT_DUE, retailDTO.getVatAmountDue());

        context.setVariable(SUB_TOTAL, retailDTO.getSubTotalAmountDue());

        context.setVariable(TRANSACTION_HANDLING_VALUE_FREQUENCY, retailDTO.getTransactionHandlingValueFrequency());
        context.setVariable(TRANSACTION_HANDLING_FEE, retailDTO.getTransactionHandlingFee());
        context.setVariable(TRANSACTION_HANDLING_AMOUNT_DUE, retailDTO.getTransactionHandlingAmountDue());

        context.setVariable(TRANSACTION_HANDLING_INTERNAL_VALUE_FREQUENCY, retailDTO.getTransactionHandlingInternalValueFrequency());
        context.setVariable(TRANSACTION_HANDLING_INTERNAL_FEE, retailDTO.getTransactionHandlingInternalFee());
        context.setVariable(TRANSACTION_HANDLING_INTERNAL_AMOUNT_DUE, retailDTO.getTransactionHandlingInternalAmountDue());

        context.setVariable(TRANSFER_VALUE_FREQUENCY, retailDTO.getTransferValueFrequency());
        context.setVariable(TRANSFER_FEE, retailDTO.getTransferFee());
        context.setVariable(TRANSFER_AMOUNT_DUE, retailDTO.getTransferAmountDue());

        String imageUrlHeader = "file:///" + folderPathImage + "/logo.png";
        String imageUrlFooter = "file:///" + folderPathImage + "/footer.png";
        context.setVariable(IMAGE_URL_HEADER, imageUrlHeader);
        context.setVariable(IMAGE_URL_FOOTER, imageUrlFooter);

        String billingTemplate = retailDTO.getBillingTemplate();

        return templateEngine.process(billingTemplate, context);
    }

    private String generateFileName(String customerCode, String subCode, String billingNumber) {
        String fileName;
        String replaceBillingNumber = billingNumber
                .replace("/", "_")
                .replace("-", "_");

        if (subCode == null || subCode.isEmpty()) {
            fileName = customerCode + "_" + replaceBillingNumber + ".pdf";
        } else {
            fileName = customerCode + "_" + subCode + "_" + replaceBillingNumber + ".pdf";
        }
        return fileName;
    }

    private void savePdf(byte[] pdfBytes, String folderPath, String fileName) throws IOException {
        Path outputPathObj = Paths.get(folderPath).resolve(fileName);
        String outputPath = outputPathObj.toString();
        pdfGenerator.savePdfToFile(pdfBytes, outputPath);
    }

    private void deleteFilesWithCustomerCode(Path folderPathObj, String customerCode, String subCode) throws IOException {
        try (DirectoryStream<Path> directoryStream = Files.newDirectoryStream(folderPathObj, "*.pdf")) {
            for (Path path : directoryStream) {
                if (Files.isRegularFile(path)) {
                    handleFile(path, customerCode, subCode);
                }
            }
        }
    }

    private void handleFile(Path path, String customerCode, String subCode) throws IOException {
        String fileName = path.getFileName().toString();
        if (shouldDeleteFile(fileName, customerCode, subCode)) {
            Files.delete(path);
            log.info("Deleted path: {}, file: {}", path, fileName);
        }
    }

    private boolean shouldDeleteFile(String fileName, String customerCode, String subCode) {
        if (subCode == null || subCode.isEmpty()) {
            return fileName.contains(customerCode);
        }
        return fileName.contains(subCode);
    }

}
