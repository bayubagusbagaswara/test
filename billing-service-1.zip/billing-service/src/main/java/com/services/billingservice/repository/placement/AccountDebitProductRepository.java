package com.services.billingservice.repository.placement;

import com.services.billingservice.model.placement.AccountDebitProduct;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface AccountDebitProductRepository extends JpaRepository<AccountDebitProduct, Long> {

    boolean existsByProductCode(String productCode);

    Optional<AccountDebitProduct> findByProductCode(String productCode);

    Optional<AccountDebitProduct> findByFundCode(String fundCode);

}
