package com.services.billingservice.service;

import com.services.billingservice.dto.customer.*;
import com.services.billingservice.dto.datachange.BillingDataChangeDTO;
import com.services.billingservice.model.BillingCustomer;

import java.util.List;

public interface BillingCustomerService {

    boolean isCodeAlreadyExists(String code, String subCode);

    List<CustomerDTO> getAll();

    CustomerDTO getByCode(String customerCode);

    List<BillingCustomer> getAllByBillingCategoryAndBillingType(String billingCategory, String billingType);

    String deleteAll();

    CustomerResponse createSingleData(CreateCustomerRequest request, BillingDataChangeDTO dataChangeDTO);

    CustomerResponse createMultipleData(CreateCustomerListRequest request, BillingDataChangeDTO dataChangeDTO);

    CustomerResponse createSingleApprove(CustomerApproveRequest request, String clientIP);

    CustomerResponse updateSingleData(UpdateCustomerRequest request, BillingDataChangeDTO dataChangeDTO);

    CustomerResponse updateMultipleData(UpdateCustomerListRequest updateCreateCustomerListRequest, BillingDataChangeDTO dataChangeDTO);

    CustomerResponse updateSingleApprove(CustomerApproveRequest request, String clientIP);

    CustomerResponse deleteSingleData(DeleteCustomerRequest request, BillingDataChangeDTO dataChangeDTO);

    CustomerResponse deleteSingleApprove(CustomerApproveRequest request, String clientIP);

    CustomerDTO getById(String id);

    BillingCustomer getByCustomerCodeAndSubCodeAndBillingCategoryAndBillingType(String aid, String s, String billingCategory, String billingType);

}
