package com.services.billingservice.dto.placement.instructionsinvest;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.services.billingservice.dto.placement.validation.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UploadInstructionsSInvestDataRequest {

    @JsonProperty(value = "IM Code")
    @NotBlank(message = "IM Code must not be blank", groups = AddValidationGroup.class)
    @Alphanumeric(message = "IM Code must contain only alphanumeric characters", groups = {AddValidationGroup.class, UpdateValidationGroup.class})
    private String imCode;

    @JsonProperty(value = "IM Name")
    @NotBlank(message = "IM Name must not be blank", groups = AddValidationGroup.class)
    private String imName;

    @JsonProperty(value = "Fund Code")
    @NotBlank(message = "Fund Code must not be blank", groups = AddValidationGroup.class)
    @Alphanumeric(message = "Fund Code must contain only alphanumeric characters", groups = {AddValidationGroup.class, UpdateValidationGroup.class})
    private String fundCode;

    @JsonProperty(value = "Fund Name")
    @NotBlank(message = "Fund Name must not be blank", groups = AddValidationGroup.class)
    private String fundName;

    @JsonProperty(value = "Placement Bank Code")
    @NotBlank(message = "Placement Bank Code must not be blank", groups = AddValidationGroup.class)
    @NumericOnly(message = "Placement Bank Code must contain only numeric digits", groups = {AddValidationGroup.class, UpdateValidationGroup.class})
    private String placementBankCode;

    @JsonProperty(value = "Placement Bank Name")
    @NotBlank(message = "Placement Bank Name must not be blank", groups = AddValidationGroup.class)
    private String placementBankName;

    @JsonProperty(value = "Placement Bank Cash Account Name")
    @NotBlank(message = "Placement Bank Cash Account Name must not be blank", groups = AddValidationGroup.class)
    private String placementBankCashAccountName;

    @JsonProperty(value = "Placement Bank Cash Account No")
    @NotBlank(message = "Placement Bank Cash Account No must not be blank", groups = AddValidationGroup.class)
    @Pattern(regexp = "^[^a-zA-Z]+$",  // Tolak semua huruf (a-z/A-Z)
            message = "Must not contain letters", groups = {AddValidationGroup.class, UpdateValidationGroup.class}
    )
    private String placementBankCashAccountNo;

    @JsonProperty(value = "CCY")
    @NotBlank(message = "Currency must not be blank", groups = AddValidationGroup.class)
    @AlphabetOnly(message = "Currency must contain only alphabetic characters or must be exactly 3 characters long", groups = {AddValidationGroup.class, UpdateValidationGroup.class})
    @Size(min = 3, max = 3, message = "Currency must contain only alphabetic or must be exactly 3 characters long", groups = {AddValidationGroup.class, UpdateValidationGroup.class})
    private String currency;

    @JsonProperty(value = "Principle")
    @NotBlank(message = "Principle must not be blank", groups = AddValidationGroup.class)
    @NumericOnly(message = "Principle must contain only numeric digits", groups = {AddValidationGroup.class, UpdateValidationGroup.class})
    private String principle;

    @JsonProperty(value = "Placement Date")
    @NotBlank(message = "Placement Date must not be blank", groups = AddValidationGroup.class)
    @NumericOnly(message = "Placement Date must contain only numeric digits", groups = {AddValidationGroup.class, UpdateValidationGroup.class})
    private String placementDate;

    @JsonProperty(value = "Reference No")
    @NotBlank(message = "Reference No must not be blank", groups = AddValidationGroup.class)
    @Alphanumeric(message = "Reference No must contain only alphanumeric characters", groups = {AddValidationGroup.class, UpdateValidationGroup.class})
    private String referenceNo;

    @JsonProperty(value = "SI Reference ID")
    @NotBlank(message = "SI Reference ID must not be blank", groups = AddValidationGroup.class)
    @Alphanumeric(message = "SI Reference ID must contain only alphanumeric characters", groups = {AddValidationGroup.class, UpdateValidationGroup.class})
    private String siReferenceId;

}
