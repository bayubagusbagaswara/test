package com.services.billingservice.service.impl;

import com.services.billingservice.dto.billing.BillingCalculationErrorMessageDTO;
import com.services.billingservice.dto.billing.BillingCalculationResponse;
import com.services.billingservice.dto.billing.BillingContextDate;
import com.services.billingservice.dto.core.CoreCalculateRequest;
import com.services.billingservice.dto.core.CoreTemplate8;
import com.services.billingservice.dto.core.CoreType10Parameter;
import com.services.billingservice.dto.mi.InvestmentManagementDTO;
import com.services.billingservice.enums.ApprovalStatus;
import com.services.billingservice.enums.BillingStatus;
import com.services.billingservice.model.*;
import com.services.billingservice.repository.BillingCoreRepository;
import com.services.billingservice.service.*;
import com.services.billingservice.utils.ConvertDateUtil;
import com.services.billingservice.utils.StringUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

import static com.services.billingservice.enums.FeeParameter.BILLING_PAYMENT_DUE_DATE;

@Slf4j
@Service
@RequiredArgsConstructor
public class Core10CalculateServiceImpl implements Core10CalculateService {

    private static final String GL_SAFEKEEPING_FEE = "GL Safekeeping Fee";
    private static final String GL_TRANSACTION_HANDLING = "Transaction Handling";

    private final BillingCustomerService customerService;
    private final SkTranService skTransactionService;
    private final SfValRgMonthlyService sfValRgMonthlyService;
    private final BillingNumberService billingNumberService;
    private final BillingCoreRepository billingCoreRepository;
    private final BillingMIService investmentManagementService;
    private final BillingFeeParameterService feeParameterService;
    private final ConvertDateUtil convertDateUtil;
    private final BillingGLCreditService glCreditService;

    @Override
    public synchronized String calculate(CoreCalculateRequest request) {
        log.info("Start core billing calculation type 10 with a data request: {}", request);

        /* initialize response data */
        Integer totalDataSuccess = 0;
        Integer totalDataFailed = 0;
        List<BillingCalculationErrorMessageDTO> errorMessageList = new ArrayList<>();

        /* initialize data request */
        Instant dateNow = Instant.now();
        String categoryUpperCase = request.getCategory().toUpperCase();
        String typeUpperCase = StringUtil.replaceBlanksWithUnderscores(request.getType());

        /* generate billing context date */
        BillingContextDate contextDate = convertDateUtil.getBillingContextDate(dateNow);

        /* get data fee parameters */
        String paymentDueDate = feeParameterService.getFeeDescriptionByName(BILLING_PAYMENT_DUE_DATE.getValue());

        /* get billing customer Core type 10 */
        List<BillingCustomer> billingCustomerList = customerService.getAllByBillingCategoryAndBillingType(categoryUpperCase, typeUpperCase);

        for (BillingCustomer customer : billingCustomerList) {
            try {
                String customerCode = customer.getCustomerCode();

                /* get data investment management */
                InvestmentManagementDTO investmentManagementDTO = investmentManagementService.getByCode(customer.getMiCode());

                /* get data sk transaction */
                List<SkTransaction> skTransactionList = skTransactionService.getAllByAidAndMonthAndYear(customerCode, contextDate.getMonthNameMinus1(), contextDate.getYearMinus1());

                /* get data sf val rg monthly */
                List<SfValRgMonthly> sfValRgMonthlyList = sfValRgMonthlyService.getAllByAidAndMonthAndYear(customerCode, contextDate.getMonthNameMinus1(), contextDate.getYearMinus1());

                /* get data GL credit*/
                BillingGlCredit glCredit = glCreditService.getByBillingTemplateAndGLCreditName(customer.getBillingTemplate(), GL_SAFEKEEPING_FEE);

                /* create billing core */
                BillingCore billingCore = buildBillingCore(contextDate, customer, investmentManagementDTO, paymentDueDate);

                /* create parameter core type 10 */
                CoreType10Parameter coreType10Parameter = new CoreType10Parameter(
                        sfValRgMonthlyList, skTransactionList, customer.getCustomerSafekeepingFee(),
                        customer.getCustomerTransactionHandling(), glCredit);

                /* calculation billing */
                CoreTemplate8 coreTemplate8 = calculationResult(coreType10Parameter);

                /* update billing core data to include calculated values */
                updateBillingCoreForCoreTemplate8(billingCore, coreTemplate8);

                /* create a billing number then set it to the billing core */
                String number = billingNumberService.generateSingleNumber(contextDate.getMonthNameNow(), contextDate.getYearNow());
                billingCore.setBillingNumber(number);

                /* check and delete existing billing data with the same month and year */
                Optional<BillingCore> existingBillingCore = billingCoreRepository.findByCustomerCodeAndSubCodeAndBillingCategoryAndBillingTypeAndMonthAndYear(
                        customerCode, customer.getSubCode(), customer.getBillingCategory(), customer.getBillingType(), contextDate.getMonthNameMinus1(), contextDate.getYearMinus1());

                /* check paid status. if it is FALSE, it can be regenerated */
                if (!existingBillingCore.isPresent() || Boolean.TRUE.equals(!existingBillingCore.get().getPaid())) {

                    /* delete billing data if it exists in the database */
                    existingBillingCore.ifPresent(this::deleteExistingBillingCore);

                    /* save to the database */
                    billingCoreRepository.save(billingCore);
                    billingNumberService.saveSingleNumber(number);
                    totalDataSuccess++;
                } else {
                    addErrorMessage(errorMessageList, customer.getCustomerCode(), "Billing already paid for period " + contextDate.getMonthNameMinus1() + " " + contextDate.getYearMinus1());
                    totalDataFailed++;
                }
            } catch (Exception e) {
                handleGeneralError(customer.getCustomerCode(), e, errorMessageList);
                totalDataFailed++;
            }
        }
        log.info("Total successfully calculations: {}, total failed calculations: {}", totalDataSuccess, totalDataFailed);
        BillingCalculationResponse billingCalculationResponse = new BillingCalculationResponse(totalDataSuccess, totalDataFailed, errorMessageList);
        return "Total successful calculations: " + billingCalculationResponse.getTotalDataSuccess() + ", total failed calculations: " + billingCalculationResponse.getTotalDataFailed();
    }

    private void updateBillingCoreForCoreTemplate8(BillingCore billingCore, CoreTemplate8 coreTemplate8) {
        billingCore.setSafekeepingValueFrequency(coreTemplate8.getSafekeepingValueFrequency());
        billingCore.setSafekeepingFee(coreTemplate8.getSafekeepingFee());
        billingCore.setSafekeepingAmountDue(coreTemplate8.getSafekeepingAmountDue());
        billingCore.setSafekeepingJournal(coreTemplate8.getSafekeepingJournal());
        billingCore.setTransactionHandlingValueFrequency(coreTemplate8.getTransactionHandlingValueFrequency());
        billingCore.setTransactionHandlingFee(coreTemplate8.getTransactionHandlingFee());
        billingCore.setTransactionHandlingAmountDue(coreTemplate8.getTransactionHandlingAmountDue());
        billingCore.setTransactionHandlingJournal(coreTemplate8.getTransactionHandlingJournal());
        billingCore.setTotalAmountDue(coreTemplate8.getTotalAmountDue());
    }

    private CoreTemplate8 calculationResult(CoreType10Parameter param) {
        BigDecimal safekeepingValueFrequency = calculateSafekeepingValueFrequency(param.getSfValRgMonthlyList());
        BigDecimal safekeepingAmountDue = calculateSafekeepingAmountDue(safekeepingValueFrequency, param.getCustomerSafekeepingFee());

        Integer transactionHandlingValueFrequency = calculateTransactionHandlingFrequency(param.getSkTransactionList());
        BigDecimal transactionHandlingAmountDue = calculateTransactionHandlingAmountDue(transactionHandlingValueFrequency, param.getTransactionHandlingFee());

        BigDecimal totalAmountDue = calculateTotalAmountDue(transactionHandlingAmountDue, safekeepingAmountDue);

        String safekeepingJournal = "GL " + String.valueOf(param.getGlCredit().getGlCreditAccountValue()) + " CC 9207";  // 713017
        String transactionHandlingJournal = "GL " + String.valueOf(param.getGlCredit().getGlCreditAccountValue()) + " CC 9207";  // 713017

        return CoreTemplate8.builder()
                .safekeepingValueFrequency(safekeepingValueFrequency)
                .safekeepingFee(param.getCustomerSafekeepingFee())
                .safekeepingAmountDue(safekeepingAmountDue)
                .safekeepingJournal(safekeepingJournal)
                .transactionHandlingValueFrequency(transactionHandlingValueFrequency)
                .transactionHandlingFee(param.getTransactionHandlingFee())
                .transactionHandlingAmountDue(transactionHandlingAmountDue)
                .transactionHandlingJournal(transactionHandlingJournal)
                .totalAmountDue(totalAmountDue)
                .build();
    }

    private static Integer calculateTransactionHandlingFrequency(List<SkTransaction> skTransactionList) {
        int totalTransactionHandling = skTransactionList.size();
        log.info("[Core Type 10] Total transaction handling: {}", totalTransactionHandling);
        return totalTransactionHandling;
    }

    private static BigDecimal calculateTransactionHandlingAmountDue(Integer transactionHandlingFrequency, BigDecimal transactionHandlingFee) {
        BigDecimal transactionHandlingAmountDue = new BigDecimal(transactionHandlingFrequency)
                .multiply(transactionHandlingFee)
                .setScale(0, RoundingMode.HALF_UP);
        log.info("[Core Type 10] Transaction handling amount due: {}", transactionHandlingAmountDue);
        return transactionHandlingAmountDue;
    }

    private static BigDecimal calculateSafekeepingValueFrequency(List<SfValRgMonthly> sfValRgMonthlyList) {
        List<SfValRgMonthly> latestEntries = sfValRgMonthlyList.stream()
                .filter(entry -> entry.getDate().equals(sfValRgMonthlyList.stream()
                        .map(SfValRgMonthly::getDate)
                        .max(Comparator.naturalOrder())
                        .orElse(null)))
                .collect(Collectors.toList());

        BigDecimal safekeepingValueFrequency = latestEntries.stream()
                .map(SfValRgMonthly::getMarketValue)
                .filter(Objects::nonNull)
                .reduce(BigDecimal.ZERO, BigDecimal::add)
                .setScale(0, RoundingMode.HALF_UP);

        log.info("[Core Type 10] Safekeeping value frequency: {}", safekeepingValueFrequency);
        return safekeepingValueFrequency;
    }

    private static BigDecimal calculateSafekeepingAmountDue(BigDecimal safekeepingValueFrequency, BigDecimal customerSafekeepingFee) {
//        log.info("Customer Safekeeping Fee: {}", customerSafekeepingFee);
//        BigDecimal safeKeepingAfterDivide100Percentage = customerSafekeepingFee
//                .divide(new BigDecimal(100), 4, RoundingMode.HALF_UP);

//        log.info("Safekeeping After Divide: {}", safeKeepingAfterDivide100Percentage);

        BigDecimal safekeepingAmountDue = safekeepingValueFrequency
                .multiply(customerSafekeepingFee)
                .divide(new BigDecimal(12), 0, RoundingMode.HALF_UP)
                .setScale(0, RoundingMode.HALF_UP);

        log.info("[Core Type 10] Safekeeping amount due: {}", safekeepingAmountDue);
        return safekeepingAmountDue;
    }

    private static BigDecimal calculateTotalAmountDue(BigDecimal transactionHandlingAmountDue, BigDecimal safekeepingAmountDue) {
        BigDecimal totalAmountDue = transactionHandlingAmountDue.add(safekeepingAmountDue);
        log.info("[Core Type 10] Total amount due: {}", totalAmountDue);
        return totalAmountDue;
    }

    private BillingCore buildBillingCore(BillingContextDate contextDate, BillingCustomer customer, InvestmentManagementDTO investmentManagementDTO, String paymentDueDate) {
        String glAccountDebit = "GL " + customer.getAccount() + " CC " + customer.getDebitTransfer();
        return BillingCore.builder()
                .createdAt(contextDate.getDateNow())
                .updatedAt(contextDate.getDateNow())
                .approvalStatus(ApprovalStatus.Pending)
                .billingStatus(BillingStatus.Generated)
                .customerCode(customer.getCustomerCode())
                .subCode(customer.getSubCode())
                .customerName(customer.getCustomerName())
                .month(contextDate.getMonthNameMinus1())
                .year(contextDate.getYearMinus1())
                .billingPeriod(contextDate.getBillingPeriod())
                .billingStatementDate(ConvertDateUtil.convertInstantToString(contextDate.getDateNow()))
                .billingPaymentDueDate(paymentDueDate)
                .billingCategory(customer.getBillingCategory())
                .billingType(customer.getBillingType())
                .billingTemplate(customer.getBillingTemplate())
                .investmentManagementCode(investmentManagementDTO.getCode())
                .investmentManagementName(investmentManagementDTO.getName())
                .investmentManagementAddress1(investmentManagementDTO.getAddress1())
                .investmentManagementAddress2(investmentManagementDTO.getAddress2())
                .investmentManagementAddress3(investmentManagementDTO.getAddress3())
                .investmentManagementAddress4(investmentManagementDTO.getAddress4())
                .investmentManagementEmail(investmentManagementDTO.getEmail())
                .investmentManagementUniqueKey(investmentManagementDTO.getUniqueKey())
                .account(glAccountDebit)
                .accountName(customer.getAccountName())
                .currency(customer.getCurrency())
                .gefuCreated(false)
                .paid(false)
                .build();
    }

    private void deleteExistingBillingCore(BillingCore existBillingCore) {
        String billingNumber = existBillingCore.getBillingNumber();
        billingCoreRepository.delete(existBillingCore);
        billingNumberService.deleteByBillingNumber(billingNumber);
    }

    private void handleGeneralError(String customerCode, Exception e, List<BillingCalculationErrorMessageDTO> errorMessageList) {
        addErrorMessage(errorMessageList, customerCode, e.getMessage());
    }

    private void addErrorMessage(List<BillingCalculationErrorMessageDTO> errorMessageList, String customerCode, String message) {
        List<String> stringList = new ArrayList<>();
        stringList.add(message);
        errorMessageList.add(new BillingCalculationErrorMessageDTO(customerCode, stringList));
    }

}
