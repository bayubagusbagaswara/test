package com.services.billingservice.service.impl;

import com.services.billingservice.model.RekapAccountBalance;
import com.services.billingservice.repository.RekapAccountBalanceRepository;
import com.services.billingservice.service.RekapAccountBalanceService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class RekapAccountBalanceServiceImpl implements RekapAccountBalanceService {

    private static final String REKAP_ACCOUNT_BALANCE = "REKAP_ACCOUNT_BALANCE";

    private final RekapAccountBalanceRepository rekapAccountBalanceRepository;

    @Override
    public Boolean existsRekapAccountBalance(final Integer year, final String monthName) {
        if (rekapAccountBalanceRepository.existsTableByName(REKAP_ACCOUNT_BALANCE).equals(0)) return false;
        if (!rekapAccountBalanceRepository.existsByYearAndMonth(year, monthName)) return false;
        return true;
    }

    @Override
    public List<RekapAccountBalance> findByYearAndMonthAndSellingAgentAndCurrencyOrderByIdAsc (final Integer year, final String monthName, final String sellingAgent, final String currency) {
        return rekapAccountBalanceRepository.findByYearAndMonthAndSellingAgentAndCurrencyOrderByIdAsc(year, monthName, sellingAgent, currency);
    }
}
