package com.services.billingservice.dto.placement.ncbsresponse;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CreateNCBSResponse {

    private LocalDateTime createdDate;

    private Long placementId;

    private LocalDate placementDate;

    private String siReferenceId;

    private String placementType;

    private String placementProcessType;

    private String placementTransferType;

    private String responseCode;

    private String responseMessage;

    private String providerSystem;

    private String statusCode;

    private String statusMessage;

    private String responseJson;

    private String ncbsStatus;

    private String referenceId;

    private String payUserRefNo;

    private String serviceType;

}
