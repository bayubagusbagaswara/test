package com.services.billingservice.controller.placement;

import com.services.billingservice.dto.ResponseDTO;
import com.services.billingservice.dto.approval.InputIdentifierRequest;
import com.services.billingservice.dto.placement.placementdata.PlacementDataDTO;
import com.services.billingservice.dto.placement.placementdata.PlacementDataResponse;
import com.services.billingservice.service.placement.PlacementDataService;
import com.services.billingservice.utils.ClientIPUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@RestController
@RequestMapping(path = "/api/placement/data")
@CrossOrigin(origins = "*", allowedHeaders = "*")
@Slf4j
@RequiredArgsConstructor
public class PlacementDataController {

    private final PlacementDataService placementDataService;

    @PostMapping(path = "/create")
    public ResponseEntity<ResponseDTO<PlacementDataResponse>> create(@RequestBody InputIdentifierRequest inputIdentifierRequest, HttpServletRequest servletRequest) {
        String inputIPAddress = ClientIPUtil.getClientIp(servletRequest);
        PlacementDataResponse placementDataResponse = placementDataService.create(inputIdentifierRequest.getInputerId(), inputIPAddress);
        ResponseDTO<PlacementDataResponse> response = ResponseDTO.<PlacementDataResponse>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(placementDataResponse)
                .build();
        return ResponseEntity.ok(response);
    }

    @GetMapping(path = "/current-date/approval-status")
    public ResponseEntity<ResponseDTO<List<PlacementDataDTO>>> getByPlacementDateAndApprovalStatusIsNullOrPending(@RequestParam("approvalStatus") String approvalStatus) {
        List<PlacementDataDTO> placementDataList = placementDataService.getByDateAndApprovalStatus(approvalStatus);
        ResponseDTO<List<PlacementDataDTO>> response = ResponseDTO.<List<PlacementDataDTO>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(placementDataList)
                .build();
        return ResponseEntity.ok(response);
    }

    @GetMapping(path = "/current-date")
    public ResponseEntity<ResponseDTO<List<PlacementDataDTO>>> getByPlacementDate() {
        List<PlacementDataDTO> placementDataDTOList = placementDataService.getByDate();
        ResponseDTO<List<PlacementDataDTO>> response = ResponseDTO.<List<PlacementDataDTO>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(placementDataDTOList)
                .build();
        return ResponseEntity.ok(response);
    }

}
