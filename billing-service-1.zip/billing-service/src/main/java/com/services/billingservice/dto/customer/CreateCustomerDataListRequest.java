package com.services.billingservice.dto.customer;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CreateCustomerDataListRequest {

    @JsonProperty(value = "Customer Code")
    @Pattern(regexp = "^[a-zA-Z0-9]*$", message = "Code must contain only alphanumeric characters")
    @NotBlank(message = "Customer Code cannot be empty")
    private String customerCode;

    @JsonProperty(value = "Sub Code")
    private String subCode;

    @JsonProperty(value = "Customer Name")
    @NotBlank(message = "Customer Name cannot be empty")
    private String customerName;

    @JsonProperty(value = "Billing Category")
    @NotBlank(message = "Billing Category cannot be empty")
    private String billingCategory;

    @JsonProperty(value = "Billing Type")
    @NotBlank(message = "Billing Type cannot be empty")
    private String billingType;

    @JsonProperty(value = "Billing Template")
    @NotBlank(message = "Billing Template cannot be empty")
    private String billingTemplate;

    @JsonProperty(value = "Currency")
    @NotBlank(message = "Currency cannot be empty")
    private String currency;

    @JsonProperty(value = "Code MI")
    @NotBlank(message = "MI Code cannot be empty")
    private String miCode;

    @JsonProperty(value = "Account")
    @Pattern(regexp = "^\\d*$", message = "Account must contain only numeric digits")
    @NotBlank(message = "Account cannot be empty")
    private String account;

    @JsonProperty(value = "Account Name")
    @NotBlank(message = "Account Name cannot be empty")
    private String accountName;

    @JsonProperty(value = "Cost Center Debit")
    @Pattern(regexp = "^\\d*$", message = "Cost Center Debit must contain only numeric digits")
    private String debitTransfer;

    @JsonProperty(value = "Cost Center")
    @Pattern(regexp = "^\\d*$", message = "Cost Center must contain only numeric digits")
    @NotBlank(message = "Cost Center cannot be empty")
    private String costCenter;

    @JsonProperty(value = "GL Account Hasil")
    @Pattern(regexp = "^\\d*$", message = "GL Account Hasil must contain only numeric digits")
    @NotBlank(message = "GL Account Hasil cannot be empty")
    private String glAccountHasil;

    @JsonProperty(value = "Minimum Fee")
    @Pattern(regexp = "^\\d+(?:\\.\\d+)?$", message = "Customer Minimum Fee must be in decimal format")
    @NotBlank(message = "Customer Minimum Fee cannot be empty")
    private String customerMinimumFee;

    @Pattern(regexp = "^\\d+(?:\\.\\d+)?$", message = "Customer Safekeeping Fee must be in decimal format")
    @JsonProperty(value = "Customer Safekeeping Fee")
    @NotBlank(message = "Customer Safekeeping Fee cannot be empty")
    private String customerSafekeepingFee;

    @JsonProperty(value = "Transaction Handling")
    @Pattern(regexp = "^\\d+(?:\\.\\d+)?$", message = "Transaction Handling must be in decimal format")
    private String customerTransactionHandling;

    @JsonProperty(value = "NPWP")
    @NotBlank(message = "NPWP Number cannot be empty")
    private String npwpNumber;

    @JsonProperty(value = "Nama NPWP")
    @NotBlank(message = "NPWP Name cannot be empty")
    private String npwpName;

    @JsonProperty(value = "Alamat NPWP")
    @NotBlank(message = "NPWP Address cannot be empty")
    private String npwpAddress;

    @JsonProperty(value = "KSEI Safe Code")
    @Pattern(regexp = "^[a-zA-Z0-9]*$", message = "KSEI Safe Code must contain only alphanumeric characters")
    private String kseiSafeCode;

    @JsonProperty(value = "Selling Agent")
    private String sellingAgent;

    @JsonProperty(value = "Is GL")
    @NotBlank(message = "Is GL cannot be empty")
    private String gl;

}
