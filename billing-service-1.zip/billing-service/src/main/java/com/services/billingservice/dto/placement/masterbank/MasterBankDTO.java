package com.services.billingservice.dto.placement.masterbank;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MasterBankDTO {

    private Long id;

    private String placementBankCode;

    private String placementBankName;

    private String biCode;

    private String bankType;

    private String branchCode;

}
