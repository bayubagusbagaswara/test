package com.services.billingservice.dto.placement.result;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

import javax.validation.ConstraintViolation;
import java.util.Set;

@Data
@AllArgsConstructor
@Builder
public class ResultGeneric<T> {

    private final Set<ConstraintViolation<Object>> violations;
    private final T data;

    public boolean hasViolations() {
        return !violations.isEmpty();
    }

    public boolean isExistingDataPresent() {
        return data != null;
    }

}
