package com.services.billingservice.dto.placement.depositapproval;

import com.services.billingservice.dto.approval.ApprovalIdentifierRequest;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.util.List;

@EqualsAndHashCode(callSuper = true)
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class DepositApprovalRequest extends ApprovalIdentifierRequest {

    private String statusRun;

    private List<Long> placementApprovalIds;

}
