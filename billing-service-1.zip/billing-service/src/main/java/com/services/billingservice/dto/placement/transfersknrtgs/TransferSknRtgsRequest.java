package com.services.billingservice.dto.placement.transfersknrtgs;

import com.services.billingservice.dto.placement.overbookingcasa.HeaderDTO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TransferSknRtgsRequest {

    private List<HeaderDTO> headers;

    private XferInfoFromDTO xferInfoFrom;

    private BdiXferXFOffDTO bdiXferXFOff;

}
