package com.services.billingservice.config.placement;

import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.concurrent.CustomizableThreadFactory;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@Configuration
@Slf4j
public class ThreadPoolConfig {

    @Bean(name = "singleThreadExecutor")
    public ExecutorService singleThreadExecutor() {
        return Executors.newSingleThreadExecutor(new CustomizableThreadFactory());
    }

    @Bean(name = "fixedThreadPool")
    public ExecutorService fixedThreadPool() {
        int poolSize = Runtime.getRuntime().availableProcessors();
        return Executors.newFixedThreadPool(
                poolSize,
                new CustomizableThreadFactory("fixed-pool-")
        );
    }

    @Bean(name = "cachedThreadPool")
    public ExecutorService cachedThreadPool() {
        return Executors.newCachedThreadPool(
                new CustomizableThreadFactory("cached-pool-")
        );
    }
}
