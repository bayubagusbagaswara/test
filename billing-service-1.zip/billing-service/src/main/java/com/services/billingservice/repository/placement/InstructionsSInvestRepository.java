package com.services.billingservice.repository.placement;

import com.services.billingservice.model.placement.InstructionsSInvest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Repository
public interface InstructionsSInvestRepository extends JpaRepository<InstructionsSInvest, Long> {

    boolean existsBySiReferenceId(String siReferenceId);

    Optional<InstructionsSInvest> findBySiReferenceId(String siReferenceId);

    @Query("SELECT p FROM InstructionsSInvest p WHERE p.placementDate = :date")
    List<InstructionsSInvest> findByPlacementDate(@Param("date") LocalDate date);

    @Query("SELECT a.siReferenceId FROM InstructionsSInvest a " +
            "WHERE EXISTS (SELECT 1 FROM InstructionsSInvest b " +
            "WHERE b.placementDate = :date " +
            "AND a.fundCode = b.fundCode " +
            "AND a.placementBankCode = b.placementBankCode " +
            "AND a.placementBankCashAccountNo = b.placementBankCashAccountNo " +
            "AND a.principle = b.principle " +
            "AND a.placementDate = :date " +
            "GROUP BY b.fundCode, b.placementBankCode, b.placementBankCashAccountNo, b.principle " +
            "HAVING COUNT(b) > 1)")
    List<String> findDuplicateDataPlacementReferenceIds(@Param("date") LocalDate date);
}
