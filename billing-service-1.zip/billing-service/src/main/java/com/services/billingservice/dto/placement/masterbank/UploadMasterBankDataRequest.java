package com.services.billingservice.dto.placement.masterbank;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.services.billingservice.dto.placement.validation.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UploadMasterBankDataRequest {

    @JsonProperty(value = "Placement Bank Code")
    @NotBlank(message = "Placement Bank Code must not be blank", groups = {AddValidationGroup.class, UpdateValidationGroup.class})
    @NumericOnly(message = "Placement Bank Code must contain only numeric digits", groups = {AddValidationGroup.class, UpdateValidationGroup.class})
    private String placementBankCode;

    @JsonProperty(value = "Placement Bank Name")
    @NotBlank(message = "Placement Bank Name must not be blank", groups = AddValidationGroup.class)
    private String placementBankName;

    @JsonProperty(value = "BI Code")
    @NotBlank(message = "BI Code must not be blank", groups = AddValidationGroup.class)
    @Alphanumeric(message = "BI Code must contain only alphanumeric characters", groups = {AddValidationGroup.class, UpdateValidationGroup.class})
    private String biCode;

    @JsonProperty(value = "Bank Type")
    @NotBlank(message = "Bank Type must not be blank", groups = AddValidationGroup.class)
    @ValidBankType(groups = {AddValidationGroup.class, UpdateValidationGroup.class})
    private String bankType;

    @JsonProperty(value = "Branch Code")
    @NotBlank(message = "Branch Code must not be blank", groups = AddValidationGroup.class)
    @NumericOnly(message = "Branch Code must contain only numeric digits", groups = {AddValidationGroup.class, UpdateValidationGroup.class})
    private String branchCode;

}
