package com.services.billingservice.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import javax.persistence.*;

@Entity
@Table(name = "billing_gl_credit")
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class BillingGlCredit {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "gl_billing_template")
    private String glBillingTemplate;

    @Column(name = "gl_credit_name")
    private String glCreditName;

    @Column(name = "gl_credit_account_value")
    private int glCreditAccountValue;

    private String jurnalType;

    private int jurnalSequence;
}
