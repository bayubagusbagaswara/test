package com.services.billingservice.config;

import org.apache.commons.lang3.StringUtils;
import org.modelmapper.AbstractConverter;
import org.modelmapper.Converter;
import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

@Configuration
public class ApplicationConfig {

    @Bean
    public ModelMapper modelMapper() {
        ModelMapper modelMapper = new ModelMapper();

        modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);
        modelMapper.getConfiguration().isSkipNullEnabled();

        modelMapper.addConverter(stringToBigDecimalConverter());
        modelMapper.addConverter(bigDecimalToStringConverter());
        modelMapper.addConverter(stringToLocalDateConverter());

        return modelMapper;
    }

    @Bean
    public Converter<String, BigDecimal> stringToBigDecimalConverter() {
        return new AbstractConverter<String, BigDecimal>() {
            protected BigDecimal convert(String source) {
                return !StringUtils.isEmpty(source)? new BigDecimal(source) : BigDecimal.ZERO;
            }
        };
    }

    @Bean
    public Converter<BigDecimal, String> bigDecimalToStringConverter() {
        return new AbstractConverter<BigDecimal, String>() {
            protected String convert(BigDecimal value) {
                if (BigDecimal.ZERO.compareTo(value) == 0) {
                    return "0";
                } else {
                    BigDecimal bigDecimal = value.stripTrailingZeros();
                    return bigDecimal.toPlainString();
                }
            }
        };
    }

    @Bean
    public Converter<Boolean, String> booleanToStringConverter() {
        return new AbstractConverter<Boolean, String>() {
            @Override
            protected String convert(Boolean source) {
                return source != null ? source.toString() : "false";
            }
        };
    }

    @Bean
    public Converter<String, LocalDate> stringToLocalDateConverter() {
        return new AbstractConverter<String, LocalDate>() {
            @Override
            protected LocalDate convert(String source) {
                return LocalDate.parse(source, DateTimeFormatter.ISO_DATE);
            }
        };
    }

}
