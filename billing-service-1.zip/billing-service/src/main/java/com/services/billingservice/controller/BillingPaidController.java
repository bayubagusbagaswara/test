package com.services.billingservice.controller;

import com.services.billingservice.dto.ResponseDTO;
import com.services.billingservice.dto.billing.UpdatePaidRequest;
import com.services.billingservice.service.BillingPaidService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(path = "/api/paid")
@CrossOrigin(origins = "*", allowedHeaders = "*")
@RequiredArgsConstructor
@Slf4j
public class BillingPaidController {

    private final BillingPaidService billingPaidService;

    @PostMapping(path = "/update")
    public ResponseEntity<ResponseDTO<String>> updatePaidStatus(@RequestBody UpdatePaidRequest updatePaidRequest) {
        String stringMessage = billingPaidService.updatePaidStatus(updatePaidRequest);
        ResponseDTO<String> response = ResponseDTO.<String>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(stringMessage)
                .build();
        return ResponseEntity.ok(response);
    }

}
