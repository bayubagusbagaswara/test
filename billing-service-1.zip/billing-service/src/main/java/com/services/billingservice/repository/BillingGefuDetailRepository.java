package com.services.billingservice.repository;

import com.services.billingservice.model.BillingGefuProcessDetail;
import com.services.billingservice.model.BillingGefuProcessHistory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
public interface BillingGefuDetailRepository extends JpaRepository<BillingGefuProcessDetail, Long> {

    @Query(value = "SELECT * FROM billing_gefu_process_detail  " +
            "WHERE fileName = :fileName ", nativeQuery = true)
    List<BillingGefuProcessDetail> findAllByFileName(
            @Param("fileName") String fileName);

    @Query(value = "SELECT * FROM billing_gefu_process_detail  " +
            "WHERE gefuProcessHistory = :gefuProcessHistory ", nativeQuery = true)
    List<BillingGefuProcessDetail> findAllByGefuProcessHistory(
            @Param("gefuProcessHistory") long gefuProcessHistory);

    @Query(value = "SELECT * FROM billing_gefu_process_detail  " +
            "WHERE gefuProcessHistory = :gefuProcessHistory and reference = :reference", nativeQuery = true)
    BillingGefuProcessDetail findByGefuProcessHistoryAndReference(
            @Param("gefuProcessHistory") long gefuProcessHistory,
            @Param("reference") String reference);

    @Query(value = "SELECT * FROM billing_gefu_process_detail  " +
            "WHERE id = :id ", nativeQuery = true)
    BillingGefuProcessDetail findById(
            @Param("id") long id);

    @Transactional
    @Modifying
    @Query(value = "UPDATE billing_gefu_process_detail set approval_status = 'Rejected', approver_id = :approverId, " +
            "approve_date=GETDATE() where gefuProcessHistory = :historyId", nativeQuery = true)
    void rejectGefuDetail(@Param("historyId") long id,
                          @Param("approverId") String approverId);


}
