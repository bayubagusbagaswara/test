package com.services.billingservice.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "rekap_data_transaksi")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RetailTransaction {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "settlement_date")
    private LocalDate settlementDate;

    @Column(name = "selling_agent")
    private String sellingAgent;

    @Column(name = "month")
    private String month;

    @Column(name = "year")
    private Integer year;

    @Column(name = "currency")
    private String currency;

    @Column(name = "security_code")
    private String securityCode;

    @Column(name = "sell_purchase")
    private String sellPurchase;

    @Column(name = "aid")
    private String aid;

    @Column(name = "name")
    private String name;

    @Column(name = "nominal")
    private String nominal;

    @Column(name = "account_number")
    private String accountNumber;

    @Column(name = "cif")
    private String cif;

    @Column(name = "branch_code")
    private String branchCode;

    @Column(name = "trade_date")
    private LocalDate tradeDate;

    @Column(name = "nation_code")
    private String nationCode;

    @Column(name = "sid")
    private String sid;

}
