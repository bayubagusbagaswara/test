package com.services.billingservice.repository;

import com.services.billingservice.bean.RetailCsaHoldingBean;
import com.services.billingservice.enums.Currency;
import com.services.billingservice.model.BillingSellingAgentData;
import com.services.billingservice.model.RekapAccountBalance;
import com.services.billingservice.service.RekapAccountBalanceService;
import com.services.billingservice.utils.ConvertDateUtil;
import com.services.billingservice.utils.OpenCsv.OpenCsvBean;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;

import java.util.*;

@Repository
@Slf4j
@RequiredArgsConstructor
public class CsaDataRepositoryImpl implements CsaDataRepository {

    @Value("${file.path.holding.data.csa}")
    private String folderPath;

    private static final String REKAP_ACCOUNT_BALANCE = "REKAP_ACCOUNT_BALANCE";
    private static final String CSV_EXT = ".csv";
    private static final String UNDERSCORE_SEPARATOR = "_";
    protected static final String PATH_SEPARATOR = "\\";

    private final RetailAccountBalanceRepository retailAccountBalanceRepository;
    private final RetailTransactionRepository retailTransactionRepository;

    private final RekapAccountBalanceService rekapAccountBalanceService;
    private final ConvertDateUtil convertDateUtil;

    private final BillingSellingAgentDataRepository billingSellingAgentDataRepository;

    @Override
    public void executeQuerySpRekapAccountBalance() {
        try {
            retailAccountBalanceRepository.execSPAccountBalance();

            final Map<String, String> monthMinus1 = convertDateUtil.getMonthMinus1();
            final String monthName = monthMinus1.get("monthName");
            final String monthValue = monthMinus1.get("monthValue");
            final int year = Integer.parseInt(monthMinus1.get("year"));
            Arrays.stream(Currency.values())
                    .map(Currency::getValue)
                    .forEach(ccy -> {
                        billingSellingAgentDataRepository.findAll().stream()
                                .map(BillingSellingAgentData::getCode)
                                .forEach(sellingAgent -> {
                                    try {
                                        generateCsv(year, monthName, monthValue, sellingAgent, ccy);
                                    } catch (Exception e) {
                                        throw new RuntimeException(e);
                                    }
                                });
                    });
            log.info("Stored procedure executed successfully");
        } catch (Exception e) {
            log.error("Error executing stored procedure: {}", e.getMessage());
        }
    }

    @Override
    public void executeQuerySpRekapRekapDataTransaksi() {
        try {
            retailTransactionRepository.execSPRekapDataTransaksi();
            log.info("Stored procedure executed successfully");
        } catch (Exception e) {
            log.error("Error executing stored procedure: {}", e.getMessage());
        }
    }

    private void generateCsv(final Integer year, final String monthName, final String monthValue, final String sellingAgent, final String currency) throws Exception {
        if (rekapAccountBalanceService.existsRekapAccountBalance(year, monthName)) {
            final String folder = folderPath + year + monthValue;
            final String fileName = REKAP_ACCOUNT_BALANCE + UNDERSCORE_SEPARATOR + sellingAgent + UNDERSCORE_SEPARATOR + currency + UNDERSCORE_SEPARATOR + year + monthValue + CSV_EXT;
            List<RekapAccountBalance> rekapAccountBalances = rekapAccountBalanceService.findByYearAndMonthAndSellingAgentAndCurrencyOrderByIdAsc(year, monthName, sellingAgent, currency);
            OpenCsvBean<RekapAccountBalance, RetailCsaHoldingBean> openCsvBean = new OpenCsvBean<>();
            openCsvBean.writeCsvFromBean(folder, fileName, rekapAccountBalances, RetailCsaHoldingBean.class);
        }
    }
}
