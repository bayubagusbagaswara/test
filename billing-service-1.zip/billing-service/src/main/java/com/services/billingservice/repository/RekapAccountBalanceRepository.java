package com.services.billingservice.repository;

import com.services.billingservice.model.RekapAccountBalance;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface RekapAccountBalanceRepository extends JpaRepository<RekapAccountBalance, Long> {
    @Query(value = "select case when count(*) > 0 then 1 else 0 end " +
            "from sysobjects where name = :tableName", nativeQuery = true)
    Integer existsTableByName(@Param("tableName") final String tableName);

    Boolean existsByYearAndMonth(final Integer year, final String monthName);

    List<RekapAccountBalance> findByYearAndMonthAndSellingAgentAndCurrencyOrderByIdAsc(final Integer year, final String monthName, final String sellingAgent, final String currency);
}
