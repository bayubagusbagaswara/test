package com.services.billingservice.dto.feeschedule;

import com.services.billingservice.dto.approval.InputIdentifierRequest;
import lombok.*;
import lombok.experimental.SuperBuilder;

import javax.validation.constraints.NotBlank;

@EqualsAndHashCode(callSuper = true)
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class CreateFeeScheduleRequest extends InputIdentifierRequest {

    @NotBlank(message = "Fee Minimum cannot be blank")
    private String feeMinimum;

    @NotBlank(message = "Fee Maximum cannot be blank")
    private String feeMaximum;

    @NotBlank(message = "Fee Amount cannot be blank")
    private String feeAmount;

}
