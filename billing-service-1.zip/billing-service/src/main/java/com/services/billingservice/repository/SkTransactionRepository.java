package com.services.billingservice.repository;

import com.services.billingservice.model.SkTransaction;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface SkTransactionRepository extends JpaRepository<SkTransaction, Long> {

    @Query(value = "SELECT * FROM bill_sktran WHERE portfolio_code = :portfolioCode", nativeQuery = true)
    List<SkTransaction> findAllByPortfolioCode(@Param("portfolioCode") String portfolioCode);

    @Query(value = "SELECT * FROM bill_sktran " +
            "WHERE portfolio_code = :portfolioCode " +
            "AND system = :system", nativeQuery = true)
    List<SkTransaction> findAllByPortfolioCodeAndSystem(
            @Param("portfolioCode") String portfolioCode,
            @Param("system") String system
    );

    @Query(value = "SELECT * FROM bill_sktran " +
            "WHERE portfolio_code = :portfolioCode " +
            "AND month = :monthName " +
            "AND year = :year " +
            "ORDER BY portfolio_code, security_short_name, trade_date, settlement_date", nativeQuery = true)
    List<SkTransaction> findAllByPortfolioCodeAndMonthAndYear(
            @Param("portfolioCode") String portfolioCode,
            @Param("monthName") String monthName,
            @Param("year") int year);

    @Query(value = "SELECT * FROM bill_sktran " +
            "WHERE portfolio_code = :portfolioCode " +
            "AND month BETWEEN :monthStart AND :monthEnd " +
            "AND year BETWEEN :yearStart AND :yearEnd " +
            "ORDER BY portfolio_code, security_short_name, trade_date, settlement_date", nativeQuery = true)
    List<SkTransaction> findAllByPortfolioCodeAndMonthBetweenAndYearBetween(
            @Param("portfolioCode") String portfolioCode,
            @Param("monthStart") String monthStart,
            @Param("monthEnd") String monthEnd,
            @Param("yearStart") String yearStart,
            @Param("yearEnd") String yearEnd
    );

    @Query(value = "EXEC sp_detail_account_transaction :date, :aid, :sellingAgent, :currency", nativeQuery = true)
    List<SkTransaction> getAllRetailByAidAndTypeAndCurrencyAndPeriod(
            @Param("aid") String aid,
            @Param("sellingAgent") String sellingAgent,
            @Param("currency") String currency,
            @Param("date") LocalDate date
    );

    @Transactional
    @Modifying
    @Query(value = "DELETE FROM SkTransaction s WHERE s.month = :month AND s.year = :year")
    void deleteByMonthAndYear(@Param("month") String month, @Param("year") int year);

}
