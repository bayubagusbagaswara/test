package com.services.billingservice.mapper.placement;

import com.services.billingservice.dto.placement.placementapproval.PlacementApprovalDTO;
import com.services.billingservice.model.placement.PlacementApproval;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Mapper(componentModel = "spring")
public interface PlacementApprovalMapper {

    @Named("bigDecimalToString")
    default String bigDecimalToString(BigDecimal value) {
        return value != null ? value.toPlainString() : null;
    }

    @Named("localDateToString")
    default String localDateToString(LocalDate localDate) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd");
        LocalDate date = LocalDate.parse(localDate.toString());
        return date.format(formatter);
    }

    @Mapping(source = "id", target = "id")
    @Mapping(source = "principle", target = "principle", qualifiedByName = "bigDecimalToString")
    @Mapping(source = "placementDate", target = "placementDate", qualifiedByName = "localDateToString")
    @Mapping(source = "approvalStatus", target = "approvalStatus")
    @Mapping(source = "inputerId", target = "inputId")
    @Mapping(source = "inputIPAddress", target = "inputIPAddress")
    @Mapping(source = "inputDate", target = "inputDate")
    @Mapping(source = "approverId", target = "approveId")
    @Mapping(source = "approveIPAddress", target = "approveIPAddress")
    @Mapping(source = "approveDate", target = "approveDate")
    PlacementApprovalDTO toDTO(PlacementApproval placementApproval);

    List<PlacementApprovalDTO> toDTOList(List<PlacementApproval> all);

}
