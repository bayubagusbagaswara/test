package com.services.billingservice.dto.reportgenerator;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BillingReportGeneratorDTO {

    private Long id;

    private String investmentManagementName;

    private String customerCode;

    private String customerName;

    private String category;

    private String type;

    private String fileName;

    private String filePath;

    private String period;

    private String status;

    private String desc;

}
