package com.services.billingservice.service;

import com.services.billingservice.dto.fund.FeeReportRequest;

import java.util.List;

public interface FundCalculateService {

    String calculate(List<FeeReportRequest> request, String monthYear);

}
