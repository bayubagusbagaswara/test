package com.services.billingservice.service.impl;

import com.services.billingservice.dto.monthyear.MonthYearDTO;
import com.services.billingservice.dto.core.BillingCoreDTO;
import com.services.billingservice.dto.core.CoreCalculateRequest;
import com.services.billingservice.dto.pdf.GeneratePDFResponse;
import com.services.billingservice.enums.*;
import com.services.billingservice.exception.GeneratePDFBillingException;
import com.services.billingservice.mapper.BillingCoreMapper;
import com.services.billingservice.model.BillingCore;
import com.services.billingservice.model.BillingReportGenerator;
import com.services.billingservice.repository.BillingCoreRepository;
import com.services.billingservice.service.BillingFeeParameterService;
import com.services.billingservice.service.BillingReportGeneratorService;
import com.services.billingservice.service.CoreGeneratePDFService;
import com.services.billingservice.utils.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.thymeleaf.context.Context;
import org.thymeleaf.spring5.SpringTemplateEngine;

import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Instant;
import java.time.Month;
import java.util.List;

import static com.services.billingservice.constant.CoreConstant.*;
import static com.services.billingservice.constant.CoreConstant.SAFEKEEPING_FEE_PERIOD;

@Service
@RequiredArgsConstructor
@Slf4j
public class CoreGeneratePDFServiceImpl implements CoreGeneratePDFService {

    @Value("${base.path.billing.core}")
    private String basePathBillingCore;

    @Value("${base.path.billing.image}")
    private String folderPathImage;

    private static final String DELIMITER = "/";

    private final BillingCoreRepository billingCoreRepository;
    private final SpringTemplateEngine templateEngine;
    private final PdfGenerator pdfGenerator;
    private final ConvertDateUtil convertDateUtil;
    private final BillingCoreMapper billingCoreMapper;
    private final BillingReportGeneratorService billingReportGeneratorService;
    private final BillingFeeParameterService feeParameterService;

    @Override
    public String generatePDF(CoreCalculateRequest request) {
        log.info("Start generate PDF Billing Core type: {}", request.getType());
        String categoryUpperCase = request.getCategory().toUpperCase();
        String typeUpperCase = StringUtil.replaceBlanksWithUnderscores(request.getType());
        String[] monthFormat = convertDateUtil.convertToYearMonthFormat(request.getMonthYear());
        String monthName = monthFormat[0];
        int year = Integer.parseInt(monthFormat[1]);

        try {
            String approvalStatus = ApprovalStatus.Approved.getStatus();

            List<BillingCore> billingCoreList = billingCoreRepository.findAllByBillingCategoryAndBillingTypeAndMonthAndYearAndApprovalStatus(
                    categoryUpperCase, typeUpperCase, monthName, year, approvalStatus
            );

            GeneratePDFResponse generatePDFResponse = generateAndSavePdfStatements(billingCoreList);

            return "Successfully created a PDF file for Billing Fund with total data success: " + generatePDFResponse.getTotalDataSuccess()
                    + ", and total data failed: " + generatePDFResponse.getTotalDataFailed();
        } catch (Exception e) {
            log.error("Error when generate PDF Billing Core type: {}, message: {}", typeUpperCase, e.getMessage(), e);
            throw new GeneratePDFBillingException("Error when generate PDF Billing Core type " + typeUpperCase + " : " + e.getMessage());
        }
    }

    private GeneratePDFResponse generateAndSavePdfStatements(List<BillingCore> billingCoreList) {
        log.info("Start generate and save pdf statements Billing Core with size: {}", billingCoreList.size());
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        Instant dateNow = Instant.now();
        List<BillingCoreDTO> billingCoreDTOList = billingCoreMapper.mapToDTOList(billingCoreList);

        for (BillingCoreDTO billingCoreDTO : billingCoreDTOList) {
            log.info("Start generate and save PDF statements Billing Core type: {}, and customer Code: {}", billingCoreDTO.getBillingType(), billingCoreDTO.getCustomerCode());

            String investmentManagementCode = billingCoreDTO.getInvestmentManagementCode();
            String investmentManagementName = billingCoreDTO.getInvestmentManagementName();
            String investmentManagementEmail = billingCoreDTO.getInvestmentManagementEmail();
            String investmentManagementUniqueKey = billingCoreDTO.getInvestmentManagementUniqueKey();

            String customerCode = billingCoreDTO.getCustomerCode();
            String subCode = billingCoreDTO.getSubCode();
            String customerName = billingCoreDTO.getCustomerName();
            String currency = billingCoreDTO.getCurrency();
            String billingCategory = billingCoreDTO.getBillingCategory();
            String billingType = billingCoreDTO.getBillingType();
            String billingPeriod = billingCoreDTO.getBillingPeriod();
            String billingNumber = billingCoreDTO.getBillingNumber();

            MonthYearDTO monthYearDTO = convertDateUtil.parseBillingPeriodToLocalDate(billingCoreDTO.getMonth() + " " + billingCoreDTO.getYear());
            String yearMonthFormat = monthYearDTO.getYear() + monthYearDTO.getMonthValue();
            String filePath;
            String fileName = generateFileName(customerCode, subCode, billingNumber);

            /* get month and year */
            int year = monthYearDTO.getYear();
            String monthName = monthYearDTO.getMonthName();

            /* tentukan folder path */
            String folderPath = basePathBillingCore + yearMonthFormat + DELIMITER + investmentManagementCode;

            /* tentukan file path */
            filePath = folderPath + DELIMITER + fileName;

            try {
                /* create folder to save pdf file */
                Path folderPathObj = Paths.get(folderPath);
                Files.createDirectories(folderPathObj);

                deleteFilesWithCustomerCode(folderPathObj, customerCode, subCode);

                /* render data to thymeleaf and save pdf */
                /* check billing type is 8 */
                if (BillingType.TYPE_8.getValue().equalsIgnoreCase(billingType)) {
                    for (int i = 0; i < 2; i++) {
                        String htmlContent = renderThymeleafTemplate(billingCoreDTO, i);
                        byte[] pdfBytes = pdfGenerator.generatePdfFromHtml(htmlContent);
                        if (i == 1) {
                            String fileNameDuplicate = customerCode + "_DUPLICATE.pdf";
                            savePdf(pdfBytes, folderPath, fileNameDuplicate);
                        } else {
                            savePdf(pdfBytes, folderPath, fileName);
                        }
                    }
                } else {
                    String htmlContent = renderThymeleafTemplate(billingCoreDTO, 0);
                    byte[] pdfBytes = pdfGenerator.generatePdfFromHtml(htmlContent);
                    savePdf(pdfBytes, folderPath, fileName);
                }

                /* check and delete existing report generator */
                billingReportGeneratorService.checkingExistingBillingReportGenerator(
                        customerCode, billingCategory, billingType, currency, billingCoreDTO.getMonth(), Integer.parseInt(billingCoreDTO.getYear())
                );

                /* create report generator for saving success process */
                BillingReportGenerator reportGenerator = BillingReportGenerator.builder()
                        .createdAt(dateNow)
                        .investmentManagementName(investmentManagementName)
                        .investmentManagementEmail(investmentManagementEmail)
                        .investmentManagementUniqueKey(investmentManagementUniqueKey)
                        .customerCode(customerCode)
                        .customerName(customerName)
                        .category(billingCategory)
                        .type(billingType)
                        .period(billingPeriod)
                        .month(monthName)
                        .year(year)
                        .fileName(fileName)
                        .filePath(filePath)
                        .status(ReportGeneratorStatus.SUCCESS.getStatus())
                        .desc("Successfully generate and save PDF statements with customer code: " + customerCode)
                        .investmentManagementCode(investmentManagementCode)
                        .currency(currency)
                        .build();
                BillingReportGenerator generator = billingReportGeneratorService.saveSingleData(reportGenerator);
                log.info("Successfully create report generator with id: {}", generator.getId());
                totalDataSuccess++;
            } catch (Exception e) {
                log.error("Error creating folder or saving PDF: {}", e.getMessage(), e);
                /* create report generator for saving failed process */
                BillingReportGenerator reportGenerator = BillingReportGenerator.builder()
                        .createdAt(dateNow)
                        .investmentManagementName(investmentManagementName)
                        .investmentManagementEmail(investmentManagementEmail)
                        .investmentManagementUniqueKey(investmentManagementUniqueKey)
                        .customerCode(customerCode)
                        .customerName(customerName)
                        .category(billingCategory)
                        .type(billingType)
                        .period(billingPeriod)
                        .month(monthName)
                        .year(year)
                        .fileName(fileName)
                        .filePath(folderPath)
                        .status(ReportGeneratorStatus.FAILED.getStatus())
                        .desc(e.getMessage())
                        .investmentManagementCode(investmentManagementCode)
                        .currency(currency)
                        .build();
                BillingReportGenerator generator = billingReportGeneratorService.saveSingleData(reportGenerator);
                log.info("Successfully create report generator with id: {}", generator.getId());
                totalDataFailed++;
            }
        }
        return new GeneratePDFResponse(totalDataSuccess, totalDataFailed);
    }

    private String renderThymeleafTemplate(BillingCoreDTO billingCoreDTO, Integer value) {
        Context context = new Context();

        context.setVariable(BILLING_NUMBER, billingCoreDTO.getBillingNumber());
        context.setVariable(BILLING_PERIOD, billingCoreDTO.getBillingPeriod());
        context.setVariable(BILLING_STATEMENT_DATE, billingCoreDTO.getBillingStatementDate());
        context.setVariable(BILLING_PAYMENT_DUE_DATE, billingCoreDTO.getBillingPaymentDueDate());
        context.setVariable(BILLING_CATEGORY, billingCoreDTO.getBillingCategory());
        context.setVariable(BILLING_TYPE, billingCoreDTO.getBillingType());
        context.setVariable(BILLING_TEMPLATE, billingCoreDTO.getBillingTemplate());
        context.setVariable(INVESTMENT_MANAGEMENT_NAME, billingCoreDTO.getInvestmentManagementName());
        context.setVariable(INVESTMENT_MANAGEMENT_ADDRESS_1, billingCoreDTO.getInvestmentManagementAddress1());
        context.setVariable(INVESTMENT_MANAGEMENT_ADDRESS_2, billingCoreDTO.getInvestmentManagementAddress2());
        context.setVariable(INVESTMENT_MANAGEMENT_ADDRESS_3, billingCoreDTO.getInvestmentManagementAddress3());
        context.setVariable(INVESTMENT_MANAGEMENT_ADDRESS_4, billingCoreDTO.getInvestmentManagementAddress4());

        context.setVariable(CUSTOMER_NAME, billingCoreDTO.getCustomerName());
        context.setVariable(ACCOUNT_NAME, billingCoreDTO.getAccountName());
        context.setVariable(ACCOUNT_NUMBER, billingCoreDTO.getAccount());

        String bankAccountBDI = feeParameterService.getFeeDescriptionByName(FeeParameter.BANK_ACCOUNT_BDI.getValue());
        context.setVariable(ACCOUNT_BANK, bankAccountBDI);

        context.setVariable(TRANSACTION_HANDLING_VALUE_FREQUENCY, billingCoreDTO.getTransactionHandlingValueFrequency());
        context.setVariable(TRANSACTION_HANDLING_FEE, billingCoreDTO.getTransactionHandlingFee());
        context.setVariable(TRANSACTION_HANDLING_AMOUNT_DUE, billingCoreDTO.getTransactionHandlingAmountDue());
        context.setVariable(SAFEKEEPING_VALUE_FREQUENCY, billingCoreDTO.getSafekeepingValueFrequency());
        context.setVariable(SAFEKEEPING_FEE, billingCoreDTO.getSafekeepingFee());
        context.setVariable(SAFEKEEPING_AMOUNT_DUE, billingCoreDTO.getSafekeepingAmountDue());
        context.setVariable(SUB_TOTAL, billingCoreDTO.getSubTotal());
        context.setVariable(VAT_FEE, billingCoreDTO.getVatFee());
        context.setVariable(VAT_AMOUNT_DUE, billingCoreDTO.getVatAmountDue());
        context.setVariable(TOTAL_AMOUNT_DUE, billingCoreDTO.getTotalAmountDue());

        context.setVariable(JOURNAL_CREDIT_TO, billingCoreDTO.getJournalCreditTo());
        context.setVariable(KSEI_SAFEKEEPING_AMOUNT_DUE, billingCoreDTO.getKseiSafekeepingAmountDue());
        context.setVariable(KSEI_TRANSACTION_VALUE_FREQUENCY, billingCoreDTO.getKseiTransactionValueFrequency());
        context.setVariable(KSEI_TRANSACTION_FEE, billingCoreDTO.getKseiTransactionFee());
        context.setVariable(KSEI_TRANSACTION_AMOUNT_DUE, billingCoreDTO.getKseiTransactionAmountDue());
        context.setVariable(BIS4_TRANSACTION_VALUE_FREQUENCY, billingCoreDTO.getBis4TransactionValueFrequency());
        context.setVariable(BIS4_TRANSACTION_FEE, billingCoreDTO.getBis4TransactionFee());
        context.setVariable(BIS4_TRANSACTION_AMOUNT_DUE, billingCoreDTO.getBis4TransactionAmountDue());

        context.setVariable(SAFEKEEPING_FEE_JOURNAL, billingCoreDTO.getSafekeepingFeeJournal());
        context.setVariable(TRANSACTION_HANDLING_JOURNAL, billingCoreDTO.getTransactionHandlingJournal());

        context.setVariable(ADMINISTRATION_SET_UP_ITEM, billingCoreDTO.getAdministrationSetUpItem());
        context.setVariable(ADMINISTRATION_SET_UP_FEE, billingCoreDTO.getAdministrationSetUpFee());
        context.setVariable(ADMINISTRATION_SET_UP_AMOUNT_DUE, billingCoreDTO.getAdministrationSetUpAmountDue());
        context.setVariable(SIGNING_REPRESENTATION_ITEM, billingCoreDTO.getSigningRepresentationItem());
        context.setVariable(SIGNING_REPRESENTATION_FEE, billingCoreDTO.getSigningRepresentationFee());
        context.setVariable(SIGNING_REPRESENTATION_AMOUNT_DUE, billingCoreDTO.getSigningRepresentationAmountDue());
        context.setVariable(SECURITY_AGENT_ITEM, billingCoreDTO.getSecurityAgentItem());
        context.setVariable(SECURITY_AGENT_FEE, billingCoreDTO.getSecurityAgentFee());
        context.setVariable(SECURITY_AGENT_AMOUNT_DUE, billingCoreDTO.getSecurityAgentAmountDue());
        context.setVariable(TRANSACTION_HANDLING_ITEM, billingCoreDTO.getTransactionHandlingItem());
        context.setVariable(SAFEKEEPING_ITEM, billingCoreDTO.getSafekeepingItem());
        context.setVariable(OTHER_ITEM, billingCoreDTO.getOtherItem());
        context.setVariable(OTHER_FEE, billingCoreDTO.getOtherFee());
        context.setVariable(OTHER_AMOUNT_DUE, billingCoreDTO.getOtherAmountDue());

        if (BillingType.TYPE_7.getValue().equalsIgnoreCase(billingCoreDTO.getBillingType())) {
            String swiftCode = feeParameterService.getFeeDescriptionByName(FeeParameter.CORE_TYPE_7_SWIFT_CODE.getValue());
            context.setVariable(SWIFT_CODE, swiftCode); // move to parameter
        }

        if (BillingType.TYPE_8.getValue().equalsIgnoreCase(billingCoreDTO.getBillingType())) {

            context.setVariable(SAFEKEEPING_FEE_PERIOD, billingCoreDTO.getBillingPeriod());

            String accountNumberCBEST = feeParameterService.getFeeDescriptionByName(FeeParameter.CORE_TYPE_8_ACCOUNT_NUMBER_CBEST.getValue());
            context.setVariable(ACCOUNT_NUMBER_CBEST, accountNumberCBEST);

            String corrBank = feeParameterService.getFeeDescriptionByName(FeeParameter.CORE_TYPE_8_CORR_BANK.getValue());
            context.setVariable(CORR_BANK, corrBank);

            String swiftCode = feeParameterService.getFeeDescriptionByName(FeeParameter.CORE_TYPE_8_SWIFT_CODE.getValue());
            context.setVariable(SWIFT_CODE, swiftCode);

            String corporateName = feeParameterService.getFeeDescriptionByName(FeeParameter.CORE_TYPE_8_CORPORATE_NAME.getValue());
            context.setVariable(CORPORATE_NAME, corporateName);

            String corporateAddress1 = feeParameterService.getFeeDescriptionByName(FeeParameter.CORE_TYPE_8_CORPORATE_ADDRESS_1.getValue());
            context.setVariable(CORPORATE_ADDRESS_1, corporateAddress1);

            String corporateAddress2 = feeParameterService.getFeeDescriptionByName(FeeParameter.CORE_TYPE_8_CORPORATE_ADDRESS_2.getValue());
            context.setVariable(CORPORATE_ADDRESS_2, corporateAddress2);

            String corporateAddress3 = feeParameterService.getFeeDescriptionByName(FeeParameter.CORE_TYPE_8_CORPORATE_ADDRESS_3.getValue());
            context.setVariable(CORPORATE_ADDRESS_3, corporateAddress3);

            String corporateAddress4 = feeParameterService.getFeeDescriptionByName(FeeParameter.CORE_TYPE_8_CORPORATE_ADDRESS_4.getValue());
            context.setVariable(CORPORATE_ADDRESS_4, corporateAddress4);
        }

        String imageUrlHeader = "file:///" + folderPathImage + "/logo.png";
        String imageUrlFooter = "file:///" + folderPathImage + "/footer.png";
        context.setVariable(IMAGE_URL_HEADER, imageUrlHeader);
        context.setVariable(IMAGE_URL_FOOTER, imageUrlFooter);

        String billingTemplate;
        if (value.equals(0)) {
            billingTemplate = billingCoreDTO.getBillingTemplate();
        } else {
            billingTemplate = BillingTemplate.CORE_TEMPLATE_6_DUPLICATE.getValue();
        }

        return templateEngine.process(billingTemplate, context);
    }

    private String generateFileName(String customerCode, String subCode, String billingNumber) {
        String fileName;
        String replaceBillingNumber = billingNumber
                .replace("/", "_")
                .replace("-", "_");

        if (subCode == null || subCode.isEmpty()) {
            fileName = customerCode + "_" + replaceBillingNumber + ".pdf";
        } else {
            fileName = customerCode + "_" + subCode + "_" + replaceBillingNumber + ".pdf";
        }
        return fileName;
    }

    // generate file name for billing type 7 (MUFG), because include 3 month
    private String generateFileNameMUFG(String billingCategory, String billingType, String billingPeriod, String billingNumber) {
        // Billing Period = Aug 2023 - Oct 2023
        String[] split = billingPeriod.split(" - ");
        String[] s = split[0].split(" ");

        String monthString1 = s[0]; // OCTOBER
        String s2 = s[1]; // 2023

        Month month1 = MonthConverterUtil.getMonth(monthString1.toUpperCase());
        int monthValue1 = month1.getValue();

        String formattedMonth1 = (monthValue1 < 10) ? "0" + monthValue1 : String.valueOf(monthValue1);

        String[] s3 = split[1].split(" ");
        String monthString2 = s3[0]; // AUGUST

        String s5 = s3[1]; // 2023

        Month month2 = MonthConverterUtil.getMonth(monthString2.toUpperCase());

        int monthValue2 = month2.getValue();
        String formattedMonth2 = (monthValue2 < 10) ? "0" + monthValue2 : String.valueOf(monthValue2);

        String replaceBillingNumber = billingNumber.replaceAll("/", "_")
                .replaceAll("-", "_");
        // return "MUFG_" + billingCategory + "_" + billingType + "_" + formattedMonth1 + s2 + "-" + formattedMonth2 + s5 + ".pdf";
        return replaceBillingNumber + ".pdf";
    }

    private void savePdf(byte[] pdfBytes, String folderPath, String fileName) throws IOException {
        Path outputPathObj = Paths.get(folderPath).resolve(fileName);
        String outputPath = outputPathObj.toString();
        pdfGenerator.savePdfToFile(pdfBytes, outputPath);
    }

    private void deleteFilesWithCustomerCode(Path folderPathObj, String customerCode, String subCode) throws IOException {
        try (DirectoryStream<Path> directoryStream = Files.newDirectoryStream(folderPathObj, "*.pdf")) {
            for (Path path : directoryStream) {
                if (Files.isRegularFile(path)) {
                    handleFile(path, customerCode, subCode);
                }
            }
        }
    }

    private void handleFile(Path path, String customerCode, String subCode) throws IOException {
        String fileName = path.getFileName().toString();
        if (shouldDeleteFile(fileName, customerCode, subCode)) {
            Files.delete(path);
            log.info("Deleted path: {}, file: {}", path, fileName);
        }
    }

    private boolean shouldDeleteFile(String fileName, String customerCode, String subCode) {
        if (subCode == null || subCode.isEmpty()) {
            return fileName.contains(customerCode);
        }
        return fileName.contains(subCode);
    }

}
