package com.services.billingservice.controller.placement;

import com.services.billingservice.dto.ResponseDTO;
import com.services.billingservice.enums.ApprovalStatus;
import com.services.billingservice.model.placement.PlacementDataChange;
import com.services.billingservice.service.placement.PlacementDataChangeService;
import com.services.billingservice.utils.ClientIPUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@RestController
@RequestMapping(path = "/api/placement/data-change")
@CrossOrigin(origins = "*", allowedHeaders = "*")
@Slf4j
@RequiredArgsConstructor
public class PlacementDataChangeController {

    private final PlacementDataChangeService placementDataChangeService;

    @GetMapping(path = "/getByMenuAndStatus")
    public ResponseEntity<ResponseDTO<List<PlacementDataChange>>> getByMenuAndStatus(@RequestParam("menu") String menu,
                                                                                     @RequestParam("status") String status) {

        ApprovalStatus approvalStatus = ApprovalStatus.valueOf(status);
        List<PlacementDataChange> placementDataChangeList = placementDataChangeService.findByMenuAndApprovalStatus(menu, approvalStatus);
        ResponseDTO<List<PlacementDataChange>> response = ResponseDTO.<List<PlacementDataChange>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(placementDataChangeList)
                .build();
        return ResponseEntity.ok(response);
    }

    @GetMapping(path = "/all/menu")
    public ResponseEntity<ResponseDTO<List<String>>> getAllMenu() {
        List<String> menuList = placementDataChangeService.findAllMenu();
        ResponseDTO<List<String>> response = ResponseDTO.<List<String>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(menuList)
                .build();
        return ResponseEntity.ok(response);
    }

    @PostMapping(path = "/checkIdDataChanges")
    public ResponseEntity<ResponseDTO<String>> checkIdDataChanges(@RequestBody List<Long> ids) {
        Boolean isExits = placementDataChangeService.existByIdListAndStatus(ids, (long) ids.size(), ApprovalStatus.Pending);

        if (Boolean.FALSE.equals(isExits))
            return ResponseEntity.status(HttpStatus.OK.value())
                    .body(ResponseDTO.<String>builder()
                            .code(HttpStatus.NOT_ACCEPTABLE.value())
                            .message(HttpStatus.NOT_ACCEPTABLE.getReasonPhrase())
                            .payload("The ID data list does not match the data in the database.")
                            .build());

        ResponseDTO<String> response = ResponseDTO.<String>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload("Success")
                .build();
        return ResponseEntity.ok(response);
    }

    @GetMapping(path = "/approval-status")
    public ResponseEntity<ResponseDTO<List<PlacementDataChange>>> getAllByApprovalStatus(@RequestParam("approvalStatus") String approvalStatus) {
        List<PlacementDataChange> dataChangeList = placementDataChangeService.getAllByApprovalStatus(approvalStatus);
        ResponseDTO<List<PlacementDataChange>> response = ResponseDTO.<List<PlacementDataChange>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(dataChangeList)
                .build();
        return ResponseEntity.ok(response);
    }

    @PutMapping("/reject/{id}")
    public ResponseEntity<ResponseDTO<String>> doReject(@PathVariable("id") Long id, @RequestParam("approverId") String approveId, HttpServletRequest servletRequest) {
        String clientIP = ClientIPUtil.getClientIp(servletRequest);
        placementDataChangeService.reject(id, approveId, clientIP);
        ResponseDTO<String> response = ResponseDTO.<String>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload("Success reject id: " + id)
                .build();
        return ResponseEntity.ok(response);
    }

}
