package com.services.billingservice.exception.placement;

public class CustomTimeoutException extends RuntimeException {

    public CustomTimeoutException() {
    }

    public CustomTimeoutException(String message) {
        super(message);
    }
}
