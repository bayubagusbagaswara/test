package com.services.billingservice.model.placement;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import javax.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;

@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "placement_instruksi_s_invest")
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class InstructionsSInvest extends BasePlacementApproval {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "im_code")
    private String imCode;

    @Column(name = "im_name")
    private String imName;

    @Column(name = "fund_code")
    private String fundCode;

    @Column(name = "fund_name")
    private String fundName;

    @Column(name = "placement_bank_code")
    private String placementBankCode;

    @Column(name = "placement_bank_name")
    private String placementBankName;

    @Column(name = "placement_bank_cash_account_name")
    private String placementBankCashAccountName;

    @Column(name = "placement_bank_cash_account_no")
    private String placementBankCashAccountNo;

    @Column(name = "currency")
    private String currency;

    @Column(name = "principle")
    private BigDecimal principle; // nominal

    @Column(name = "placement_date")
    private LocalDate placementDate; // 20220104 format yyyyMMdd

    @Column(name = "reference_no")
    private String referenceNo;

    @Column(name = "si_reference_id")
    private String siReferenceId;

}
