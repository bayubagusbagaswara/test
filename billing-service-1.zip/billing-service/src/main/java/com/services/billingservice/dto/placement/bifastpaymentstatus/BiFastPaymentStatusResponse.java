package com.services.billingservice.dto.placement.bifastpaymentstatus;

import com.services.billingservice.dto.placement.apiresponse.SubStatusProviderDTO;
import com.services.billingservice.dto.placement.overbookingcasa.HeaderResponseDTO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BiFastPaymentStatusResponse {

    private String responseCode;

    private String responseMessage;

    private BiFastPaymentStatusDataDTO data;

    private SubStatusProviderDTO subStatusProvider;

    private HeaderResponseDTO headerResponse;
}
