package com.services.billingservice.dto.feeschedule;

import com.services.billingservice.dto.approval.InputIdentifierRequest;
import lombok.*;
import lombok.experimental.SuperBuilder;

@EqualsAndHashCode(callSuper = true)
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class DeleteFeeScheduleRequest extends InputIdentifierRequest {

    private Long id;

}
