package com.services.billingservice.repository.placement;

import com.services.billingservice.model.placement.ResponseCode;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ResponseCodeRepository extends JpaRepository<ResponseCode, Long> {

    List<ResponseCode> findAllByName(String name);
}
