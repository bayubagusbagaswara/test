package com.services.billingservice.repository;

import com.services.billingservice.dto.emailprocessing.BillingEmailProcessingDTO;
import com.services.billingservice.model.BillingEmailProcessing;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface BillingEmailProcessingRepository extends JpaRepository<BillingEmailProcessing, Long> {

    @Query(value = "SELECT * FROM billing_email_processing WHERE period = :id", nativeQuery = true)
    Optional<BillingEmailProcessing> findByPeriod(@Param("id") String id);

    @Query(value = "SELECT * FROM billing_email_processing", nativeQuery = true)
    List<BillingEmailProcessing> findAll();

    @Query(value = "select new com.services.billingservice.dto.emailprocessing.BillingEmailProcessingDTO(c.npwpNumber, c.npwpName, c.npwpAddress, 'Custodian Fee' as category , " +
            " bf.billingPeriod, bf.billingNumber, bf.currency, bf.subTotal, bf.vatAmountDue, c.glAccountHasil, c.costCenter) " +
            "from com.services.billingservice.model.BillingCustomer c " +
            "join com.services.billingservice.model.BillingFund bf " +
            "on c.customerCode = bf.customerCode " +
            "where bf.billingPeriod = :period AND c.npwpNumber <> '-' ")
    List<BillingEmailProcessingDTO> getTosFund(@Param("period") String period);

    @Query(value = "select new com.services.billingservice.dto.emailprocessing.BillingEmailProcessingDTO(c.npwpNumber, c.npwpName, c.npwpAddress, 'Safekeeping fee' as category, " +
            " bc.billingPeriod, bc.billingNumber, bc.currency, bc.subTotal, bc.vatAmountDue, c.glAccountHasil, c.costCenter) " +
            "from com.services.billingservice.model.BillingCustomer c " +
            "join com.services.billingservice.model.BillingCore bc " +
            "on c.customerCode = bc.customerCode " +
            "where bc.billingPeriod = :period AND c.npwpNumber <> '-' ")
    List<BillingEmailProcessingDTO> getTosCore(@Param("period") String period);

    @Query(value = "select new com.services.billingservice.dto.emailprocessing.BillingEmailProcessingDTO(c.npwpNumber, c.npwpName, c.npwpAddress, 'Safekeeping fee' as category, " +
            " br.billingPeriod, br.billingNumber, br.currency, br.subTotalAmountDue, br.vatAmountDue, c.glAccountHasil, c.costCenter) " +
            "from com.services.billingservice.model.BillingCustomer c " +
            "join com.services.billingservice.model.BillingRetail br " +
            "on c.customerCode = br.customerCode " +
            "where br.billingPeriod = :period AND c.npwpNumber <> '-' ")
    List<BillingEmailProcessingDTO> getTosRetail(@Param("period") String period);

}

