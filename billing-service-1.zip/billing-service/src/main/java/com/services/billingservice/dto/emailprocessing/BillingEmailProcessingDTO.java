package com.services.billingservice.dto.emailprocessing;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BillingEmailProcessingDTO {

    private String npwpNumber;

    private String npwpName;

    private String npwpAddress;

    private String billingCategory;

    private String billingPeriod;

    private String billingNumber;

    private String currency;

    private BigDecimal subTotal;

    private BigDecimal vatFee;

    private String glAccountHasil;

    private String costCenter;
}
