package com.services.billingservice.service;

import com.services.billingservice.dto.fund.FundCalculateRequest;

public interface FundGeneratePDFService {

    String generatePDF(FundCalculateRequest fundCalculateRequest);

}
