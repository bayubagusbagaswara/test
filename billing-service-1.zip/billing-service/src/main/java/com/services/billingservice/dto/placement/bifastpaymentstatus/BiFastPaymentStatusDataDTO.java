package com.services.billingservice.dto.placement.bifastpaymentstatus;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BiFastPaymentStatusDataDTO {

    private String payUserRefNo;
    private String infoStatus;
    private String sttlmDate;

    private String senderName;
    private String senderAcctNo;
    private String senderAcctType;
    private String senderBic;

    private String benefName;
    private String benefAcctNo;
    private String benefAcctType;
    private String benefBic;

    private String senderType;
    private String senderId;
    private String senderResidentStatus;
    private String senderCityCode;

    private String benefType;
    private String benefId;
    private String benefResidentStatus;
    private String benefCityCode;

    private String senderSttlmAcct;
    private String benefSttlmAcct;
    private String userRefNoBi;

}
