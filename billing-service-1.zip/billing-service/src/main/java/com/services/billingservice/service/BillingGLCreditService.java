package com.services.billingservice.service;

import com.services.billingservice.model.BillingGlCredit;

public interface BillingGLCreditService {

    BillingGlCredit getByBillingTemplateAndGLCreditName(String billingTemplate, String glCreditName);
}
