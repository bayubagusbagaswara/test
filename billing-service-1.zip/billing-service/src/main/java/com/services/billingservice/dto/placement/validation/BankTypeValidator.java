package com.services.billingservice.dto.placement.validation;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class BankTypeValidator implements ConstraintValidator<ValidBankType, String> {

    @Override
    public boolean isValid(String value, ConstraintValidatorContext constraintValidatorContext) {
        if (value == null) {
            return true; // if you want to allow null values
        }
        return "C".equalsIgnoreCase(value) || "S".equalsIgnoreCase(value);
    }

}
