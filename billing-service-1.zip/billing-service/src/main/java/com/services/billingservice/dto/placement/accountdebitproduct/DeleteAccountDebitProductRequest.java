package com.services.billingservice.dto.placement.accountdebitproduct;

import com.services.billingservice.dto.approval.InputIdentifierRequest;
import lombok.*;
import lombok.experimental.SuperBuilder;

@EqualsAndHashCode(callSuper = true)
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class DeleteAccountDebitProductRequest extends InputIdentifierRequest {

    private Long id;

}
