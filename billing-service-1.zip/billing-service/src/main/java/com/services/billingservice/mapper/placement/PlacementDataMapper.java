package com.services.billingservice.mapper.placement;

import com.services.billingservice.dto.placement.placementdata.PlacementDataDTO;
import com.services.billingservice.model.placement.PlacementData;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Mapper(componentModel = "spring")
public interface PlacementDataMapper {

    @Named("bigDecimalToString")
    default String bigDecimalToString(BigDecimal value) {
        return value != null ? value.toPlainString() : null;
    }

    @Named("localDateToString")
    default String localDateToString(LocalDate localDate) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd");
        LocalDate date = LocalDate.parse(localDate.toString());
        return date.format(formatter);
    }

    @Mapping(source = "id", target = "id")
    @Mapping(source = "principle", target = "principle", qualifiedByName = "bigDecimalToString")
    @Mapping(source = "placementDate", target = "placementDate", qualifiedByName = "localDateToString")
    PlacementDataDTO toDTO(PlacementData placementData);

    // when DTO placement date format is yyyyMMdd, from table database is yyyy-MM-dd

    List<PlacementDataDTO> toDTOList(List<PlacementData> all);

}
