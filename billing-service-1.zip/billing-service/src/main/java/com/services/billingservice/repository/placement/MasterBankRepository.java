package com.services.billingservice.repository.placement;

import com.services.billingservice.model.placement.MasterBank;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface MasterBankRepository extends JpaRepository<MasterBank, Long> {

    @Query(value = "FROM MasterBank m WHERE m.placementBankCode = :placementBankCode")
    Optional<MasterBank> findByPlacementBankCode(@Param("placementBankCode") String placementBankCode);

    boolean existsByPlacementBankCode(String placementBankCode);

}
