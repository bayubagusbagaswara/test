package com.services.billingservice.service.placement;

import com.services.billingservice.dto.placement.bifastpaymentstatus.BiFastPaymentStatusRequest;
import com.services.billingservice.dto.placement.bifastpaymentstatus.BiFastPaymentStatusResponse;

public interface BiFastPaymentStatusService {

    BiFastPaymentStatusResponse checkPaymentStatus(BiFastPaymentStatusRequest biFastPaymentStatusRequest);

}
