package com.services.billingservice.dto.ematerai;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BillingEmateraiDTO {

    private Long id;

    private String customerCode;

    private String securityCode;

    private String period;
}
