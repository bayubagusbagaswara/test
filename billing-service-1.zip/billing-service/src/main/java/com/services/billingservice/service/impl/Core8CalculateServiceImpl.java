package com.services.billingservice.service.impl;

import com.services.billingservice.dto.billing.BillingCalculationErrorMessageDTO;
import com.services.billingservice.dto.billing.BillingCalculationResponse;
import com.services.billingservice.dto.billing.BillingContextDate;
import com.services.billingservice.dto.core.CoreCalculateRequest;
import com.services.billingservice.dto.core.CoreTemplate6;
import com.services.billingservice.dto.core.CoreType8Parameter;
import com.services.billingservice.dto.exchangerate.ExchangeRateDTO;
import com.services.billingservice.dto.mi.InvestmentManagementDTO;
import com.services.billingservice.enums.ApprovalStatus;
import com.services.billingservice.enums.BillingStatus;
import com.services.billingservice.model.BillingCore;
import com.services.billingservice.model.BillingCustomer;
import com.services.billingservice.model.SfValCoreIIG;
import com.services.billingservice.repository.BillingCoreRepository;
import com.services.billingservice.service.*;
import com.services.billingservice.utils.ConvertDateUtil;
import com.services.billingservice.utils.StringUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import static com.services.billingservice.enums.Currency.USD;
import static com.services.billingservice.enums.FeeParameter.*;

@Service
@Slf4j
@RequiredArgsConstructor
public class Core8CalculateServiceImpl implements Core8CalculateService {

    private final BillingCustomerService customerService;
    private final BillingFeeParameterService feeParameterService;
    private final SfValCoreIIGService sfValCoreIIGService;
    private final ExchangeRateService exchangeRateService;
    private final BillingNumberService billingNumberService;
    private final BillingCoreRepository billingCoreRepository;
    private final BillingMIService investmentManagementService;
    private final ConvertDateUtil convertDateUtil;

    @Override
    public synchronized String calculate(CoreCalculateRequest request) {
        log.info("Start core billing calculation type 8 with a data request: {}", request);

        /* initialize response data */
        Integer totalDataSuccess = 0;
        Integer totalDataFailed = 0;
        List<BillingCalculationErrorMessageDTO> errorMessageList = new ArrayList<>();

        /* initialize data request */
        Instant dateNow = Instant.now();
        String categoryUpperCase = request.getCategory().toUpperCase();
        String typeUpperCase = StringUtil.replaceBlanksWithUnderscores(request.getType());

        /* generate billing context date */
        BillingContextDate contextDate = convertDateUtil.getBillingContextDate(dateNow);

        /* get data fee parameters */
        String paymentDueDate = feeParameterService.getFeeDescriptionByName(BILLING_PAYMENT_DUE_DATE.getValue());
        BigDecimal administrationSetUpFee = feeParameterService.getValueByName(ADMINISTRATION_SET_UP.getValue());
        BigDecimal signingRepresentationFee = feeParameterService.getValueByName(SIGNING_REPRESENTATION.getValue());
        BigDecimal securityAgentFee = feeParameterService.getValueByName(SECURITY_AGENT.getValue());
        BigDecimal otherFee = feeParameterService.getValueByName(OTHER.getValue());
        BigDecimal vatFee = feeParameterService.getValueByName(VAT.getValue());

        /* get all customer Core Type 8 */
        List<BillingCustomer> billingCustomerList = customerService.getAllByBillingCategoryAndBillingType(categoryUpperCase, typeUpperCase);

        /* get data exchange rate */
        ExchangeRateDTO exchangeRateDTO = exchangeRateService.getByCurrency(USD.getValue());
        BigDecimal exchangeRateValue = new BigDecimal(exchangeRateDTO.getValue());

        for (BillingCustomer customer : billingCustomerList) {
            try {
                String customerCode = customer.getCustomerCode();

                /* get data investment management */
                InvestmentManagementDTO investmentManagementDTO = investmentManagementService.getByCode(customer.getMiCode());

                /* get data core IIG */
                List<SfValCoreIIG> sfValCoreIIGList = sfValCoreIIGService.getAllByAidAndMonthAndYear(customerCode, contextDate.getMonthNameMinus1(), contextDate.getYearMinus1());

                /* create billing core */
                BillingCore billingCore = createBillingCore(contextDate, customer, investmentManagementDTO, paymentDueDate);

                /* create core type 8 parameter */
                CoreType8Parameter coreType8Parameter = new CoreType8Parameter(
                        administrationSetUpFee, signingRepresentationFee, securityAgentFee, customer.getCustomerTransactionHandling(), customer.getCustomerSafekeepingFee(),
                        otherFee, vatFee, sfValCoreIIGList, exchangeRateValue);

                /* calculation billing */
                CoreTemplate6 coreTemplate6 = calculationResult(coreType8Parameter);

                /* update billing core data to include calculated values */
                updateBillingCoreForTemplate6(billingCore, coreTemplate6);

                /* create a billing number then set it to the billing core */
                String number = billingNumberService.generateSingleNumber(contextDate.getMonthNameNow(), contextDate.getYearNow());
                billingCore.setBillingNumber(number);

                /* get billing data to check whether the data is in the database or not */
                Optional<BillingCore> existingBillingCore = billingCoreRepository.findByCustomerCodeAndSubCodeAndBillingCategoryAndBillingTypeAndMonthAndYear(
                        customerCode, customer.getSubCode(), customer.getBillingCategory(), customer.getBillingType(), contextDate.getMonthNameMinus1(), contextDate.getYearMinus1());

                /* check paid status. if it is FALSE, it can be regenerated */
                if (!existingBillingCore.isPresent() || Boolean.TRUE.equals(!existingBillingCore.get().getPaid())) {

                    /* delete billing data if it exists in the database */
                    existingBillingCore.ifPresent(this::deleteExistingBillingCore);

                    /* save to the database */
                    billingCoreRepository.save(billingCore);
                    billingNumberService.saveSingleNumber(number);
                    totalDataSuccess++;
                } else {
                    addErrorMessage(errorMessageList, customer.getCustomerCode(), "Billing already paid for period " + contextDate.getMonthNameMinus1() + " " + contextDate.getYearMinus1());
                    totalDataFailed++;
                }
            } catch (Exception e) {
                handleGeneralError(customer.getCustomerCode(), e, errorMessageList);
                totalDataFailed++;
            }
        }
        log.info("Total successfully calculations: {}, total failed calculations: {}", totalDataSuccess, totalDataFailed);
        BillingCalculationResponse billingCalculationResponse = new BillingCalculationResponse(totalDataSuccess, totalDataFailed, errorMessageList);
        return "Total successful calculations: " + billingCalculationResponse.getTotalDataSuccess() + ", total failed calculations: " + billingCalculationResponse.getTotalDataFailed();
    }

    private void updateBillingCoreForTemplate6(BillingCore billingCore, CoreTemplate6 coreTemplate6) {
        billingCore.setAdministrationSetUpItem(coreTemplate6.getAdministrationSetUpItem());
        billingCore.setAdministrationSetUpFee(coreTemplate6.getAdministrationSetUpFee());
        billingCore.setAdministrationSetUpAmountDue(coreTemplate6.getAdministrationSetUpAmountDue());

        billingCore.setSigningRepresentationItem(coreTemplate6.getSigningRepresentationItem());
        billingCore.setSigningRepresentationFee(coreTemplate6.getSigningRepresentationFee());
        billingCore.setSigningRepresentationAmountDue(coreTemplate6.getSigningRepresentationAmountDue());

        billingCore.setSecurityAgentItem(coreTemplate6.getSecurityAgentItem());
        billingCore.setSecurityAgentFee(coreTemplate6.getSecurityAgentFee());
        billingCore.setSecurityAgentAmountDue(coreTemplate6.getSecurityAgentAmountDue());

        billingCore.setTransactionHandlingItem(coreTemplate6.getTransactionHandlingItem());
        billingCore.setTransactionHandlingFee(coreTemplate6.getTransactionHandlingFee());
        billingCore.setTransactionHandlingAmountDue(coreTemplate6.getTransactionHandlingAmountDue());

        billingCore.setSafekeepingItem(coreTemplate6.getSafekeepingItem());
        billingCore.setSafekeepingFee(coreTemplate6.getSafekeepingFee());
        billingCore.setSafekeepingAmountDue(coreTemplate6.getSafekeepingAmountDueUSD());

        billingCore.setOtherItem(coreTemplate6.getOtherItem());
        billingCore.setOtherFee(coreTemplate6.getOtherFee());
        billingCore.setOtherAmountDue(coreTemplate6.getOtherAmountDue());

        billingCore.setSubTotal(coreTemplate6.getSubTotal());
        billingCore.setVatFee(coreTemplate6.getVatFee());
        billingCore.setVatAmountDue(coreTemplate6.getVatAmountDueUSD());
        billingCore.setTotalAmountDue(coreTemplate6.getTotalAmountDue());
    }

    private BillingCore createBillingCore(BillingContextDate contextDate, BillingCustomer customer, InvestmentManagementDTO investmentManagementDTO, String paymentDueDate) {
        String glAccountDebit = "GL " + customer.getAccount() + " CC " + customer.getDebitTransfer();
        return BillingCore.builder()
                .createdAt(contextDate.getDateNow())
                .updatedAt(contextDate.getDateNow())
                .approvalStatus(ApprovalStatus.Pending)
                .billingStatus(BillingStatus.Generated)
                .customerCode(customer.getCustomerCode())
                .subCode(customer.getSubCode())
                .customerName(customer.getCustomerName())
                .month(contextDate.getMonthNameMinus1())
                .year(contextDate.getYearMinus1())
                .billingPeriod(contextDate.getBillingPeriod())
                .billingStatementDate(ConvertDateUtil.convertInstantToString(contextDate.getDateNow()))
                .billingPaymentDueDate(paymentDueDate)
                .billingCategory(customer.getBillingCategory())
                .billingType(customer.getBillingType())
                .billingTemplate(customer.getBillingTemplate())
                .investmentManagementCode(investmentManagementDTO.getCode())
                .investmentManagementName(investmentManagementDTO.getName())
                .investmentManagementAddress1(investmentManagementDTO.getAddress1())
                .investmentManagementAddress2(investmentManagementDTO.getAddress2())
                .investmentManagementAddress3(investmentManagementDTO.getAddress3())
                .investmentManagementAddress4(investmentManagementDTO.getAddress4())
                .investmentManagementEmail(investmentManagementDTO.getEmail())
                .investmentManagementUniqueKey(investmentManagementDTO.getUniqueKey())
                .account(glAccountDebit)
                .accountName(customer.getAccountName())
                .currency(customer.getCurrency())
                .paid(false)
                .gefuCreated(false)
                .build();
    }

    private CoreTemplate6 calculationResult(CoreType8Parameter param) {
        BigDecimal safekeepingFeeIDR = calculateTotalSafekeepingIDR(param.getSfValCoreIIGList());

        Integer administrationSetUpItem = getAdministrationSetUpItem();
        BigDecimal administrationSetUpFee = param.getAdministrationSetUpFee();
        BigDecimal administrationSetUpAmountDue = getAdministrationSetAmountDue();

        Integer signingRepresentationItem = getSigningRepresentationItem();
        BigDecimal signingRepresentationFee = param.getSigningRepresentationFee();
        BigDecimal signingRepresentationAmountDue = getSigningRepresentationAmountDue();

        Integer securityAgentItem = getSecurityAgentItem();
        BigDecimal securityAgentFee = param.getSecurityAgentFee();
        BigDecimal securityAgentAmountDue = getSecurityAgentAmountDue();

        Integer transactionHandlingItem = getTransactionHandlingItem();
        BigDecimal transactionHandlingFee = param.getTransactionHandlingFee();
        BigDecimal transactionHandlingAmountDue = getTransactionHandlingAmountDue();

        Integer safekeepingItem = getSafekeepingItem();
        BigDecimal safekeepingFee = param.getSafekeepingFee();
        BigDecimal safekeepingAmountDueUSD = calculateTotalSafekeepingUSD(safekeepingFeeIDR, param.getExchangeRateValue());

        Integer otherItem = 0;
        BigDecimal otherFee = param.getOtherFee();
        BigDecimal otherAmountDue = getOtherAmountDue();

        BigDecimal subTotal = calculateSubTotal(administrationSetUpAmountDue, signingRepresentationAmountDue,
                securityAgentAmountDue, transactionHandlingAmountDue, safekeepingAmountDueUSD, otherAmountDue);

        BigDecimal vatAmountDueUSD = calculateVATAmountDueUSD(param.getVatFee(), safekeepingAmountDueUSD);

        BigDecimal totalAmountDue = calculateTotalAmountDueUSD(vatAmountDueUSD, safekeepingAmountDueUSD);

        return CoreTemplate6.builder()
                .administrationSetUpItem(administrationSetUpItem)
                .administrationSetUpFee(administrationSetUpFee)
                .administrationSetUpAmountDue(administrationSetUpAmountDue)
                .signingRepresentationItem(signingRepresentationItem)
                .signingRepresentationFee(signingRepresentationFee)
                .signingRepresentationAmountDue(signingRepresentationAmountDue)
                .securityAgentItem(securityAgentItem)
                .securityAgentFee(securityAgentFee)
                .securityAgentAmountDue(securityAgentAmountDue)
                .transactionHandlingItem(transactionHandlingItem)
                .transactionHandlingFee(transactionHandlingFee)
                .transactionHandlingAmountDue(getTransactionHandlingAmountDue())
                .safekeepingItem(safekeepingItem)
                .safekeepingFee(safekeepingFee)
                .safekeepingAmountDueUSD(safekeepingAmountDueUSD)
                .otherItem(otherItem)
                .otherFee(otherFee)
                .otherAmountDue(otherAmountDue)
                .subTotal(subTotal)
                .vatFee(param.getVatFee())
                .vatAmountDueUSD(vatAmountDueUSD)
                .totalAmountDue(totalAmountDue)
                .build();
    }

    private static BigDecimal getOtherAmountDue() {
        return BigDecimal.ZERO;
    }

    private static int getSafekeepingItem() {
        return 0;
    }

    private static BigDecimal getTransactionHandlingAmountDue() {
        return BigDecimal.ZERO;
    }

    private static int getTransactionHandlingItem() {
        return 0;
    }

    private static BigDecimal getSecurityAgentAmountDue() {
        return BigDecimal.ZERO;
    }

    private static int getSecurityAgentItem() {
        return 0;
    }

    private static BigDecimal calculateTotalSafekeepingIDR(List<SfValCoreIIG> sfValCoreIIGList) {
        BigDecimal totalSafekeepingFeeIDR = sfValCoreIIGList.stream()
                .map(SfValCoreIIG::getSafekeepingFee)
                .filter(Objects::nonNull)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        log.info("[Core Type 8] Safekeeping Fee IDR: {}", totalSafekeepingFeeIDR);
        return totalSafekeepingFeeIDR;
    }

    private static BigDecimal calculateTotalSafekeepingUSD(BigDecimal safekeepingFeeIDR, BigDecimal exchangeRate) {
        BigDecimal totalSafekeepingFeeUSD = safekeepingFeeIDR
                .divide(exchangeRate, 2, RoundingMode.HALF_UP);
        log.info("[Core Type 8] Safekeeping Fee USD: {}", totalSafekeepingFeeUSD);
        return totalSafekeepingFeeUSD;
    }

    private static BigDecimal calculateSubTotal(BigDecimal administrationSetUpAmountDue, BigDecimal signingRepresentationAmountDue, BigDecimal securityAgentAmountDue, BigDecimal transactionHandlingAmountDue, BigDecimal safekeepingAmountDue, BigDecimal otherAmountDue) {
        BigDecimal subTotal = administrationSetUpAmountDue
                .add(signingRepresentationAmountDue)
                .add(securityAgentAmountDue)
                .add(transactionHandlingAmountDue)
                .add(safekeepingAmountDue)
                .add(otherAmountDue)
                .setScale(2, RoundingMode.HALF_UP);
        log.info("[Core Type 8] Sub total: {}", subTotal);
        return subTotal;
    }

    private static BigDecimal calculateVATAmountDueUSD(BigDecimal vatFee, BigDecimal safekeepingAmountDueUSD) {
        BigDecimal vatAmountDueUSD = safekeepingAmountDueUSD
                .multiply(vatFee)
                .divide(new BigDecimal(100), 2, RoundingMode.HALF_UP)
                .setScale(2, RoundingMode.HALF_UP);
        log.info("[Core Type 8] VAT amount USD: {}", vatAmountDueUSD);
        return vatAmountDueUSD;
    }

    private static BigDecimal calculateTotalAmountDueUSD(BigDecimal vatAmountDueUSD, BigDecimal safekeepingAmountDueUSD) {
        BigDecimal totalAmountDueUSD = safekeepingAmountDueUSD
                .add(vatAmountDueUSD);
        log.info("[Core Type 8] Total amount USD: {}", totalAmountDueUSD);
        return totalAmountDueUSD;
    }

    private static int getAdministrationSetUpItem() {
        return 0;
    }

    private static BigDecimal getAdministrationSetAmountDue() {
        return BigDecimal.ZERO;
    }

    private static int getSigningRepresentationItem() {
        return 0;
    }

    private static BigDecimal getSigningRepresentationAmountDue() {
        return BigDecimal.ZERO;
    }

    private void deleteExistingBillingCore(BillingCore existBillingCore) {
        String billingNumber = existBillingCore.getBillingNumber();
        billingCoreRepository.delete(existBillingCore);
        billingNumberService.deleteByBillingNumber(billingNumber);
    }

    private void handleGeneralError(String customerCode, Exception e, List<BillingCalculationErrorMessageDTO> errorMessageList) {
        addErrorMessage(errorMessageList, customerCode, e.getMessage());
    }

    private void addErrorMessage(List<BillingCalculationErrorMessageDTO> errorMessageList, String customerCode, String message) {
        List<String> stringList = new ArrayList<>();
        stringList.add(message);
        errorMessageList.add(new BillingCalculationErrorMessageDTO(customerCode, stringList));
    }

}
