package com.services.billingservice.model.placement;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "placement_fee_parameter")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FeeParameterPlacement {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Column(name = "transaction_type")
    private String transactionType; // BI-FAST, SKN, RTGS, OVERBOOKING

    @Column(name = "amount", nullable = false, precision = 19, scale = 2)
    private BigDecimal amount;

}
