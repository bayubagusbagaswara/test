package com.services.billingservice.service;

import com.services.billingservice.dto.datachange.BillingDataChangeDTO;
import com.services.billingservice.dto.mi.*;

import java.util.List;

public interface BillingMIService {

    boolean isExistsByCode(String code);

    boolean isCodeAlreadyExists(String code);

    InvestmentManagementResponse createSingleData(CreateInvestmentManagementRequest request, BillingDataChangeDTO dataChangeDTO);

    InvestmentManagementResponse createMultipleData(CreateInvestmentManagementListRequest createInvestmentManagementListRequest, BillingDataChangeDTO dataChangeDTO);

    InvestmentManagementResponse createSingleApprove(InvestmentManagementApproveRequest investmentManagementApproveRequest, String clientIP);

    InvestmentManagementResponse updateSingleData(UpdateInvestmentManagementRequest request, BillingDataChangeDTO dataChangeDTO);

    InvestmentManagementResponse updateMultipleData(UpdateInvestmentManagementListRequest updateInvestmentManagementListRequest, BillingDataChangeDTO dataChangeDTO);

    InvestmentManagementResponse updateSingleApprove(InvestmentManagementApproveRequest updateInvestmentManagementApproveRequest, String clientIP);

    InvestmentManagementResponse deleteSingleData(DeleteInvestmentManagementRequest request, BillingDataChangeDTO dataChangeDTO);

    InvestmentManagementResponse deleteSingleApprove(InvestmentManagementApproveRequest request, String clientIP);

    InvestmentManagementDTO getByCode(String code);

    List<InvestmentManagementDTO> getAll();

    String deleteAll();

    InvestmentManagementDTO getById(String id);
}
