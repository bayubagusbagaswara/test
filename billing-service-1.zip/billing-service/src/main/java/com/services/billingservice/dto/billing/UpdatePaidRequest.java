package com.services.billingservice.dto.billing;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UpdatePaidRequest {

    private String customerCode;

    private String period;

    private String category;

    private String gefuFileName;

}
