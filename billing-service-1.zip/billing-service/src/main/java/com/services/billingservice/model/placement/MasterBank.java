package com.services.billingservice.model.placement;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import javax.persistence.*;

@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "placement_master_bank")
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class MasterBank extends BasePlacementApproval {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "placement_bank_code")
    private String placementBankCode;

    @Column(name = "placement_bank_name")
    private String placementBankName;

    @Column(name = "bi_code")
    private String biCode;

    @Column(name = "bank_type")
    private String bankType;

    @Column(name = "branch_code")
    private String branchCode;

}
