package com.services.billingservice.dto.core;

import com.services.billingservice.model.SfValCoreIIG;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CoreType8Parameter {

    private BigDecimal administrationSetUpFee;
    private BigDecimal signingRepresentationFee;
    private BigDecimal securityAgentFee;
    private BigDecimal transactionHandlingFee;
    private BigDecimal safekeepingFee;
    private BigDecimal otherFee;
    private BigDecimal vatFee;

    private List<SfValCoreIIG> sfValCoreIIGList;

    private BigDecimal exchangeRateValue;

}
