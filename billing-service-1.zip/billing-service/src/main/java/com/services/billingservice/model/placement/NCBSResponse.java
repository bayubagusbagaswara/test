package com.services.billingservice.model.placement;

import lombok.*;
import lombok.experimental.SuperBuilder;

import javax.persistence.*;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "placement_ncbs_response")
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class NCBSResponse {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Column(name = "placement_id")
    private Long placementId;

    @Column(name = "placement_date")
    private LocalDate placementDate;

    @Column(name = "si_reference_id")
    private String siReferenceId;

    @Column(name = "placement_type")
    private String placementType; // External or Internal

    @Column(name = "placement_transfer_type")
    private String placementTransferType; // Overbooking, Bi-Fast, SKN, RTGS

    @Column(name = "response_code")
    private String responseCode;

    @Column(name = "response_message")
    private String responseMessage;

    @Column(name = "provider_system")
    private String providerSystem;

    @Column(name = "status_code")
    private String statusCode;

    @Column(name = "status_message")
    private String statusMessage;

    @Lob
    @Column(name = "response_json", columnDefinition = "nvarchar(max)")
    private String responseJson;

    @Column(name = "ncbs_status")
    private String ncbsStatus; // SUCCESS or FAILED

    @Column(name = "reference_id")
    private String referenceId; // generate from CSA

    @Column(name = "pay_user_ref_no")
    private String payUserRefNo; // only used to check BI-FAST status

    @Column(name = "service_type")
    private String serviceType; // service type --> INQUIRY_ACCOUNT, CREDIT_TRANSFER, OVERBOOKING_CASA, TRANSFER_SKN_RTGS, PAYMENT_STATUS

}
