package com.services.billingservice.repository;

public interface CsaDataRepository {

    void executeQuerySpRekapAccountBalance();

    void executeQuerySpRekapRekapDataTransaksi();
}
