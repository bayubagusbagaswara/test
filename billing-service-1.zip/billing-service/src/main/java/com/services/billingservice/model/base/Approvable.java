package com.services.billingservice.model.base;

import com.services.billingservice.enums.ApprovalStatus;
import lombok.*;
import lombok.experimental.SuperBuilder;

import javax.persistence.Column;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.MappedSuperclass;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Date;


@EqualsAndHashCode(callSuper = true)
@Data
@MappedSuperclass
@SuperBuilder
@NoArgsConstructor
public abstract class Approvable extends BeanEntity {

    @Enumerated(EnumType.STRING)
    @Column(name = "approval_status")
    private ApprovalStatus approvalStatus;

    @Column(name = "inputer_id")
    private String inputerId;

    @Column(name = "input_date")
    private Date inputDate;

    @Column(name = "approver_id")
    private String approverId;

    @Column(name = "approve_date")
    private Date approveDate;

    @Column(name = "inputer_ip_address")
    private String inputerIPAddress = getIp();

    @Column(name = "approver_ip_address")
    private String approverIPAddress;

    private String getIp() {
        String ipStr = "";
        InetAddress ip;
        try {
            ip = InetAddress.getLocalHost();
            ipStr = ip.getHostAddress();
        } catch (UnknownHostException e) {
            e.printStackTrace();
        }
        return ipStr;
    }

}
