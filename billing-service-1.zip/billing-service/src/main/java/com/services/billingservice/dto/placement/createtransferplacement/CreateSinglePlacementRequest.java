package com.services.billingservice.dto.placement.createtransferplacement;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CreateSinglePlacementRequest {

    private Long id;

    private String placementTransferType; // RTGS, SKN, BI-FAST

    private String description;

}
