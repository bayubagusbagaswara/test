package com.services.billingservice.dto.retail;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

/**
 * kita buat tipe data sesuai dengan
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Retail2QueryResultDTO {

    private String month;

    private Integer year;

    private String sellingAgent;

    private BigDecimal lastBalance; // BigDecimal

    private BigDecimal sumFee; // BigDecimal
}
