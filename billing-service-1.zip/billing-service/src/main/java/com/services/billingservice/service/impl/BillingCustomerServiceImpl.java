package com.services.billingservice.service.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.services.billingservice.dto.ErrorMessageDTO;
import com.services.billingservice.dto.customer.*;
import com.services.billingservice.dto.datachange.BillingDataChangeDTO;
import com.services.billingservice.dto.mi.InvestmentManagementDTO;
import com.services.billingservice.exception.DataNotFoundException;
import com.services.billingservice.exception.GeneralException;
import com.services.billingservice.mapper.CustomerMapper;
import com.services.billingservice.model.BillingCustomer;
import com.services.billingservice.repository.BillingCustomerRepository;
import com.services.billingservice.service.*;
import com.services.billingservice.utils.BeanUtil;
import com.services.billingservice.utils.EnumValidator;
import com.services.billingservice.utils.JsonUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import java.lang.reflect.InvocationTargetException;
import java.util.*;

import static com.services.billingservice.enums.BillingCategory.CORE;
import static com.services.billingservice.enums.BillingType.*;

@Service
@RequiredArgsConstructor
@Slf4j
public class BillingCustomerServiceImpl implements BillingCustomerService {

    private static final String ID_NOT_FOUND = "Billing Customer not found with id: ";
    private static final String CODE_NOT_FOUND = "Billing Customer not found with code: ";
    private static final String SUB_CODE_NOT_FOUND = " and sub code: ";
    private static final String UNKNOWN = "unknown";
    private static final String INVALID_VALUE_TRUE_OR_FALSE = "Invalid value for 'Is GL'. Value must be 'TRUE' or 'FALSE'.";
    private static final String INVESTMENT_MANAGEMENT_NOT_FOUND_WITH_CODE = "Investment Management not found with code: ";
    private static final String KSEI_SAFE_CODE_REQUIRED = "Ksei Safe Code is required when Billing Type is ";

    private final BillingCustomerRepository customerRepository;
    private final BillingMIService investmentManagementService;
    private final BillingDataChangeService dataChangeService;
    private final BillingSellingAgentDataService sellingAgentService;
    private final BillingTemplateService billingTemplateService;
    private final Validator validator;
    private final ObjectMapper objectMapper;
    private final CustomerMapper customerMapper;

    @Override
    public boolean isCodeAlreadyExists(String code, String subCode) {
        return customerRepository.existsCustomerByCustomerCodeAndSubCode(code, subCode);
    }

    @Override
    public List<CustomerDTO> getAll() {
        List<BillingCustomer> all = customerRepository.findAll();
        return customerMapper.mapToDTOList(all);
    }

    @Override
    public CustomerDTO getByCode(String customerCode) {
        BillingCustomer billingCustomer = customerRepository.findByCode(customerCode)
                .orElseThrow(() -> new DataNotFoundException("Billing Customer not found with code: " + customerCode));
        return customerMapper.mapToDto(billingCustomer);
    }

    @Override
    public List<BillingCustomer> getAllByBillingCategoryAndBillingType(String billingCategory, String billingType) {
        log.info("Get customers by billing category: {}, and billing type: {}", billingCategory, billingCategory);
        return customerRepository.findAllByBillingCategoryAndBillingType(billingCategory, billingType);
    }

    @Override
    public String deleteAll() {
        customerRepository.deleteAll();
        return "Successfully delete all billing customer;";
    }

    @Override
    public CustomerResponse createSingleData(CreateCustomerRequest createCustomerRequest, BillingDataChangeDTO dataChangeDTO) {
        log.info("Create single data billing customer with request: {}", createCustomerRequest);
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<>();
        List<String> validationErrors = new ArrayList<>();
        CustomerDTO customerDTO = null;

        try {
            /* mapping data from request to dto */
            customerDTO = customerMapper.mapCreateRequestToDto(createCustomerRequest);
            customerDTO.setBillingCategory(customerDTO.getBillingCategory().toUpperCase());
            customerDTO.setBillingType(customerDTO.getBillingType().toUpperCase());
            customerDTO.setBillingTemplate(customerDTO.getBillingTemplate().toUpperCase());
            customerDTO.setCurrency(customerDTO.getCurrency().toUpperCase());
            log.info("[Create Single] Request to DTO: {}", customerDTO);

            /* validation for each column dto */
            Errors errors = validateCustomerUsingValidator(customerDTO);
            if (errors.hasErrors()) {
                errors.getAllErrors().forEach(error -> validationErrors.add(error.getDefaultMessage()));
            }

            /* validation code and sub code already exists */
            validationCustomerCodeAndSubCodeAlreadyExists(customerDTO.getCustomerCode(), customerDTO.getSubCode(), validationErrors);

            /* validating sales agent is available or not */
            validateSellingAgent(customerDTO, validationErrors);

            /* validation enum data */
            validateBillingEnums(customerDTO.getBillingCategory(),
                    customerDTO.getBillingType(),
                    customerDTO.getCurrency(),
                    validationErrors);

            /* validation value GL must be true or false */
            validateIsGL(customerDTO, validationErrors);

            /* validating Cost Center Debit */
            validateGLForCostCenterDebit(Boolean.parseBoolean(customerDTO.getGl()), customerDTO.getDebitTransfer(), validationErrors);

            /* validating data billing template */
            validationBillingTemplate(customerDTO.getBillingCategory(),
                    customerDTO.getBillingType(),
                    customerDTO.getCurrency(),
                    customerDTO.getSubCode(),
                    customerDTO.getBillingTemplate(),
                    validationErrors);

            /* validating Ksei Safe Code for some Billing Type, especially CORE TYPE 4, TYPE, 5, TYPE 6, TYPE 7 */
            validationKseiSafeCode(customerDTO, validationErrors);

            /* validating data Investment Management is available or not */
            InvestmentManagementDTO investmentManagementDTO = investmentManagementService.getByCode(customerDTO.getMiCode());
            customerDTO.setMiName(investmentManagementDTO.getName());

            /* set data input id to data change */
            dataChangeDTO.setInputerId(createCustomerRequest.getInputerId());

            /* check validation errors for custom response */
            if (validationErrors.isEmpty()) {
                dataChangeDTO.setJsonDataAfter(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(customerDTO)));
                dataChangeService.createChangeActionADD(dataChangeDTO, BillingCustomer.class);
                totalDataSuccess++;
            } else {
                ErrorMessageDTO errorMessageDTO = new ErrorMessageDTO(customerDTO.getCustomerCode(), validationErrors);
                errorMessageDTOList.add(errorMessageDTO);
                totalDataFailed++;
            }
        } catch (Exception e) {
            handleGeneralError(customerDTO, e, validationErrors, errorMessageDTOList);
            totalDataFailed++;
        }
        return new CustomerResponse(totalDataSuccess, totalDataFailed, errorMessageDTOList);
    }

    @Override
    public CustomerResponse createMultipleData(CreateCustomerListRequest createCustomerListRequest, BillingDataChangeDTO dataChangeDTO) {
        log.info("Create billing customer multiple data with request: {}", createCustomerListRequest);
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<>();

        /* repeat data one by one */
        for (CreateCustomerDataListRequest createCustomerDataListRequest : createCustomerListRequest.getCreateCustomerDataListRequests()) {
            List<String> validationErrors = new ArrayList<>();
            CustomerDTO customerDTO = null;
            try {
                /* mapping data from request to dto */
                customerDTO = customerMapper.mapCreateListRequestToDTO(createCustomerDataListRequest);
                customerDTO.setBillingCategory(customerDTO.getBillingCategory().toUpperCase());
                customerDTO.setBillingType(customerDTO.getBillingType().toUpperCase());
                customerDTO.setBillingTemplate(customerDTO.getBillingTemplate().toUpperCase());
                customerDTO.setCurrency(customerDTO.getCurrency().toUpperCase());

                /* validating for each column dto */
                Errors errors = validateCustomerUsingValidator(customerDTO);
                if (errors.hasErrors()) {
                    errors.getAllErrors().forEach(error -> validationErrors.add(error.getDefaultMessage()));
                }

                /* validating code and sub code already exists */
                validationCustomerCodeAndSubCodeAlreadyExists(customerDTO.getCustomerCode(), customerDTO.getSubCode(), validationErrors);

                /* validation selling agent is available or not */
                validateSellingAgent(customerDTO, validationErrors);

                /* validating enum data */
                validateBillingEnums(customerDTO.getBillingCategory(), customerDTO.getBillingType(), customerDTO.getCurrency(), validationErrors);

                /* validating value GL must be true or false */
                validateIsGL(customerDTO, validationErrors);

                /* validating Cost Center Debit */
                validateGLForCostCenterDebit(Boolean.parseBoolean(customerDTO.getGl()), customerDTO.getDebitTransfer(), validationErrors);

                /* validating data billing template */
                validationBillingTemplate(customerDTO.getBillingCategory(),
                        customerDTO.getBillingType(), customerDTO.getCurrency(),
                        customerDTO.getSubCode(), customerDTO.getBillingTemplate(),
                        validationErrors);

                /* validating Ksei Safe Code for some Billing Type, especially CORE TYPE 4, TYPE, 5, TYPE 6, TYPE 7 */
                validationKseiSafeCode(customerDTO, validationErrors);

                /* validating data Investment Management is available or not*/
                InvestmentManagementDTO investmentManagementDTO = investmentManagementService.getByCode(customerDTO.getMiCode());
                customerDTO.setMiName(investmentManagementDTO.getName());

                /* set data input id to data change */
                dataChangeDTO.setInputerId(createCustomerListRequest.getInputerId());

                /* check validation errors for custom response */
                if (validationErrors.isEmpty()) {
                    dataChangeDTO.setJsonDataAfter(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(customerDTO)));
                    dataChangeService.createChangeActionADD(dataChangeDTO, BillingCustomer.class);
                    totalDataSuccess++;
                } else {
                    ErrorMessageDTO errorMessageDTO = new ErrorMessageDTO(customerDTO.getCustomerCode(), validationErrors);
                    errorMessageDTOList.add(errorMessageDTO);
                    totalDataFailed++;
                }
            } catch (Exception e) {
                handleGeneralError(customerDTO, e, validationErrors, errorMessageDTOList);
                totalDataFailed++;
            }
        }
        return new CustomerResponse(totalDataSuccess, totalDataFailed, errorMessageDTOList);
    }

    @Override
    public CustomerResponse createSingleApprove(CustomerApproveRequest approveRequest, String clientIP) {
        log.info("Approve for create billing customer with request: {}", approveRequest);
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<>();
        List<String> validationErrors = new ArrayList<>();
        CustomerDTO customerDTO = null;

        try {
            /* validate data change id */
            validateDataChangeId(approveRequest.getDataChangeId());

            /* mapping from data JSON data after to class dto */
            Long dataChangeId = Long.valueOf(approveRequest.getDataChangeId());
            BillingDataChangeDTO dataChangeDTO = dataChangeService.getById(dataChangeId);
            customerDTO = objectMapper.readValue(dataChangeDTO.getJsonDataAfter(), CustomerDTO.class);

            /* check validation code and sub code already exists */
            validationCustomerCodeAndSubCodeAlreadyExists(customerDTO.getCustomerCode(), customerDTO.getSubCode(), validationErrors);

            /* set data approval data change */
            dataChangeDTO.setApproverId(approveRequest.getApproverId());
            dataChangeDTO.setApproverIPAddress(clientIP);

            /* check validation errors to custom response */
            if (!validationErrors.isEmpty()) {
                dataChangeDTO.setJsonDataAfter(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(customerDTO)));
                dataChangeService.approvalStatusIsRejected(dataChangeDTO, validationErrors);
                totalDataFailed++;
            } else {
                BillingCustomer customer = customerMapper.createEntity(customerDTO, dataChangeDTO);
                customerRepository.save(customer);
                dataChangeDTO.setDescription("Successfully approve data change and save data investment management with id: " + customer.getId());
                dataChangeDTO.setJsonDataAfter(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(customerMapper.mapToDto(customer))));
                dataChangeDTO.setEntityId(customer.getId().toString());
                dataChangeService.approvalStatusIsApproved(dataChangeDTO);
                totalDataSuccess++;
            }
        } catch (Exception e) {
            handleGeneralError(customerDTO, e, validationErrors, errorMessageDTOList);
            totalDataFailed++;
        }
        return new CustomerResponse(totalDataSuccess, totalDataFailed, errorMessageDTOList);
    }

    @Override
    public CustomerResponse updateSingleData(UpdateCustomerRequest updateCustomerRequest, BillingDataChangeDTO dataChangeDTO) {
        log.info("Update billing customer by id with request: {}", updateCustomerRequest);
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<>();
        List<String> validationErrors = new ArrayList<>();
        CustomerDTO clonedDTO = null;

        try {
            /* map data from request to dto */
            CustomerDTO customerDTO = customerMapper.mapUpdateRequestToDto(updateCustomerRequest);
            customerDTO.setBillingCategory(customerDTO.getBillingCategory().toUpperCase());
            customerDTO.setBillingType(customerDTO.getBillingType().toUpperCase());
            customerDTO.setBillingTemplate(customerDTO.getBillingTemplate().toUpperCase());
            customerDTO.setCurrency(customerDTO.getCurrency().toUpperCase());

            clonedDTO = new CustomerDTO();
            BeanUtil.copyAllProperties(customerDTO, clonedDTO);

            /* get customer entity by id */
            BillingCustomer customer = customerRepository.findById(customerDTO.getId())
                    .orElseThrow(() -> new DataNotFoundException(ID_NOT_FOUND + customerDTO.getId()));

            /* data yang akan di validator */
            copyNonNullOrEmptyFields(customer, clonedDTO);

            /* check validator for data request after mapping to dto */
            Errors errors = validateCustomerUsingValidator(clonedDTO);
            if (errors.hasErrors()) {
                errors.getAllErrors().forEach(error -> validationErrors.add(error.getDefaultMessage()));
            }

            /* validating selling agent is available or not */
            validateSellingAgent(clonedDTO, validationErrors);

            /* validating enums data */
            validateBillingEnums(clonedDTO.getBillingCategory(),
                    clonedDTO.getBillingType(),
                    clonedDTO.getCurrency(),
                    validationErrors);

            /* validating value GL must be true or false */
            validateIsGL(clonedDTO, validationErrors);

            /* validating Cost Center Debit */
            if (Boolean.FALSE.toString().equalsIgnoreCase(clonedDTO.getGl())) {
                clonedDTO.setDebitTransfer("");
            }
            validateGLForCostCenterDebit(Boolean.parseBoolean(clonedDTO.getGl()), clonedDTO.getDebitTransfer(), validationErrors);

            /* validating data billing template */
            validationBillingTemplate(clonedDTO.getBillingCategory(),
                    clonedDTO.getBillingType(),
                    clonedDTO.getCurrency(),
                    clonedDTO.getSubCode(),
                    clonedDTO.getBillingTemplate(),
                    validationErrors);

            /* validation ksei safe code */
            validationKseiSafeCode(clonedDTO, validationErrors);

            /* validating data Investment Management is available or not */
            validateIsExistsInvestmentManagement(clonedDTO, validationErrors);

            /* set input id for data change */
            dataChangeDTO.setInputerId(updateCustomerRequest.getInputerId());
            dataChangeDTO.setEntityId(customer.getId().toString());

            /* check validation errors to custom response */
            if (!validationErrors.isEmpty()) {
                ErrorMessageDTO errorMessageDTO = new ErrorMessageDTO(clonedDTO.getCustomerCode(), validationErrors);
                errorMessageDTOList.add(errorMessageDTO);
                totalDataFailed++;
            } else {
                dataChangeDTO.setJsonDataBefore(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(customerMapper.mapToDto(customer))));
                dataChangeDTO.setJsonDataAfter(JsonUtil.cleanedJsonDataUpdate(objectMapper.writeValueAsString(customerDTO)));
                dataChangeService.createChangeActionEDIT(dataChangeDTO, BillingCustomer.class);
                totalDataSuccess++;
            }
        } catch (Exception e) {
            handleGeneralError(clonedDTO, e, validationErrors, errorMessageDTOList);
            totalDataFailed++;
        }
        return new CustomerResponse(totalDataSuccess, totalDataFailed, errorMessageDTOList);
    }

    @Override
    public CustomerResponse updateMultipleData(UpdateCustomerListRequest updateCreateCustomerListRequest, BillingDataChangeDTO dataChangeDTO) {
        log.info("Update multiple billing customer with request: {}", updateCreateCustomerListRequest);
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<>();

        for (UpdateCustomerDataListRequest updateCustomerDataListRequest : updateCreateCustomerListRequest.getUpdateCustomerDataListRequests()) {
            List<String> validationErrors = new ArrayList<>();
            CustomerDTO clonedDTO = null;
            try {
                /* mapping data from request to dto */
                CustomerDTO customerDTO = customerMapper.mapUpdateListRequestToDTO(updateCustomerDataListRequest);
                customerDTO.setBillingCategory(customerDTO.getBillingCategory().toUpperCase());
                customerDTO.setBillingType(customerDTO.getBillingType().toUpperCase());
                customerDTO.setBillingTemplate(customerDTO.getBillingTemplate().toUpperCase());
                customerDTO.setCurrency(customerDTO.getCurrency().toUpperCase());

                /* create cloned dto */
                clonedDTO = new CustomerDTO();
                BeanUtil.copyAllProperties(customerDTO, clonedDTO);

                /* get data by code and sub code */
                BillingCustomer customer = customerRepository.findByCustomerCodeAndOptionalSubCode(customerDTO.getCustomerCode(), customerDTO.getSubCode())
                        .orElseThrow(() -> new DataNotFoundException(CODE_NOT_FOUND + customerDTO.getCustomerCode() + SUB_CODE_NOT_FOUND + customerDTO.getSubCode()));

                /* data yang akan di validator */
                copyNonNullOrEmptyFields(customer, clonedDTO);
                log.info("Combines Entity data and Request data: {}", clonedDTO);

                /* validating for each column dto */
                Errors errors = validateCustomerUsingValidator(clonedDTO);
                if (errors.hasErrors()) {
                    errors.getAllErrors().forEach(error -> validationErrors.add(error.getDefaultMessage()));
                }

                /* validating selling agent is available or not */
                validateSellingAgent(clonedDTO, validationErrors);

                /* validating enums data */
                validateBillingEnums(clonedDTO.getBillingCategory(),
                        clonedDTO.getBillingType(),
                        clonedDTO.getCurrency(),
                        validationErrors);

                /* validation value GL must be true or false */
                validateIsGL(customerDTO, validationErrors);

                /* validating Cost Center Debit */
                if (Boolean.FALSE.toString().equalsIgnoreCase(clonedDTO.getGl())) {
                    clonedDTO.setDebitTransfer("");
                }
                validateGLForCostCenterDebit(Boolean.parseBoolean(clonedDTO.getGl()), clonedDTO.getDebitTransfer(), validationErrors);

                /* validating data billing template */
                validationBillingTemplate(clonedDTO.getBillingCategory(),
                        clonedDTO.getBillingType(),
                        clonedDTO.getCurrency(),
                        clonedDTO.getSubCode(),
                        clonedDTO.getBillingTemplate(),
                        validationErrors);

                /* validation ksei safe code */
                validationKseiSafeCode(clonedDTO, validationErrors);

                /* validating data Investment Management is available or not */
                validateIsExistsInvestmentManagement(clonedDTO, validationErrors);

                /* set input id for data change */
                dataChangeDTO.setInputerId(updateCreateCustomerListRequest.getInputerId());
                dataChangeDTO.setEntityId(customer.getId().toString());

                /* check validation errors for custom response */
                if (!validationErrors.isEmpty()) {
                    ErrorMessageDTO errorMessageDTO = new ErrorMessageDTO(customerDTO.getCustomerCode(), validationErrors);
                    errorMessageDTOList.add(errorMessageDTO);
                    totalDataFailed++;
                } else {
                    dataChangeDTO.setJsonDataBefore(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(customerMapper.mapToDto(customer))));
                    dataChangeDTO.setJsonDataAfter(JsonUtil.cleanedJsonDataUpdate(objectMapper.writeValueAsString(customerDTO)));
                    dataChangeService.createChangeActionEDIT(dataChangeDTO, BillingCustomer.class);
                    totalDataSuccess++;
                }
            } catch (Exception e) {
                handleGeneralError(clonedDTO, e, validationErrors, errorMessageDTOList);
                totalDataFailed++;
            }
        }
        return new CustomerResponse(totalDataSuccess, totalDataFailed, errorMessageDTOList);
    }

    @Override
    public CustomerResponse updateSingleApprove(CustomerApproveRequest approveRequest, String clientIP) {
        log.info("Approve multiple update billing customer with request: {}", approveRequest);
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageList = new ArrayList<>();
        List<String> validationErrors = new ArrayList<>();
        CustomerDTO customerDTO = null;

        try {
            /* validate data change id */
            validateDataChangeId(approveRequest.getDataChangeId());

            /* get data change by id and get json data after data */
            Long dataChangeId = Long.valueOf(approveRequest.getDataChangeId());
            BillingDataChangeDTO dataChangeDTO = dataChangeService.getById(dataChangeId);
            CustomerDTO dto = objectMapper.readValue(dataChangeDTO.getJsonDataAfter(), CustomerDTO.class);
            log.info("[Update Approve] JSONDataAfter -> DTO: {}", dto);

            /* get customer by id */
            BillingCustomer customer = customerRepository.findById(Long.valueOf(dataChangeDTO.getEntityId()))
                    .orElseThrow(() -> new DataNotFoundException(ID_NOT_FOUND + dataChangeDTO.getEntityId()));

            /* set data investment management name */
            if (dto.getMiCode() != null && !dto.getMiCode().isEmpty()) {
                InvestmentManagementDTO investmentManagementDTO = investmentManagementService.getByCode(dto.getMiCode());
                customer.setMiName(investmentManagementDTO.getName());
            }

            /* check and set debit transfer */
            if (dto.getGl() != null && !dto.getGl().isEmpty() && Boolean.FALSE.toString().equalsIgnoreCase(dto.getGl())) {
                customer.setDebitTransfer("");
            }

            customerMapper.mapObjectsDtoToEntity(dto, customer);
            log.info("[Update Approve] DTO -> Entity: {}", customer);

            customerDTO = customerMapper.mapToDto(customer);
            log.info("[Update Approve] Entity -> DTO: {}", customerDTO);

            /* check validation each column */
            Errors errors = validateCustomerUsingValidator(customerDTO);
            if (errors.hasErrors()) {
                errors.getAllErrors().forEach(error -> validationErrors.add(error.getDefaultMessage()));
            }

            /* set data change information */
            dataChangeDTO.setApproverId(approveRequest.getApproverId());
            dataChangeDTO.setApproverIPAddress(clientIP);
            dataChangeDTO.setEntityId(customer.getId().toString());

            /* check validation errors for custom response */
            if (!validationErrors.isEmpty()) {
                dataChangeDTO.setJsonDataAfter(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(dto)));
                dataChangeService.approvalStatusIsRejected(dataChangeDTO, validationErrors);
                totalDataFailed++;
            } else {
                BillingCustomer customerUpdated = customerMapper.updateEntity(customer, dataChangeDTO);
                BillingCustomer customerSaved = customerRepository.save(customerUpdated);
                dataChangeDTO.setJsonDataAfter(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(customerMapper.mapToDto(customerSaved))));
                dataChangeDTO.setDescription("Successfully approved and update data entity with id: " + customerSaved.getId());
                dataChangeService.approvalStatusIsApproved(dataChangeDTO);
                totalDataSuccess++;
            }
        } catch (Exception e) {
            handleGeneralError(customerDTO, e, validationErrors, errorMessageList);
            totalDataFailed++;
        }
        return new CustomerResponse(totalDataSuccess, totalDataFailed, errorMessageList);
    }

    @Override
    public CustomerResponse deleteSingleData(DeleteCustomerRequest deleteCustomerRequest, BillingDataChangeDTO dataChangeDTO) {
        log.info("Delete single data billing customer with request: {}", deleteCustomerRequest);
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<>();
        List<String> validationErrors = new ArrayList<>();
        CustomerDTO customerDTO = null;

        try {
            /* get data by id */
            Long id = deleteCustomerRequest.getId();
            BillingCustomer customer = customerRepository.findById(id)
                    .orElseThrow(() -> new DataNotFoundException(ID_NOT_FOUND + id));

            customerDTO = customerMapper.mapToDto(customer);

            dataChangeDTO.setInputerId(deleteCustomerRequest.getInputerId());
            dataChangeDTO.setJsonDataBefore(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(customer)));
            dataChangeDTO.setJsonDataAfter("");
            dataChangeDTO.setEntityId(customer.getId().toString());
            dataChangeService.createChangeActionDELETE(dataChangeDTO, BillingCustomer.class);
            totalDataSuccess++;
        } catch (Exception e) {
            handleGeneralError(customerDTO, e, validationErrors, errorMessageDTOList);
            totalDataFailed++;
        }
        return new CustomerResponse(totalDataSuccess, totalDataFailed, errorMessageDTOList);
    }

    @Override
    public CustomerResponse deleteSingleApprove(CustomerApproveRequest approveRequest, String clientIP) {
        log.info("Approve delete multiple billing customer with request: {}", approveRequest);
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<>();
        List<String> validationErrors = new ArrayList<>();
        CustomerDTO customerDTO = null;

        try {
            /* validate data change id */
            validateDataChangeId(approveRequest.getDataChangeId());

            /* get data change by id and get Entity ID */
            Long dataChangeId = Long.valueOf(approveRequest.getDataChangeId());
            BillingDataChangeDTO dataChangeDTO = dataChangeService.getById(dataChangeId);
            Long entityId = Long.valueOf(dataChangeDTO.getEntityId());

            BillingCustomer customer = customerRepository.findById(entityId)
                    .orElseThrow(() -> new DataNotFoundException(ID_NOT_FOUND + entityId));
            customerDTO = customerMapper.mapToDto(customer);

            dataChangeDTO.setApproverId(approveRequest.getApproverId());
            dataChangeDTO.setApproverIPAddress(clientIP);
            dataChangeDTO.setJsonDataBefore(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(customer)));
            dataChangeDTO.setDescription("Successfully approve data change and delete data entity with id: " + customer.getId());
            dataChangeService.approvalStatusIsApproved(dataChangeDTO);
            customerRepository.delete(customer);
            totalDataSuccess++;
        } catch (Exception e) {
            handleGeneralError(customerDTO, e, validationErrors, errorMessageDTOList);
            totalDataFailed++;
        }
        return new CustomerResponse(totalDataSuccess, totalDataFailed, errorMessageDTOList);
    }

    @Override
    public CustomerDTO getById(String id) {
        BillingCustomer billingCustomer = customerRepository.findById(Long.valueOf(id))
                .orElseThrow(() -> new DataNotFoundException(ID_NOT_FOUND + id));
        return customerMapper.mapToDto(billingCustomer);
    }

    @Override
    public BillingCustomer getByCustomerCodeAndSubCodeAndBillingCategoryAndBillingType(String customerCode, String subCode, String billingCategory, String billingType) {
        return customerRepository.findByCustomerCodeAndSubCodeAndBillingCategoryAndBillingType(customerCode, subCode, billingCategory, billingType)
                .orElseThrow(() -> new DataNotFoundException("Customer not found with customer code: " + customerCode + ", sub code: " + subCode + ", billing category: " + billingCategory + ", and billing type: " + billingType));
    }

    private Errors validateCustomerUsingValidator(CustomerDTO dto) {
        Errors errors = new BeanPropertyBindingResult(dto, "customerDTO");
        validator.validate(dto, errors);
        return errors;
    }

    private void validationCustomerCodeAndSubCodeAlreadyExists(String customerCode, String subCode, List<String> validationErrors) {
        if (isCodeAlreadyExists(customerCode, subCode)) {
            validationErrors.add("Billing Customer already taken with code: " + customerCode + ", and sub code: " + subCode);
        }
    }

    private void validationBillingTemplate(String category, String type, String currency, String subCode, String templateName, List<String> validationErrors) {
        if (!billingTemplateService.isExistsByCategoryAndTypeAndCurrencyAndSubCodeAndTemplateName(category, type, currency, subCode, templateName)) {
            validationErrors.add("Billing Template not found with category: " + category
                    + ", type: " + type
                    + ", currency: " + currency
                    + ", sub code: " + subCode
                    + ", and template name: " + templateName);
        }
    }

    private void validateSellingAgent(CustomerDTO customerDTO, List<String> validationErrors) {
        if (!StringUtils.isEmpty(customerDTO.getSellingAgent()) && !sellingAgentService.isCodeAlreadyExists(customerDTO.getSellingAgent())) {
            validationErrors.add("Selling Agent not found with code: " + customerDTO.getSellingAgent());
        }
    }

    private void validateDataChangeId(String dataChangeId) {
        if (!dataChangeService.existById(Long.valueOf(dataChangeId))) {
            log.info("Data Change ids not found: {}", dataChangeId);
            throw new DataNotFoundException("Data Change id not found with id: " + dataChangeId);
        }
    }

    private void validateIsExistsInvestmentManagement(CustomerDTO customerDTO, List<String> validationErrors) {
        if (!investmentManagementService.isExistsByCode(customerDTO.getMiCode())) {
            validationErrors.add(INVESTMENT_MANAGEMENT_NOT_FOUND_WITH_CODE + customerDTO.getMiCode());
        }
    }

    private void handleGeneralError(CustomerDTO customerDTO, Exception e, List<String> validationErrors, List<ErrorMessageDTO> errorMessageList) {
        log.error("An unexpected error occurred: {}", e.getMessage(), e);
        validationErrors.add(e.getMessage());
        errorMessageList.add(new ErrorMessageDTO(customerDTO != null ? customerDTO.getCustomerCode() : UNKNOWN, validationErrors));
    }

    private void validateBillingEnums(String billingCategory, String billingType, String currency, List<String> validationErrors) {
        if (EnumValidator.validateEnumBillingCategory(billingCategory)) {
            validationErrors.add("Billing Category enum not found with value: " + billingCategory);
        }
        if (EnumValidator.validateEnumBillingType(billingType)) {
            validationErrors.add("Billing Type enum not found with value: " + billingType);
        }
        if (EnumValidator.validateEnumCurrency(currency)) {
            validationErrors.add("Currency enum not found with value: " + currency);
        }
    }

    private void validateGLForCostCenterDebit(boolean isGL, String debitTransfer, List<String> validationErrors) {
        if (isGL) {
            if (debitTransfer == null || debitTransfer.isEmpty()) {
                validationErrors.add("Cost Center Debit is required when GL is true");
            }
        } else {
            if (!StringUtils.isEmpty(debitTransfer)) {
                validationErrors.add("Cost Center Debit must be blank when GL is false");
            }
        }
    }

    private void validateIsGL(CustomerDTO customerDTO, List<String> validationErrors) {
        if (isValidIsGLValue(customerDTO.getGl())) {
            validationErrors.add(INVALID_VALUE_TRUE_OR_FALSE);
        }
    }

    private boolean isValidIsGLValue(String isGL) {
        return !"TRUE".equalsIgnoreCase(isGL) && !"FALSE".equalsIgnoreCase(isGL);
    }

    private void copyNonNullOrEmptyFields(BillingCustomer customer, CustomerDTO customerDTO) {
        try {
            Map<String, String> entityProperties = BeanUtils.describe(customer);

            for (Map.Entry<String, String> entry : entityProperties.entrySet()) {
                String propertyName = entry.getKey();
                String entityValue = entry.getValue();

                String dtoValue = BeanUtils.getProperty(customerDTO, propertyName);

                if (isNullOrEmpty(dtoValue) && entityValue != null) {
                    BeanUtils.setProperty(customerDTO, propertyName, entityValue);
                }
            }
        } catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException e) {
            throw new GeneralException("Failed while processing copy non null or empty fields", e);
        }
    }

    private boolean isNullOrEmpty(String str) {
        return str == null || str.trim().isEmpty();
    }

    private void validationKseiSafeCode(CustomerDTO customerDTO, List<String> validationErrors) {
        String kseiSafeCodeTrim = customerDTO.getKseiSafeCode() != null ? customerDTO.getKseiSafeCode().trim() : null;
        log.info("KSEI Safe Code: {}", kseiSafeCodeTrim);

        if (CORE.name().equalsIgnoreCase(customerDTO.getBillingCategory())) {
            Set<String> billingTypes = new HashSet<>();
            billingTypes.add(TYPE_4.name());
            billingTypes.add(TYPE_5.name());
            billingTypes.add(TYPE_6.name());
            billingTypes.add(TYPE_7.name());

            if (billingTypes.contains(customerDTO.getBillingType()) && (kseiSafeCodeTrim == null || kseiSafeCodeTrim.isEmpty())) {
                validationErrors.add(KSEI_SAFE_CODE_REQUIRED + customerDTO.getBillingType());
            }
        }
    }

}
