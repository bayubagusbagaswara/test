package com.services.billingservice.config.placement;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.TimeUnit;

@Component
@Slf4j
public class ThreadPoolManager implements DisposableBean {

    private final List<ExecutorService> threadPools = new ArrayList<>();

    public void registerThreadPool(ExecutorService executor) {
        threadPools.add(executor);
    }

    @Override
    public void destroy() throws Exception {
        log.info("Shutting down {} thread pools", threadPools.size());
        for (ExecutorService pool : threadPools) {
            shutdownPool(pool);
        }
    }

    private void shutdownPool(ExecutorService pool) {
        pool.shutdown();
        try {
            if (!pool.awaitTermination(5, TimeUnit.SECONDS)) {
                log.warn("Force shutting down thread pool: {}", pool);
                pool.shutdownNow();
            }
        } catch (InterruptedException e) {
            pool.shutdownNow();
            Thread.currentThread().interrupt();
        }
    }

}
