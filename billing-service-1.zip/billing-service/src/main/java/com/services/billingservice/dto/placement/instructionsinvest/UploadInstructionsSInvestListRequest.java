package com.services.billingservice.dto.placement.instructionsinvest;

import com.services.billingservice.dto.approval.InputIdentifierRequest;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.util.List;

@EqualsAndHashCode(callSuper = true)
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class UploadInstructionsSInvestListRequest extends InputIdentifierRequest {

    private List<UploadInstructionsSInvestDataRequest> uploadInstructionsSInvestDataRequestList;

}
