package com.services.billingservice.repository;

import com.services.billingservice.model.BillingGlCredit;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface BillingGlCreditRepository extends JpaRepository<BillingGlCredit, Long> {

    @Query(value = "SELECT * FROM billing_gl_credit  " +
            "WHERE gl_billing_template = :billTemplate ", nativeQuery = true)
    BillingGlCredit findByGlBillingTemplate(@Param("billTemplate") String billingTemplate);

    @Query(value = "SELECT * FROM billing_gl_credit  " +
            "WHERE gl_billing_template = :billTemplate order by jurnalSequence asc", nativeQuery = true)
    List<BillingGlCredit> findAllByGlBillingTemplate(@Param("billTemplate") String billingTemplate);

    @Query(value = "SELECT * FROM billing_gl_credit " +
            "WHERE gl_billing_template = :billingTemplate " +
            "AND gl_credit_name = :glCreditName", nativeQuery = true)
    Optional<BillingGlCredit> findByGlBillingTemplateAndGlCreditName(
            @Param("billingTemplate") String billingTemplate,
            @Param("glCreditName") String glCreditName
    );

}
