package com.services.billingservice.service;

import com.services.billingservice.dto.datachange.BillingDataChangeDTO;
import com.services.billingservice.dto.sellingagent.*;

import java.util.List;

public interface BillingSellingAgentDataService {

    boolean isCodeAlreadyExists(String sellingAgentCode);

    SellingAgentDTO getBySellingAgentCode(String sellingAgentCode);

    SellingAgentResponse createSingleData(CreateSellingAgentRequest createSellingAgentRequest, BillingDataChangeDTO dataChangeDTO);

    SellingAgentResponse createSingleApprove(SellingAgentApproveRequest sellingAgentApproveRequest, String clientIP);

    SellingAgentResponse updateSingleData(UpdateSellingAgentRequest updateSellingAgentRequest, BillingDataChangeDTO dataChangeDTO);

    SellingAgentResponse updateSingleApprove(SellingAgentApproveRequest sellingAgentApproveRequest, String clientIP);

    SellingAgentResponse deleteSingleData(DeleteSellingAgentRequest deleteRequest, BillingDataChangeDTO dataChangeDTO);

    SellingAgentResponse deleteSingleApprove(SellingAgentApproveRequest approveRequest, String clientIP);

    List<SellingAgentDTO> getAll();

    String deleteAll();

}
