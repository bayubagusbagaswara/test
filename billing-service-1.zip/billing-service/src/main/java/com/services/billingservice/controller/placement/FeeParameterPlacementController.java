package com.services.billingservice.controller.placement;

import com.services.billingservice.dto.ResponseDTO;
import com.services.billingservice.dto.placement.feeparameter.CreateFeeParameterPlacementRequest;
import com.services.billingservice.dto.placement.feeparameter.FeeParameterPlacementDTO;
import com.services.billingservice.model.placement.FeeParameterPlacement;
import com.services.billingservice.service.placement.FeeParameterPlacementService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(path = "/api/placement/fee-parameter")
@CrossOrigin(origins = "*", allowedHeaders = "*")
@RequiredArgsConstructor
@Slf4j
public class FeeParameterPlacementController {

    private final FeeParameterPlacementService feeParameterPlacementService;

    @PostMapping(path = "/create")
    public ResponseEntity<ResponseDTO<List<FeeParameterPlacement>>> create(@RequestBody List<CreateFeeParameterPlacementRequest> createFeeParameterPlacementRequestList) {
        List<FeeParameterPlacement> feeParameterPlacements = feeParameterPlacementService.create(createFeeParameterPlacementRequestList);
        ResponseDTO<List<FeeParameterPlacement>> response = ResponseDTO.<List<FeeParameterPlacement>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(feeParameterPlacements)
                .build();
        return ResponseEntity.ok(response);
    }

    @GetMapping(path = "/all")
    public ResponseEntity<ResponseDTO<List<FeeParameterPlacementDTO>>>getAll(){
        List<FeeParameterPlacementDTO> feeParameterDTOList = feeParameterPlacementService.getAll();
        ResponseDTO<List<FeeParameterPlacementDTO>> response = ResponseDTO.<List<FeeParameterPlacementDTO>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(feeParameterDTOList)
                .build();
        return  ResponseEntity.ok(response);
    }



}
