package com.services.billingservice.dto.mi;

import com.services.billingservice.dto.approval.InputIdentifierRequest;
import lombok.*;
import lombok.experimental.SuperBuilder;

import java.util.List;

@EqualsAndHashCode(callSuper = true)
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class UpdateInvestmentManagementListRequest extends InputIdentifierRequest {

    private List<UpdateInvestmentManagementDataListRequest> updateInvestmentManagementDataListRequests;
}
