package com.services.billingservice.dto.retail;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import javax.persistence.Column;
import java.math.BigDecimal;

/**
 * change data type, must be equal with model Billing Core
 */
@EqualsAndHashCode(callSuper = true)
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class UpdateBillingRetailRequest extends BillingRetailBaseDTO {

    private Long id;
    private BigDecimal safekeepingFR;
    private BigDecimal safekeepingSR;
    private BigDecimal safekeepingST;
    private BigDecimal safekeepingORI;
    private BigDecimal safekeepingSBR;
    private BigDecimal safekeepingPBS;
    private BigDecimal safekeepingCorporateBond;
    private BigDecimal totalAmountDue;
    private BigDecimal safekeepingValueFrequency;
    private BigDecimal safekeepingFee;
    private BigDecimal safekeepingAmountDue;
    private Integer transactionSettlementValueFrequency;
    private BigDecimal transactionSettlementFee;
    private BigDecimal transactionSettlementAmountDue;
    private Integer adHocReportValueFrequency;
    private BigDecimal adHocReportFee;
    private BigDecimal adHocReportAmountDue;
    private Integer thirdPartyValueFrequency;
    private BigDecimal thirdPartyFee;
    private BigDecimal thirdPartyAmountDue;
    private BigDecimal vatFee;
    private BigDecimal vatAmountDue;
    private BigDecimal subTotalAmountDue;
    private Integer transactionHandlingValueFrequency;
    private BigDecimal transactionHandlingFee;
    private BigDecimal transactionHandlingAmountDue;
    private Integer transactionHandlingInternalValueFrequency;
    private BigDecimal transactionHandlingInternalFee;
    private BigDecimal transactionHandlingInternalAmountDue;
    private Integer transferValueFrequency;
    private BigDecimal transferFee;
    private BigDecimal transferAmountDue;
}
