package com.services.billingservice.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "billing_email_processing")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BillingEmailProcessing {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name =  "bill_customer_name")
    private String customerName;

    @Column(name = "bill_customer_email")
    private String customerEmail;

    @Column(name = "bill_period")
    private String period;

    @Column(name = "bill_email_status")
    private String emailStatus;

    @Column(name = "bill_sentAt")
    private Date sentAt;

    @Column(name = "bill_desc")
    private String desc;

    @Column(name = "bill_category")
    private String category;

}
