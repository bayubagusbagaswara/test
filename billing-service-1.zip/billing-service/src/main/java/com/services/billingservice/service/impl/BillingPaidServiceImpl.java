package com.services.billingservice.service.impl;

import com.services.billingservice.dto.billing.UpdatePaidRequest;
import com.services.billingservice.enums.ApprovalStatus;
import com.services.billingservice.enums.GefuTransactionStatus;
import com.services.billingservice.model.*;
import com.services.billingservice.repository.*;
import com.services.billingservice.service.BillingPaidService;
import com.services.billingservice.utils.ConvertDateUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

import static com.services.billingservice.enums.BillingCategory.CORE;
import static com.services.billingservice.enums.BillingCategory.FUND;
import static com.services.billingservice.enums.BillingCategory.RETAIL;

@Service
@Slf4j
@RequiredArgsConstructor
public class BillingPaidServiceImpl implements BillingPaidService {

    private final BillingFundRepository fundRepository;
    private final BillingCoreRepository coreRepository;
    private final BillingRetailRepository retailRepository;
    private final BillingGefuDetailRepository gefuDetailRepository;
    private final BillingGefuHistoryRepository gefuHistoryRepository;
    private final ConvertDateUtil convertDateUtil;

    @Override
    public String updatePaidStatus(UpdatePaidRequest request) {
        log.info("Update billing paid with request: {}", request);

        /* covert to uppercase */
        String customerCodeUpperCase = request.getCustomerCode().toUpperCase();
        String categoryUpperCase = request.getCategory().toUpperCase();

        /* extract period */
        Map<String, String> stringMap = convertDateUtil.extractMonthYearInformation(request.getPeriod());
        String monthName = stringMap.get("monthName");
        int year = Integer.parseInt(stringMap.get("year"));

        /* check category */
        if (FUND.getValue().equalsIgnoreCase(categoryUpperCase)) {
            List<BillingFund> billingFundList = fundRepository.findAllByCustomerCodeAndMonthAndYear(customerCodeUpperCase, monthName, year);
            if (!billingFundList.isEmpty()) {
                for (BillingFund billingFund : billingFundList) {
                    billingFund.setPaid(true);
                    fundRepository.save(billingFund);
                }
            }
        } else if (CORE.getValue().equalsIgnoreCase(categoryUpperCase)) {
            List<BillingCore> billingCoreList = coreRepository.findAllByCustomerCodeAndMonthAndYear(customerCodeUpperCase, monthName, year);
            if (!billingCoreList.isEmpty()) {
                for (BillingCore billingCore : billingCoreList) {
                    billingCore.setPaid(true);
                    coreRepository.save(billingCore);
                }
            }
        } else if (RETAIL.getValue().equalsIgnoreCase(categoryUpperCase)) {
            List<BillingRetail> billingRetailList = retailRepository.findAllByCustomerCodeAndMonthAndYear(customerCodeUpperCase, monthName, year);
            if (!billingRetailList.isEmpty()) {
                for (BillingRetail billingRetail : billingRetailList) {
                    billingRetail.setPaid(true);
                    retailRepository.save(billingRetail);
                }
            }
        }

        List<BillingGefuProcessDetail> gefuProcessDetailList = gefuDetailRepository.findAllByFileName(request.getGefuFileName());

        List<BillingGefuProcessHistory> gefuProcessHistorieslList = gefuHistoryRepository.findAllByFileName(request.getGefuFileName());

        if (!gefuProcessDetailList.isEmpty()) {
            for (BillingGefuProcessDetail gefuProcessDetail : gefuProcessDetailList) {
                for( BillingGefuProcessHistory gefuProcessHistory :gefuProcessHistorieslList) {
                    gefuProcessDetail.setStatus(GefuTransactionStatus.Success);
                    gefuProcessHistory.setApprovalStatus(ApprovalStatus.Approved);
                    gefuDetailRepository.save(gefuProcessDetail);
                    gefuHistoryRepository.save(gefuProcessHistory);
                }
            }
        }

        return "Successfully update paid status with category: " + categoryUpperCase + "and period: " + request.getPeriod();
    }

}
