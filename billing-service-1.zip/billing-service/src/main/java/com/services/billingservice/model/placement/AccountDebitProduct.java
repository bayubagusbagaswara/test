package com.services.billingservice.model.placement;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import javax.persistence.*;

@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "placement_master_product_rekening_debit")
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class AccountDebitProduct extends BasePlacementApproval {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "product_code")
    private String productCode;

    @Column(name = "fund_code")
    private String fundCode;

    @Column(name = "fund_name")
    private String fundName;

    @Column(name = "im_code")
    private String imCode;

    @Column(name = "im_name")
    private String imName;

    @Column(name = "currency")
    private String currency;

    @Column(name = "cash_account")
    private String cashAccount;

    @Column(name = "bank_name")
    private String bankName;

}
