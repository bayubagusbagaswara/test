package com.services.billingservice.model;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Data
@Table(name = "rb_connection_parameter")
public class ConnectionParameter {

    @Id
    private String id;

    private String ncbsSftpHost;
    private String ncbsSftpUser;
    private String ncbsSftpPrivateKeyPath;
    private String ncbsSftpLocalFolderOutgoing;
    private String ncbsSftpLocalFolderIncoming;
    private String ncbsSftpRemoteFolderIn;
    private String ncbsSftpRemoteFolderOut;
    private String ncbsFileNamePattern;
    private String ncbsFileNameDateFormat;
    private String ncbsFilePassword;
    private String ncbsFileSaltHex;
    private String ncbsProfileName;
    private String ncbsDebitAccountNumber;
    private String ncbsDebitGlNumber;
    private String ncbsDebitCostCenter;
    private String ncbsCreditAccountNumber;
    private String ncbsCreditGlNumber;
    private String ncbsCreditCostCenter;
    private String gefuPassword;
    private String ldapHost;
    private String gefuFileNamePattern;
    private String gefuSftpLocalFolderIncoming;
    private String gefuSftpLocalFolderOutgoing;
    private String gefuResponsePassword;
    private String type;
}
