package com.services.billingservice.controller.placement;

import com.services.billingservice.dto.ResponseDTO;
import com.services.billingservice.dto.placement.responsecode.CreateResponseCodeRequest;
import com.services.billingservice.model.placement.ResponseCode;
import com.services.billingservice.service.placement.ResponseCodeService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping(path = "/api/placement/response-code")
@RequiredArgsConstructor
@Slf4j
public class ResponseCodeController {

    private final ResponseCodeService responseCodeService;

    @PostMapping(path = "/create")
    public ResponseEntity<ResponseDTO<List<ResponseCode>>> create(@RequestBody List<CreateResponseCodeRequest> createResponseCodeRequests) {
        List<ResponseCode> responseCodes = responseCodeService.create(createResponseCodeRequests);
        ResponseDTO<List<ResponseCode>> response = ResponseDTO.<List<ResponseCode>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(responseCodes)
                .build();
        return ResponseEntity.ok(response);
    }

}
