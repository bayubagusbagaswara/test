package com.services.billingservice.model.placement;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Entity
@Table(name = "placement_response_code")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ResponseCode {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "name")
    private String name;

    @Column(name = "ncbs_response_message")
    private String ncbsResponseMessage;

    @Column(name = "ncbs_response_code")
    private String ncbsResponseCode;

}
