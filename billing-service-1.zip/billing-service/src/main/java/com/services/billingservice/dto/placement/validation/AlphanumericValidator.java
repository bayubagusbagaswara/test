package com.services.billingservice.dto.placement.validation;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class AlphanumericValidator implements ConstraintValidator<Alphanumeric, String> {

    @Override
    public boolean isValid(String value, ConstraintValidatorContext constraintValidatorContext) {
        if (value == null) {
            return true; // Jika null valid, jika tidak ubah menjadi false
        }
        String trim = value.trim();
        // alphanumeric = ^[a-zA-Z0-9]*$
        return trim.matches("^[a-zA-Z0-9-]*$");
    }

}
