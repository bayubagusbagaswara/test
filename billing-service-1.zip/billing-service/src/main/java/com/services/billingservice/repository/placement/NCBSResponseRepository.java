package com.services.billingservice.repository.placement;

import com.services.billingservice.model.placement.NCBSResponse;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface NCBSResponseRepository extends JpaRepository<NCBSResponse, Long> {

    @Query("SELECT n FROM NCBSResponse n WHERE n.placementDate = :placementDate AND n.ncbsStatus = :ncbsStatus AND n.serviceType = :serviceType")
    List<NCBSResponse> findAllByPlacementDateAndNcbsStatusAndServiceType(
            @Param("placementDate") LocalDate placementDate,
            @Param("ncbsStatus") String ncbsStatus,
            @Param("serviceType") String serviceType
    );

}
