package com.services.billingservice.enums.placement;

import lombok.Getter;

@Getter
public enum TransactionType {

    SKN("3"),
    RTGS("1");

    private final String code;

    TransactionType(String code) {
        this.code = code;
    }

    public static TransactionType fromString(String value) {
        for (TransactionType type : TransactionType.values()) {
            if (type.name().equalsIgnoreCase(value)) {
                return type;
            }
        }
        throw new IllegalArgumentException("Unknown transaction type: " + value);
    }
}
