package com.services.billingservice.exception.placement;

import lombok.Getter;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@Getter
@ResponseStatus(HttpStatus.BAD_GATEWAY)
public class TransferPlacementException extends RuntimeException {

    private final String responseCode;
    private final String responseMessage;

    public TransferPlacementException(String responseCode, String responseMessage) {
        super(responseMessage);
        this.responseCode = responseCode;
        this.responseMessage = responseMessage;
    }

    public TransferPlacementException(String responseCode, String responseMessage, Throwable cause) {
        super(responseMessage, cause);
        this.responseCode = responseCode;
        this.responseMessage = responseMessage;
    }

}
