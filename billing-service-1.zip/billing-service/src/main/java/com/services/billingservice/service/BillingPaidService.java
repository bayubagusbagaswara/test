package com.services.billingservice.service;

import com.services.billingservice.dto.billing.UpdatePaidRequest;

public interface BillingPaidService {

    String updatePaidStatus(UpdatePaidRequest request);

}
