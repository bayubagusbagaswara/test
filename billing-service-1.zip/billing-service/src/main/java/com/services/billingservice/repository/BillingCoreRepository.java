package com.services.billingservice.repository;

import com.services.billingservice.dto.core.BillingCoreListProcess;
import com.services.billingservice.model.BillingCore;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

@Repository
public interface BillingCoreRepository extends JpaRepository<BillingCore, Long> {

    //TODO for payment
    @Query(value = "SELECT * FROM billing_core " +
            "WHERE month = :month " +
            "AND year = :year " +
            "AND approval_status = :approvalStatus", nativeQuery = true)
    List<BillingCore> findAllByMonthAndYearAndApprovalStatus(
            @Param("month") String month,
            @Param("year") int year,
            @Param("approvalStatus") String approvalStatus
    );

    @Query(value = "SELECT * FROM billing_core " +
            "WHERE bill_category = :billingCategory " +
            "AND month = :month " +
            "AND year = :year " +
            "AND approval_status = :approvalStatus", nativeQuery = true)
    List<BillingCore> findAllByCategoryAndMonthAndYearAndApprovalStatus(
            @Param("billingCategory") String billingCategory,
            @Param("month") String month,
            @Param("year") int year,
            @Param("approvalStatus") String approvalStatus
    );

    @Query(value = "SELECT * FROM billing_core " +
            "WHERE customer_code=:custCode AND month = :month " +
            "AND year = :year " +
            "AND approval_status = :approvalStatus", nativeQuery = true)
    BillingCore findByCustomerCodeAndMonthAndYearAndApprovalStatus(
            @Param("month") String month,
            @Param("year") int year,
            @Param("custCode") String custCode,
            @Param("approvalStatus") String approvalStatus
    );

    //TODO for payment
    @Query(value = "SELECT * FROM billing_core " +
            "WHERE bill_type = :billingType " +
            "AND month = :month " +
            "AND year = :year " +
            "AND approval_status = :approvalStatus", nativeQuery = true)
    List<BillingCore> findAllByBillingTypeAndMonthAndYearAndApprovalStatus(
            @Param("billingType") String billingType,
            @Param("month") String month,
            @Param("year") int year,
            @Param("approvalStatus") String approvalStatus
    );

    @Query(value = "SELECT * FROM billing_core " +
            "WHERE bill_category = :billingCategory " +
            "AND bill_type = :billingType " +
            "AND month = :month " +
            "AND year = :year " +
            "AND approval_status = :approvalStatus", nativeQuery = true)
    List<BillingCore> findAllByBillingCategoryAndBillingTypeAndMonthAndYearAndApprovalStatus(
            @Param("billingCategory") String billingCategory,
            @Param("billingType") String billingType,
            @Param("month") String month,
            @Param("year") int year,
            @Param("approvalStatus") String approvalStatus
    );

    @Query(value = "SELECT * FROM billing_core " +
            "WHERE bill_category = :billingCategory " +
            "AND bill_type = :billingType " +
            "AND month = :month " +
            "AND year = :year", nativeQuery = true)
    List<BillingCore> findAllByBillingCategoryAndBillingTypeAndMonthAndYear(
            @Param("billingCategory") String billingCategory,
            @Param("billingType") String billingType,
            @Param("month") String month,
            @Param("year") Integer year
    );

    @Query(value = "SELECT * FROM billing_core " +
            "WHERE bill_category = :billingCategory " +
            "AND bill_type = :billingType " +
            "AND month = :month " +
            "AND year = :year " +
            "AND customer_code = :customerCode", nativeQuery = true)
    List<BillingCore> findAllByBillingCategoryAndBillingTypeAndMonthAndYearAndAid(
            @Param("billingCategory") String billingCategory,
            @Param("billingType") String billingType,
            @Param("month") String month,
            @Param("year") Integer year,
            @Param("customerCode") String customerCode
    );

    @Query(value = "SELECT * FROM billing_core " +
            "WHERE customer_code = :customerCode " +
            "AND bill_category = :billingCategory " +
            "AND bill_type = :billingType " +
            "AND month = :month " +
            "AND year = :year", nativeQuery = true)
    List<BillingCore> findAllByCustomerCodeAndBillingCategoryAndBillingTypeAndMonthAndYear(
            @Param("customerCode") String customerCode,
            @Param("billingCategory") String billingCategory,
            @Param("billingType") String billingType,
            @Param("month") String monthName,
            @Param("year") int year);

    @Query(value = "SELECT DISTINCT NEW com.services.billingservice.dto.core.BillingCoreListProcess " +
            "(f.month, f.year, MAX(f.createdAt)) " +
            "FROM BillingCore f " +
            "GROUP BY f.month, f.year " +
            "ORDER BY f.year DESC, month DESC")
    List<BillingCoreListProcess> getAllListProcess();

    @Query(value = "SELECT DISTINCT NEW com.services.billingservice.dto.core.BillingCoreListProcess " +
            "(f.month, f.year, MAX(f.createdAt)) " +
            "FROM BillingCore f " +
            "WHERE upper(f.approvalStatus) = 'PENDING' " +
            "   AND upper(f.billingStatus) = 'REVIEWED' " +
            "GROUP BY f.month, f.year " +
            "ORDER BY f.year DESC, month DESC")
    List<BillingCoreListProcess> getAllListPendingApprove();

    List<BillingCore> findByMonthAndYear(String month, Integer year);

    @Query(value = "SELECT * FROM billing_core " +
            "WHERE bill_category = :billingCategory " +
            "AND month = :month " +
            "AND year = :year", nativeQuery = true)
    List<BillingCore> findAllByCategoryPeriod(
            @Param("month") String monthName,
            @Param("year") int year,
            @Param("billingCategory") String category);

    @Query(value = "SELECT * FROM billing_core WHERE customer_code = :customerCode " +
            "AND bill_category = :billingCategory " +
            "AND bill_type = :billingType " +
            "AND month = :monthName " +
            "AND year = :year", nativeQuery = true)
    Optional<BillingCore> findByCustomerCodeAndBillingCategoryAndBillingTypeAndMonthAndYear(
            @Param("customerCode") String customerCode,
            @Param("billingCategory") String billingCategory,
            @Param("billingType") String billingType,
            @Param("monthName") String monthName,
            @Param("year") Integer year);

    @Query(value = "SELECT * FROM billing_core WHERE customer_code = :customerCode " +
            "AND sub_code = :subCode " +
            "AND bill_category = :billingCategory " +
            "AND bill_type = :billingType " +
            "AND month = :monthName " +
            "AND year = :year", nativeQuery = true)
    Optional<BillingCore> findByCustomerCodeAndSubCodeAndBillingCategoryAndBillingTypeAndMonthAndYear(
            @Param("customerCode") String customerCode,
            @Param("subCode") String subCode,
            @Param("billingCategory") String billingCategory,
            @Param("billingType") String billingType,
            @Param("monthName") String monthName,
            @Param("year") Integer year);

    @Query(value = "SELECT * FROM billing_core " +
            "WHERE bill_category = :billingCategory " +
            "AND month = :month " +
            "AND year = :year " +
            "AND approval_status = :approvalStatus " +
            "AND total_amount_due > :amount", nativeQuery = true)
    List<BillingCore> findAllByBillingCategoryAndMonthAndYearAndApprovalStatusAndAmount(
            @Param("billingCategory") String billingCategory,
            @Param("month") String monthName,
            @Param("year") int year,
            @Param("approvalStatus") String approvalStatusIsApproved,
            @Param("amount") BigDecimal amount);

    @Query(value = "SELECT * FROM billing_core " +
            "WHERE customer_code = :customerCode " +
            "AND month = :monthName " +
            "AND year = :year", nativeQuery = true)
    List<BillingCore> findAllByCustomerCodeAndMonthAndYear(@Param("customerCode") String customerCode,
                                                           @Param("monthName") String monthName,
                                                           @Param("year") int year);
}
