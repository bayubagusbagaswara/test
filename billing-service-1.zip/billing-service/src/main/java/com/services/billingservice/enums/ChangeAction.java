package com.services.billingservice.enums;

public enum  ChangeAction {
        Add, Edit, Delete
}
