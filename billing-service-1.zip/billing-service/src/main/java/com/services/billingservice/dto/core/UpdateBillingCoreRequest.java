package com.services.billingservice.dto.core;

import lombok.*;
import lombok.experimental.SuperBuilder;

import java.math.BigDecimal;

/**
 * change data type, must be equal with model Billing Core
 */
@EqualsAndHashCode(callSuper = true)
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class UpdateBillingCoreRequest extends BillingCoreBaseDTO {

    private Long id;

    private Integer transactionHandlingValueFrequency;
    private BigDecimal transactionHandlingFee;
    private BigDecimal transactionHandlingAmountDue;

    private BigDecimal safekeepingValueFrequency;
    private BigDecimal safekeepingFee;
    private BigDecimal safekeepingAmountDue;

    private BigDecimal subTotal;

    private BigDecimal vatFee;
    private BigDecimal vatAmountDue;

    private BigDecimal totalAmountDue;

    // especially core type 3
    private String journalCreditTo;

    // especially for KSEI Safe Fee
    private BigDecimal kseiSafekeepingAmountDue;

    private Integer kseiTransactionValueFrequency;
    private BigDecimal kseiTransactionFee;
    private BigDecimal kseiTransactionAmountDue;

    private Integer bis4TransactionValueFrequency;
    private BigDecimal bis4TransactionFee;
    private BigDecimal bis4TransactionAmountDue;

    // journal
    private String safekeepingFeeJournal;
    private String transactionHandlingJournal;

    // especially core type 8
    private Integer administrationSetUpItem;
    private BigDecimal administrationSetUpFee;
    private BigDecimal administrationSetUpAmountDue;

    private Integer signingRepresentationItem;
    private BigDecimal signingRepresentationFee;
    private BigDecimal signingRepresentationAmountDue;

    private Integer securityAgentItem;
    private BigDecimal securityAgentFee;
    private BigDecimal securityAgentAmountDue;

    private Integer transactionHandlingItem;

    private Integer safekeepingItem;

    private Integer otherItem;
    private BigDecimal otherFee;
    private BigDecimal otherAmountDue;
}
