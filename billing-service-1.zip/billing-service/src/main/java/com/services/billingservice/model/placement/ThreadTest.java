package com.services.billingservice.model.placement;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.math.BigDecimal;

@Entity
@Table(name = "placement_thread_test")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ThreadTest {

    @Id
    @GenericGenerator(name = "system-uuid", strategy = "uuid2")
    @GeneratedValue(generator = "system-uuid")
    private String id;

    @Column(name = "code")
    private String code;

    @Column(name = "")
    private String name;

    @Column(name = "price")
    private BigDecimal price;

}
