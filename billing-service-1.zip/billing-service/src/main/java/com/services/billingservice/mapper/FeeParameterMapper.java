package com.services.billingservice.mapper;

import com.services.billingservice.dto.datachange.BillingDataChangeDTO;
import com.services.billingservice.dto.feeparameter.FeeParameterDTO;
import com.services.billingservice.enums.ApprovalStatus;
import com.services.billingservice.model.BillingFeeParam;
import com.services.billingservice.utils.ConvertDateUtil;
import org.modelmapper.ModelMapper;
import org.modelmapper.PropertyMap;
import org.springframework.stereotype.Component;

@Component
public class FeeParameterMapper extends BaseMapper<BillingFeeParam, FeeParameterDTO> {

    private final ConvertDateUtil convertDateUtil;

    public FeeParameterMapper(ModelMapper modelMapper, ConvertDateUtil convertDateUtil) {
        super(modelMapper);
        this.convertDateUtil = convertDateUtil;
    }

    @Override
    protected PropertyMap<BillingFeeParam, FeeParameterDTO> getPropertyMap() {
        return new PropertyMap<BillingFeeParam, FeeParameterDTO>() {
            @Override
            protected void configure() {
                skip(destination.getApprovalStatus());
                skip(destination.getInputerId());
                skip(destination.getInputerIPAddress());
                skip(destination.getInputDate());
                skip(destination.getApproverId());
                skip(destination.getApproverIPAddress());
                skip(destination.getApproveDate());
            }
        };
    }

    @Override
    protected Class<BillingFeeParam> getEntityClass() {
        return BillingFeeParam.class;
    }

    @Override
    protected Class<FeeParameterDTO> getDtoClass() {
        return FeeParameterDTO.class;
    }

    @Override
    protected void setCommonProperties(BillingFeeParam entity, BillingDataChangeDTO dataChangeDTO) {
        entity.setApprovalStatus(ApprovalStatus.Approved);
        entity.setInputerId(dataChangeDTO.getInputerId());
        entity.setInputerIPAddress(dataChangeDTO.getInputerIPAddress());
        entity.setInputDate(dataChangeDTO.getInputDate());
        entity.setApproverId(dataChangeDTO.getApproverId());
        entity.setApproverIPAddress(dataChangeDTO.getApproverIPAddress());
        entity.setApproveDate(convertDateUtil.getDate());
    }

}
