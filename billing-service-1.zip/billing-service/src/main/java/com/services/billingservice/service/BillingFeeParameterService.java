package com.services.billingservice.service;

import com.services.billingservice.dto.datachange.BillingDataChangeDTO;
import com.services.billingservice.dto.feeparameter.*;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

public interface BillingFeeParameterService {

    boolean isCodeAlreadyExists(String code);

    boolean isNameAlreadyExists(String name);

    BigDecimal getValueByName(String name);

    String getFeeDescriptionByName(String name);
    
    Map<String, BigDecimal> getValueByNameList(List<String> nameList);

    FeeParameterResponse createSingleData(CreateFeeParameterRequest createFeeParameterRequest, BillingDataChangeDTO dataChangeDTO);

    FeeParameterResponse createMultipleData(CreateFeeParameterListRequest createFeeParameterListRequest, BillingDataChangeDTO dataChangeDTO);

    FeeParameterResponse createSingleApprove(FeeParameterApproveRequest createFeeParameterListRequest, String clientIP);

    FeeParameterResponse updateSingleData(UpdateFeeParameterRequest updateFeeParameterRequest, BillingDataChangeDTO dataChangeDTO);

    FeeParameterResponse updateMultipleData(UpdateFeeParameterListRequest updateFeeParameterListRequest, BillingDataChangeDTO dataChangeDTO);

    FeeParameterResponse updateSingleApprove(FeeParameterApproveRequest updateFeeParameterListRequest, String clientIP);

    List<FeeParameterDTO> getAll();

    FeeParameterDTO getByCode(String code);

    FeeParameterDTO findById(Long id);

    String deleteAll();
}
