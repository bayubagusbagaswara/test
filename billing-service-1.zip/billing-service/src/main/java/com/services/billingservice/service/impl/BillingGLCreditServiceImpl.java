package com.services.billingservice.service.impl;

import com.services.billingservice.exception.DataNotFoundException;
import com.services.billingservice.model.BillingGlCredit;
import com.services.billingservice.repository.BillingGlCreditRepository;
import com.services.billingservice.service.BillingGLCreditService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
@Slf4j
public class BillingGLCreditServiceImpl implements BillingGLCreditService {

    private final BillingGlCreditRepository glCreditRepository;

    @Override
    public BillingGlCredit getByBillingTemplateAndGLCreditName(String billingTemplate, String glCreditName) {
        return glCreditRepository.findByGlBillingTemplateAndGlCreditName(billingTemplate, glCreditName)
                .orElseThrow(() -> new DataNotFoundException("Billing GL Credit not found with billing template: " + billingTemplate + ", and GL credit name: " + glCreditName));
    }

}
