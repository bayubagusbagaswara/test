package com.services.billingservice.service;

import com.services.billingservice.dto.billingtemplate.BillingTemplateRequest;
import com.services.billingservice.dto.billingtemplate.BillingTemplateDTO;

import java.util.List;

public interface BillingTemplateService {

   BillingTemplateDTO create(BillingTemplateRequest request);

   BillingTemplateDTO getById(String id);

   List<BillingTemplateDTO> getAll();

   List<String> getAllSubCode();

   BillingTemplateDTO updateById(String id, BillingTemplateRequest request);

   List<BillingTemplateDTO> getByType(String type);

   List<BillingTemplateDTO> getByCategoryAndTypeAndSubCode(String category, String type, String subCode, String currency);

   String delete(String Id);

    boolean isExistsByCategoryAndTypeAndCurrencyAndSubCodeAndTemplateName(String category, String type, String currency, String subCode, String templateName);

    BillingTemplateDTO getByCategoryAndTypeAndCurrencyAndSubCodeAndTemplateName(String category, String type, String currency, String subCode, String templateName);
}
