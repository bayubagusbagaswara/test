package com.services.billingservice.dto.placement.createtransferplacement;

import com.services.billingservice.dto.approval.InputIdentifierRequest;
import lombok.*;
import lombok.experimental.SuperBuilder;

import java.util.List;

@EqualsAndHashCode(callSuper = true)
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class CreateBulkPlacementListRequest extends InputIdentifierRequest {

    private String placementTransferType; // RTGS, SKN, BI-FAST

    private String description;

    private List<CreateBulkPlacementRequest> createBulkPlacementRequestList;
}
