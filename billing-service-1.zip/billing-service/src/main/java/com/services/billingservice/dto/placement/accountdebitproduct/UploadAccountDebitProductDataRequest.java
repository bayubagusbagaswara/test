package com.services.billingservice.dto.placement.accountdebitproduct;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.services.billingservice.dto.placement.validation.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UploadAccountDebitProductDataRequest {

    @JsonProperty(value = "Product Code")
    @NotBlank(message = "Product Code must not be blank", groups = {AddValidationGroup.class, UpdateValidationGroup.class})
    @Alphanumeric(message = "Product Code contain only alphanumeric characters", groups = {AddValidationGroup.class, UpdateValidationGroup.class})
    private String productCode;

    @JsonProperty(value = "Fund Code")
    @NotBlank(message = "Fund Code must not be blank", groups = {AddValidationGroup.class, UpdateValidationGroup.class})
    @Alphanumeric(message = "Fund Code must contain alphanumeric characters", groups = {AddValidationGroup.class, UpdateValidationGroup.class})
    private String fundCode;

    @JsonProperty(value = "Fund Name")
    @NotBlank(message = "Fund Name must not be blank", groups = AddValidationGroup.class)
    private String fundName;

    @JsonProperty(value = "IM Code")
    @NotBlank(message = "IM Code must not be blank", groups = AddValidationGroup.class)
    @Alphanumeric(message = "IM Code must contain alphanumeric characters", groups = {AddValidationGroup.class, UpdateValidationGroup.class})
    private String imCode;

    @JsonProperty(value = "IM Name")
    @NotBlank(message = "IM Name must not be blank", groups = AddValidationGroup.class)
    private String imName;

    @JsonProperty(value = "Currency")
    @NotBlank(message = "Currency must not be blank", groups = AddValidationGroup.class)
    @AlphabetOnly(message = "Currency must contain only alphabetic characters or must be exactly 3 characters long", groups = {AddValidationGroup.class, UpdateValidationGroup.class})
    @Size(min = 3, max = 3, message = "Currency must contain only alphabetic or must be exactly 3 characters long", groups = {AddValidationGroup.class, UpdateValidationGroup.class})
    private String currency;

    @JsonProperty(value = "Cash Account")
    @NotBlank(message = "Cash Account must not be blank", groups = AddValidationGroup.class)
    @NumericOnly(message = "Cash Account must contain only numeric digits", groups = {AddValidationGroup.class, UpdateValidationGroup.class})
    private String cashAccount;

    @JsonProperty(value = "Bank Name")
    @NotBlank(message = "Bank Name must not be blank", groups = AddValidationGroup.class)
    private String bankName;

}
