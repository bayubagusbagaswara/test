package com.services.billingservice.repository.placement;

import com.services.billingservice.enums.ApprovalStatus;
import com.services.billingservice.model.placement.PlacementApproval;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface PlacementApprovalRepository extends JpaRepository<PlacementApproval, Long> {

    @Query("SELECT p FROM PlacementApproval p WHERE p.placementDate = :placementDate AND p.approvalStatus = :approvalStatus")
    List<PlacementApproval> findByPlacementDateAndApprovalStatus(
            @Param("placementDate") LocalDate placementDate,
            @Param("approvalStatus") ApprovalStatus approvalStatus);

    @Query("SELECT p FROM PlacementApproval p WHERE p.placementDate = :placementDate AND p.approvalStatus = :approvalStatus AND p.placementTransferType = :placementTransferType")
    List<PlacementApproval> findByPlacementDateAndApprovalStatusAndPlacementTransferType(
            @Param("placementDate") LocalDate placementDate,
            @Param("approvalStatus") ApprovalStatus approvalStatus,
            @Param("placementTransferType") String placementTransferType);

    @Query(value = "SELECT DISTINCT placement_transfer_type FROM placement_approval WHERE ISNULL(placement_transfer_type, '') != '' ORDER BY placement_transfer_type ASC", nativeQuery = true)
    List<String> findAllTransferType();

    @Query("SELECT p FROM PlacementApproval p WHERE p.placementDate = :placementDate and p.approvalStatus = 'Approved'" )
    List<PlacementApproval> findAllByDate(@Param("placementDate") LocalDate date);

}
