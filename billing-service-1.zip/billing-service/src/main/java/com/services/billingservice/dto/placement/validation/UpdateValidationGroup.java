package com.services.billingservice.dto.placement.validation;

public interface UpdateValidationGroup {
}
