package com.services.billingservice.dto.placement.accountdebitproduct;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * productCode
 * fundCode
 * fundName
 * imCode
 * imName
 * currency
 * cashAccount
 * bankName
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AccountDebitProductDTO {

    private Long id;

    private String productCode;

    private String fundCode;

    private String fundName;

    private String imCode;

    private String imName;

    private String currency;

    private String cashAccount;

    private String bankName;

}
