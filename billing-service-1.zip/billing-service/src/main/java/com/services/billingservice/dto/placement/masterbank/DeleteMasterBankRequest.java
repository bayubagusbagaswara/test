package com.services.billingservice.dto.placement.masterbank;

import com.services.billingservice.dto.approval.InputIdentifierRequest;
import lombok.*;
import lombok.experimental.SuperBuilder;

@EqualsAndHashCode(callSuper = true)
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class DeleteMasterBankRequest extends InputIdentifierRequest {

    private Long id;

}
