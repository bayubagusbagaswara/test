package com.services.billingservice.service.impl;

import com.services.billingservice.dto.emailprocessing.BillingEmailProcessingDTO;
import com.services.billingservice.repository.BillingEmailProcessingRepository;
import com.services.billingservice.service.BillingEmailProcessingService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@Slf4j
@RequiredArgsConstructor
public class BillingEmailProcessingServiceImpl implements BillingEmailProcessingService {

    private final BillingEmailProcessingRepository billingEmailProcessingRepository;

    @Override
    public List<BillingEmailProcessingDTO> generateFileFund(String period) {
        return billingEmailProcessingRepository.getTosFund(period);
    }

    @Override
    public List<BillingEmailProcessingDTO> generateFileCore(String period) {
        return billingEmailProcessingRepository.getTosCore(period);
    }

    @Override
    public List<BillingEmailProcessingDTO> generateFileRetail(String period) {
        return billingEmailProcessingRepository.getTosRetail(period);
    }

}
