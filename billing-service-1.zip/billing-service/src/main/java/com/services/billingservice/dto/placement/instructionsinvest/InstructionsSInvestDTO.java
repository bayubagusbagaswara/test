package com.services.billingservice.dto.placement.instructionsinvest;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class InstructionsSInvestDTO {

    private Long id;

    private String imCode;

    private String imName;

    private String fundCode;

    private String fundName;

    private String placementBankCode;

    private String placementBankName;

    private String placementBankCashAccountName;

    private String placementBankCashAccountNo;

    private String currency;

    private String principle;

    private String placementDate;

    private String referenceNo;

    private String siReferenceId;

}
