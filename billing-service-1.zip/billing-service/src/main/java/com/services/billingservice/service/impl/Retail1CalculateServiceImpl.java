package com.services.billingservice.service.impl;

import com.services.billingservice.dto.billing.BillingCalculationErrorMessageDTO;
import com.services.billingservice.dto.billing.BillingCalculationResponse;
import com.services.billingservice.dto.billing.BillingContextDate;
import com.services.billingservice.dto.retail.RetailTemplate1IDR;
import com.services.billingservice.dto.retail.RetailType1Parameter;
import com.services.billingservice.dto.mi.InvestmentManagementDTO;
import com.services.billingservice.dto.retail.Retail1QueryResultDTO;
import com.services.billingservice.dto.retail.RetailCalculateRequest;
import com.services.billingservice.enums.ApprovalStatus;
import com.services.billingservice.enums.BillingStatus;
import com.services.billingservice.model.BillingCustomer;
import com.services.billingservice.model.BillingRetail;
import com.services.billingservice.repository.BillingRetailRepository;
import com.services.billingservice.repository.RetailAccountBalanceRepository;
import com.services.billingservice.service.*;
import com.services.billingservice.utils.ConvertDateUtil;
import com.services.billingservice.utils.StringUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static com.services.billingservice.constant.SecurityGroupConstant.*;
import static com.services.billingservice.enums.Currency.IDR;
import static com.services.billingservice.enums.Currency.USD;
import static com.services.billingservice.enums.FeeParameter.BILLING_PAYMENT_DUE_DATE;
import static com.services.billingservice.enums.FeeParameter.CUSTOMER_SAFEKEEPING_BDI_IDR;
import static com.services.billingservice.enums.FeeParameter.CUSTOMER_SAFEKEEPING_BDI_USD;

@Service
@Slf4j
@RequiredArgsConstructor
public class Retail1CalculateServiceImpl implements Retail1CalculateService {

    private final BillingCustomerService customerService;
    private final RetailAccountBalanceRepository retailAccountBalanceRepository;
    private final BillingRetailRepository billingRetailRepository;
    private final BillingNumberService billingNumberService;
    private final BillingMIService investmentManagementService;
    private final BillingFeeParameterService feeParameterService;
    private final ConvertDateUtil convertDateUtil;

    @Override
    public String calculate(RetailCalculateRequest request) {
        log.info("Start core billing calculation type 1 with a data request: {}", request);

        /* initialize data response */
        Integer totalDataSuccess = 0;
        Integer totalDataFailed = 0;
        List<BillingCalculationErrorMessageDTO> errorMessageList = new ArrayList<>();

        /* initialize data request */
        Instant dateNow = Instant.now();
        String categoryUpperCase = request.getCategory().toUpperCase();
        String typeUpperCase = StringUtil.replaceBlanksWithUnderscores(request.getType());

        /* get data fee parameters */
        String paymentDueDate = feeParameterService.getFeeDescriptionByName(BILLING_PAYMENT_DUE_DATE.getValue());

        /* get data fee parameter for percentage WM IDR */
        BigDecimal customerSafekeepingBDIIDR = feeParameterService.getValueByName(CUSTOMER_SAFEKEEPING_BDI_IDR.getValue());

        /* get data fee parameter for percentage WM USD */
        BigDecimal customerSafekeepingBDIUSD = feeParameterService.getValueByName(CUSTOMER_SAFEKEEPING_BDI_USD.getValue());

        /* generate billing context date */
        BillingContextDate contextDate = convertDateUtil.getBillingContextDate(dateNow);

        /* get all customer Retail Type 1 */
        List<BillingCustomer> customerList = customerService.getAllByBillingCategoryAndBillingType(categoryUpperCase, typeUpperCase);

        for (BillingCustomer customer : customerList) {
            try {
                String customerCode = customer.getCustomerCode();

                /* get data investment management */
                InvestmentManagementDTO investmentManagementDTO = investmentManagementService.getByCode(customer.getMiCode());

                /* create billing retail */
                BillingRetail billingRetail = createBillingRetail(contextDate, customer, investmentManagementDTO, paymentDueDate);

                /* check currency is IDR or USD */
                if (IDR.getValue().equalsIgnoreCase(customer.getCurrency())) {
                    List<Retail1QueryResultDTO> retailAccountBalances = retailAccountBalanceRepository
                            .getSumTotalAmountFeeBySellingAgentAndCurrencyIDR(customer.getSellingAgent(), customer.getCurrency());

                    RetailType1Parameter retailType1Parameter = new RetailType1Parameter(retailAccountBalances);

                    RetailTemplate1IDR retailTemplate1IDR = calculateRetailType1IDR(retailType1Parameter);

                    updateBillingRetailForRetailTemplate1IDR(billingRetail, customerSafekeepingBDIIDR, retailTemplate1IDR);

                } else if (USD.getValue().equalsIgnoreCase(customer.getCurrency())) {
                    BigDecimal totalAmountDue = retailAccountBalanceRepository
                            .getSumTotalAmountFeeBySellingAgentAndCurrencyUSD(customer.getSellingAgent(), customer.getCurrency());

                    billingRetail.setSafekeepingFee(customerSafekeepingBDIUSD);
                    billingRetail.setTotalAmountDue(totalAmountDue);
                }

                /* create a billing number then set it to the billing core */
                String number = billingNumberService.generateSingleNumber(contextDate.getMonthNameNow(), contextDate.getYearNow());
                billingRetail.setBillingNumber(number);

                /* get billing data to check whether the data is in the database or not */
                Optional<BillingRetail> existingBillingRetail = billingRetailRepository.findByCustomerCodeAndSubCodeAndBillingCategoryAndBillingTypeAndMonthAndYear(
                        customerCode, customer.getSubCode(), customer.getBillingCategory(), customer.getBillingType(), contextDate.getMonthNameMinus1(), contextDate.getYearMinus1());

                /* check paid status. if it is FALSE, it can be regenerated */
                if (!existingBillingRetail.isPresent() || Boolean.TRUE.equals(!existingBillingRetail.get().getPaid())) {

                    /* delete billing data if it exists in the database */
                    existingBillingRetail.ifPresent(this::deleteExistingBillingRetail);

                    /* save to the database */
                    billingRetailRepository.save(billingRetail);
                    billingNumberService.saveSingleNumber(number);
                    totalDataSuccess++;
                } else {
                    addErrorMessage(errorMessageList, customer.getCustomerCode(), "Billing already paid for period " + contextDate.getMonthNameMinus1() + " " + contextDate.getYearMinus1());
                    totalDataFailed++;
                }
            } catch (Exception e) {
                handleGeneralError(customer.getCustomerCode(), e, errorMessageList);
                totalDataFailed++;
            }
        }
        log.info("Total successfully calculations: {}, total failed calculations: {}", totalDataSuccess, totalDataFailed);
        BillingCalculationResponse billingCalculationResponse = new BillingCalculationResponse(totalDataSuccess, totalDataFailed, errorMessageList);
        return "Total successful calculations: " + billingCalculationResponse.getTotalDataSuccess() + ", total failed calculations: " + billingCalculationResponse.getTotalDataFailed();
    }

    private void updateBillingRetailForRetailTemplate1IDR(BillingRetail billingRetail, BigDecimal customerSafekeepingBDIIDR, RetailTemplate1IDR retailTemplate1IDR) {
        billingRetail.setSafekeepingFR(retailTemplate1IDR.getSafekeepingFR());
        billingRetail.setSafekeepingSR(retailTemplate1IDR.getSafekeepingSR());
        billingRetail.setSafekeepingST(retailTemplate1IDR.getSafekeepingST());
        billingRetail.setSafekeepingORI(retailTemplate1IDR.getSafekeepingORI());
        billingRetail.setSafekeepingSBR(retailTemplate1IDR.getSafekeepingSBR());
        billingRetail.setSafekeepingPBS(retailTemplate1IDR.getSafekeepingPBS());
        billingRetail.setSafekeepingCorporateBond(retailTemplate1IDR.getSafekeepingCorporateBond());

        billingRetail.setSafekeepingFee(customerSafekeepingBDIIDR);

        billingRetail.setTotalAmountDue(retailTemplate1IDR.getTotalAmountDue());
    }

    private RetailTemplate1IDR calculateRetailType1IDR(RetailType1Parameter param) {
        RetailTemplate1IDR retailTemplate1IDR = new RetailTemplate1IDR();
        BigDecimal totalAmountDue = BigDecimal.ZERO;

        for (Retail1QueryResultDTO accountBalance : param.getRetailAccountBalances()) {
            BigDecimal totalAmountFee = accountBalance.getTotalAmountFee();
            String securityGroup = accountBalance.getSecurityGroup();

            switch (securityGroup.toUpperCase()) {
                case FR:
                    retailTemplate1IDR.setSafekeepingFR(totalAmountFee);
                    break;
                case SR:
                    retailTemplate1IDR.setSafekeepingSR(totalAmountFee);
                    break;
                case ST:
                    retailTemplate1IDR.setSafekeepingST(totalAmountFee);
                    break;
                case ORI:
                    retailTemplate1IDR.setSafekeepingORI(totalAmountFee);
                    break;
                case SBR:
                    retailTemplate1IDR.setSafekeepingSBR(totalAmountFee);
                    break;
                case PBS:
                    retailTemplate1IDR.setSafekeepingPBS(totalAmountFee);
                    break;
                case CORPORATE_BOND:
                    retailTemplate1IDR.setSafekeepingCorporateBond(totalAmountFee);
                    break;
                default:
                    break;
            }
            totalAmountDue = totalAmountDue.add(totalAmountFee);
        }
        retailTemplate1IDR.setTotalAmountDue(totalAmountDue);
        return retailTemplate1IDR;
    }

    private BillingRetail createBillingRetail(BillingContextDate contextDate, BillingCustomer customer, InvestmentManagementDTO investmentManagementDTO, String paymentDueDate) {  // set default field
        String glAccountDebit = "GL " + customer.getAccount() + " CC " + customer.getDebitTransfer();
        return BillingRetail.builder()
                .createdAt(contextDate.getDateNow())
                .updatedAt(contextDate.getDateNow())
                .approvalStatus(ApprovalStatus.Pending)
                .billingStatus(BillingStatus.Generated)
                .customerCode(customer.getCustomerCode())
                .subCode(customer.getSubCode())
                .customerName(customer.getCustomerName())
                .month(contextDate.getMonthNameMinus1())
                .year(contextDate.getYearMinus1())
                .billingPeriod(contextDate.getBillingPeriod())
                .billingStatementDate(ConvertDateUtil.convertInstantToString(contextDate.getDateNow()))
                .billingPaymentDueDate(paymentDueDate)
                .billingCategory(customer.getBillingCategory())
                .billingType(customer.getBillingType())
                .billingTemplate(customer.getBillingTemplate())
                .investmentManagementCode(investmentManagementDTO.getCode())
                .investmentManagementName(investmentManagementDTO.getName())
                .investmentManagementAddress1(investmentManagementDTO.getAddress1())
                .investmentManagementAddress2(investmentManagementDTO.getAddress2())
                .investmentManagementAddress3(investmentManagementDTO.getAddress3())
                .investmentManagementAddress4(investmentManagementDTO.getAddress4())
                .investmentManagementEmail(investmentManagementDTO.getEmail())
                .investmentManagementUniqueKey(investmentManagementDTO.getUniqueKey())
//                .account(customer.getAccount())
                .account(glAccountDebit)
                .accountName(customer.getAccountName())
                .currency(customer.getCurrency())
                .paid(false)
                .gefuCreated(false)
                .safekeepingFee(customer.getCustomerSafekeepingFee())
                .build();
    }

    private void deleteExistingBillingRetail(BillingRetail existBillingRetail) {
        String billingNumber = existBillingRetail.getBillingNumber();
        billingRetailRepository.delete(existBillingRetail);
        billingNumberService.deleteByBillingNumber(billingNumber);
    }

    private void handleGeneralError(String customerCode, Exception e, List<BillingCalculationErrorMessageDTO> errorMessageList) {
        addErrorMessage(errorMessageList, customerCode, e.getMessage());
    }

    private void addErrorMessage(List<BillingCalculationErrorMessageDTO> errorMessageList, String customerCode, String message) {
        List<String> stringList = new ArrayList<>();
        stringList.add(message);
        errorMessageList.add(new BillingCalculationErrorMessageDTO(customerCode, stringList));
    }

}
