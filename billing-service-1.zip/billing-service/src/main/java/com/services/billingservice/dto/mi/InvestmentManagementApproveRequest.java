package com.services.billingservice.dto.mi;

import com.services.billingservice.dto.approval.ApprovalIdentifierRequest;
import lombok.*;
import lombok.experimental.SuperBuilder;

@EqualsAndHashCode(callSuper = true)
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class InvestmentManagementApproveRequest extends ApprovalIdentifierRequest {

    private String dataChangeId;

}
