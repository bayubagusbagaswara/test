package com.services.billingservice.controller.placement;

import com.services.billingservice.dto.ResponseDTO;
import com.services.billingservice.model.placement.NCBSResponse;
import com.services.billingservice.service.placement.NCBSResponseService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping(path = "/api/placement/ncbs-response")
@CrossOrigin(origins = "*", allowedHeaders = "*")
@Slf4j
@RequiredArgsConstructor
public class NCBSResponseController {

    private final NCBSResponseService ncbsResponseService;

    // get data NCBS Response with serviceType = "CREDIT_TRANSFER" and status FAILED and placementDate = today
    @GetMapping(path = "/service-type/current-date")
    public ResponseEntity<ResponseDTO<List<NCBSResponse>>> getAllByServiceTypeAndCurrentDate() {
        List<NCBSResponse> ncbsResponseList = ncbsResponseService.getAllByServiceTypeAndCurrentDate();
        ResponseDTO<List<NCBSResponse>> response = ResponseDTO.<List<NCBSResponse>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(ncbsResponseList)
                .build();
        return ResponseEntity.ok(response);
    }

}
