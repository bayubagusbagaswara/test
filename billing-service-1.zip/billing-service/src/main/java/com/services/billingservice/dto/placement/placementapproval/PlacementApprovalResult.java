package com.services.billingservice.dto.placement.placementapproval;

import com.services.billingservice.dto.ErrorMessageDTO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Collections;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PlacementApprovalResult {

    private boolean success;

    private List<ErrorMessageDTO> errorMessages;

    public static PlacementApprovalResult success() {
        return PlacementApprovalResult.builder()
                .success(true)
                .errorMessages(Collections.emptyList())
                .build();
    }

    public static PlacementApprovalResult failed(List<ErrorMessageDTO> errors) {
        return PlacementApprovalResult.builder()
                .success(false)
                .errorMessages(errors != null ? errors : Collections.emptyList())
                .build();
    }

    public static PlacementApprovalResult failed(String referenceId, String errorMessage) {
        return PlacementApprovalResult.builder()
                .success(false)
                .errorMessages(Collections.singletonList(
                        new ErrorMessageDTO(referenceId, Collections.singletonList(errorMessage))
                ))
                .build();
    }

}
