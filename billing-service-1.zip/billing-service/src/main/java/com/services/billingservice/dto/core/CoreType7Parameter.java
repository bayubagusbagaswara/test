package com.services.billingservice.dto.core;

import com.services.billingservice.model.SfValRgMonthly;
import com.services.billingservice.model.SkTransaction;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CoreType7Parameter {

    private BigDecimal customerSafekeepingFee;

    private List<List<SkTransaction>> skTransactionsList;

    private List<List<SfValRgMonthly>> sfValRgMonthliesList;

    private List<BigDecimal> kseiAmountFeeList;

    private BigDecimal vatFee;

    private BigDecimal kseiTransactionFee;
}
