package com.services.billingservice.constant;

import lombok.experimental.UtilityClass;

@UtilityClass
public class SellingAgentConstant {

    public static final String BDI = "BDI";
    public static final String BINA = "BINA";
    public static final String CTBC = "CTBC";
    public static final String INVISEE = "INVISEE";
}
