package com.services.billingservice.controller.placement;

import com.services.billingservice.dto.ResponseDTO;
import com.services.billingservice.dto.placement.bifastpaymentstatus.BiFastPaymentStatusRequest;
import com.services.billingservice.dto.placement.bifastpaymentstatus.BiFastPaymentStatusResponse;
import com.services.billingservice.service.placement.BiFastPaymentStatusService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(path = "/api/placement/bifast/payment-status")
@CrossOrigin(origins = "*", allowedHeaders = "*")
@Slf4j
@RequiredArgsConstructor
public class BiFastPaymentStatusController {

    private final BiFastPaymentStatusService biFastPaymentStatusService;

    @PostMapping
    public ResponseEntity<ResponseDTO<BiFastPaymentStatusResponse>> biFastPaymentStatus(@RequestBody BiFastPaymentStatusRequest biFastPaymentStatusRequest) {
        BiFastPaymentStatusResponse biFastPaymentStatusResponse = biFastPaymentStatusService.checkPaymentStatus(biFastPaymentStatusRequest);
        ResponseDTO<BiFastPaymentStatusResponse> response = ResponseDTO.<BiFastPaymentStatusResponse>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(biFastPaymentStatusResponse)
                .build();
        return ResponseEntity.ok(response);
    }

}
