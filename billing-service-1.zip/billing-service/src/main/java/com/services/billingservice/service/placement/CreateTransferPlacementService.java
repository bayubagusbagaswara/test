package com.services.billingservice.service.placement;

import com.services.billingservice.dto.placement.createtransferplacement.CreateBulkPlacementListRequest;
import com.services.billingservice.dto.placement.createtransferplacement.CreatePlacementResponse;
import com.services.billingservice.dto.placement.createtransferplacement.CreateSinglePlacementListRequest;

import java.util.concurrent.CompletableFuture;

public interface CreateTransferPlacementService {

    CompletableFuture<CreatePlacementResponse> createBulk(CreateBulkPlacementListRequest createBulkPlacementListRequest, String inputId, String inputIPAddress);

    CompletableFuture<CreatePlacementResponse> createSingle(CreateSinglePlacementListRequest createSinglePlacementListRequest, String inputId, String inputIPAddress);

}
