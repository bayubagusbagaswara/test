package com.services.billingservice.dto.billingtemplate;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BillingTemplateRequest {

    private long id;

    private String templateName;

    private String templateType;

    private String templateCategory;

    private String desc;
}
